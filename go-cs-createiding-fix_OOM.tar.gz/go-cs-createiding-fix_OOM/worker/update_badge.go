package worker

import (
	"encoding/json"
	"strings"

	cm "go.kbtg.tech/715_MicroService/go-common/core_message"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	"go.kbtg.tech/715_microservice/go-cs-createiding/message"
	"go.uber.org/zap"
)

func (w *BulkInsertWorker) updateBadge(requestMessage message.UpdateBadgeMessage) {
	if data, err := json.Marshal(requestMessage); err != nil {
		log.L().Sugar().Error("Can't marshal request to put to updateBadge queue", err, requestMessage)
	} else {
		queueHeaders := make(map[string]string)
		if _, err := w.updateBadgeProducerClient.InsertMessage(data, &queueHeaders); err != nil {
			log.L().Sugar().Error("Can't put to updateBadge queue", err, requestMessage)
		} else {
			for _, v := range requestMessage.Data.UpdateBadgeItems {
				zf1 := zap.String("feedId", v.FeedID)
				zf2 := zap.String("profileId", *v.ProfileID)
				log.L().Info("Put to updateBadge queue success", zf1, zf2)
			}
		}
	}
}

func existID(id string, idings []message.ContentFeed) (int, *message.ContentFeed) {
	if len(idings) == 0 {
		return -1, nil
	}
	for i, iding := range idings {
		if iding.FeedID == id {
			return i, &iding
		}
	}
	return -1, nil
}

func createBadgeItem(h cm.RequestHeader, f message.ContentFeed, qDt string) message.UpdateBadgeItem {
	i := message.UpdateBadgeItem{}
	i.MobileNo = h.MobileNo
	i.Token = f.PushToken
	platform := firstChar(*f.Platform)
	if platform == "A" {
		i.Platform = "A"
	} else {
		i.Platform = "I"
	}
	i.Notification = f.Notification
	i.NotificationMessagePreview = f.NotificationMessagePreview
	i.Language = f.Language
	i.FeedID = f.FeedID
	i.ProfileID = f.ProfileID
	i.CampaignCode = f.CampaignCode
	i.Hashtag = f.Hashtag
	i.TrackingID = f.TrackingID
	i.ContentCategory = f.ContentCategory
	i.Command = f.Command
	i.Parameter = f.Parameter
	i.ActionExpireDate = f.ActionExpireDate
	i.LandingTemplateID = f.LandingTemplateID
	i.LandingButtonLabelSet = f.LandingButtonLabelSet
	i.ImodeFlag = f.ImodeFlag
	i.IdingFlag = f.IdingFlag
	i.LandingFlag = f.LandingFlag
	i.IotherType = f.IotherType
	i.AuthType = f.AuthType
	i.IdingInfo = f.IdingInfo
	i.EnQueueDate = qDt
	return i
}

func firstChar(s string) string {
	if len(s) > 1 {
		return strings.ToUpper(s[:1])
	}
	return "A"
}
