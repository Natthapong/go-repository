package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.kbtg.tech/715_MicroService/go-common/core_message"
	cm "go.kbtg.tech/715_MicroService/go-common/core_message"
	c "go.kbtg.tech/715_MicroService/go-common/core_message_queue/client"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
	const_key "go.kbtg.tech/715_microservice/go-cs-createiding/constant"
	"go.kbtg.tech/715_microservice/go-cs-createiding/message"
	"go.kbtg.tech/715_microservice/go-cs-createiding/model"
	"go.kbtg.tech/715_microservice/go-cs-createiding/repository"
	"go.uber.org/zap"

	"github.com/google/uuid"
)

const (
	logName             = "create.feed"
	logType             = "Create IDing feed"
	sourceSystem        = "715"
	notificationLogStep = "CS-CREATEIDING"
	failed              = "Failed"
	success             = "Success"
	ErrCannotInsert     = "ERR-MS-IDING-0002"
)

type BulkInsertWorker struct {
	bulkSize                  int
	timeOut                   int64
	limitRetry                int
	repository                repository.IdingRepository
	retryProducerClient       c.MessageQueueProducerClient
	updateBadgeProducerClient c.MessageQueueProducerClient
	batchLog                  c.MessageQueueProducerClient

	feeds            []model.IdingItem
	queueHeaders     []map[string]string
	requestHeaders   []cm.RequestHeader
	feedContentItems []message.ContentFeed

	latestExecutedTime int64
	mux                sync.Mutex

	loc *time.Location
}

func NewBulkInsertWorker(bulkSize int, timeOut int64, limitRetry int, repository repository.IdingRepository, retryProducerClient c.MessageQueueProducerClient, updateBadgeProducerClient c.MessageQueueProducerClient,
	batchLog c.MessageQueueProducerClient) *BulkInsertWorker {
	loc, _ := time.LoadLocation("Asia/Bangkok")
	return &BulkInsertWorker{
		bulkSize:                  bulkSize,
		timeOut:                   timeOut,
		limitRetry:                limitRetry,
		repository:                repository,
		retryProducerClient:       retryProducerClient,
		updateBadgeProducerClient: updateBadgeProducerClient,
		batchLog:                  batchLog,
		loc:                       loc,
	}
}

func (w *BulkInsertWorker) DoInsert(feed *model.IdingItem, queueHeader map[string]string, requestHeader cm.RequestHeader, feedContentItem message.ContentFeed) {
	w.mux.Lock()
	if feed != nil {
		w.feeds = append(w.feeds, *feed)
		w.queueHeaders = append(w.queueHeaders, queueHeader)
		w.requestHeaders = append(w.requestHeaders, requestHeader)
		w.feedContentItems = append(w.feedContentItems, feedContentItem)

		zf1 := zap.String("msgId", queueHeader["msgID"])
		zf2 := zap.String("feedId", feedContentItem.FeedID)
		zf3 := zap.String("profileId", *feedContentItem.ProfileID)
		log.L().Info("DoInsert", zf1, zf2, zf3)
		if log.IsLevelEnabled(zap.DebugLevel) {
			log.L().Debug(fmt.Sprintf("msg: %#v", feedContentItem))
		}
	} else if log.IsLevelEnabled(zap.DebugLevel) {
		log.L().Debug("DoInsert - feed is nil")
	}
	if w.isReadyToExecute() {
		w.forceToInsert()
	}
	w.mux.Unlock()
}

func (w *BulkInsertWorker) isReadyToExecute() bool {
	isReady := false
	now := time.Now().Unix()
	batchSize := len(w.feeds)
	if batchSize > 0 && (batchSize >= w.bulkSize || w.latestExecutedTime+w.timeOut < now) {
		isReady = true
		zf1 := zap.Int64("next", w.latestExecutedTime+w.timeOut)
		zf2 := zap.Int64("now", now)
		zf3 := zap.Int("batchSize", batchSize)
		log.L().Debug("isReadyToExecute", zf1, zf2, zf3)
	}
	return isReady
}

func (w *BulkInsertWorker) forceToInsert() {
	lenFeeds := len(w.feeds)
	if lenFeeds == 0 {
		if log.IsLevelEnabled(zap.DebugLevel) {
			log.L().Debug("Nothing to insert.")
		}
		w.resetState()
		return
	}

	var failedIndices = make([]int, 0)
	startTime := time.Now()
	countInserted, errInsert, errInsertDuplicated, _ := w.repository.InsertMany(w.feeds)
	insertProcessingTime := (time.Now().UnixNano() - startTime.UnixNano()) / 1000000
	totalIds, successIds, failIds, failDupIds, successProfileIds := buildIds(w.feeds, errInsert, errInsertDuplicated)
	if log.IsLevelEnabled(zap.InfoLevel) {
		log.L().Sugar().Debugf("Executed insert total %d feeds: %v, success %d feeds: %v, fail %d feeds: %v.", lenFeeds, totalIds, countInserted, successIds, int64(lenFeeds)-countInserted, failIds)
		for i, feedId := range successIds {
			zf1 := zap.String("feedId", feedId)
			zf2 := zap.String("profileId", successProfileIds[i])
			zf3 := zap.Int64("processingTime", insertProcessingTime)
			log.L().Info("Insert Success", zf1, zf2, zf3)
		}
	}
	items := make([]message.UpdateBadgeItem, 0)
	ids := make([]string, 0)
	// Retry
	if feeds, ok := errInsert.(*[]model.IdingItem); ok && len(*feeds) > 0 {
		log.L().Sugar().Warnf("%d feeds need to retry: %v.", len(*feeds), failIds)
		for _, feed := range *feeds {
			i, feedContentItem := existID(feed.FeedID, w.feedContentItems)
			timestamp, _ := w.queueHeaders[i]["timestamp"]
			if i < 0 {
				if feedContentItem.ProfileID != nil && len(*feedContentItem.ProfileID) > 0 {
					badgeItem := createBadgeItem(w.requestHeaders[i], w.feedContentItems[i], timestamp)
					items = append(items, badgeItem)
					ids = append(ids, *feedContentItem.ProfileID)
				}
			} else {
				if w.queueHeaders[i] == nil {
					w.queueHeaders[i] = map[string]string{}
				}

				retryCount, er1 := strconv.Atoi(w.queueHeaders[i]["UCT_retryCount"])
				if er1 != nil {
					retryCount = 1
				}
				retryCount++

				ctx := context.WithValue(context.Background(), const_key.CorID, w.requestHeaders[i].CorrId)
				if log.IsLevelEnabled(zap.InfoLevel) {
					ctx = context.WithValue(ctx, const_key.MobileNo, w.requestHeaders[i].MobileNo)
					if feedContentItem.ProfileID != nil {
						ctx = context.WithValue(ctx, const_key.ProfileID, *feedContentItem.ProfileID)
					}
				}
				if retryCount > w.limitRetry {
					failedIndices = append(failedIndices, i)
					log.Warnf(ctx, "Retry create feed is limitation %d times: %+v.", w.limitRetry, feed)
					badgeItem := createBadgeItem(w.requestHeaders[i], w.feedContentItems[i], timestamp)
					if jsonBytes, err := json.Marshal(badgeItem); err == nil {
						s := string(jsonBytes)
						log.Infof(ctx, "badgeItem of error: %s", s)
					}
					filename, okBatch := w.queueHeaders[i]["UCT_fileName"]
					if w.batchLog != nil && okBatch && len(filename) > 0 {
						batchLog := buildBatchLog(feed, w.queueHeaders[i], w.loc, ErrCannotInsert)
						if d1, er1b := json.Marshal(batchLog); er1b == nil {
							log.Warnf(ctx, "Batch Log: %s", d1)
						}
						data, er2 := json.Marshal(batchLog)
						if er2 != nil {
							log.Error(ctx, "Can't marshal request to put to batchlog queue", er2, batchLog)
						} else {
							log.Warnf(ctx, "Batch Log msg: %s", data)
							queueHeader := make(map[string]string)
							if _, err := w.batchLog.InsertMessage(data, &queueHeader); err != nil {
								log.Error(ctx, "Can't put to batchlog queue", err, batchLog)
							} else {
								log.Info(ctx, "Put to batchlog queue success")
							}
						}
					}
					continue
				}
				if log.IsLevelEnabled(zap.InfoLevel) {
					log.Infof(ctx, "Retry create feed %d times: %v.", retryCount, feed)
				}

				w.queueHeaders[i]["UCT_retryCount"] = strconv.Itoa(retryCount)

				requestMessage := message.RequestMessage{
					Header: w.requestHeaders[i],
					Data: &message.RequestMessageData{
						ContentFeedList: []message.ContentFeed{*feedContentItem},
					},
				}
				w.putToRetry(requestMessage, w.queueHeaders[i])
				continue
			}
		}
	} else if feeds, ok := errInsertDuplicated.(*[]model.IdingItem); ok && len(*feeds) > 0 {
		// Do nothing just print duplicated insert.
		if log.IsLevelEnabled(zap.InfoLevel) {
			for _, feedDupId := range failDupIds {
				zf1 := zap.String("feedId", feedDupId)
				if log.IsLevelEnabled(zap.DebugLevel) {
					log.L().Debug("Duplicated Insert", zf1)
				}
			}
		}
	} else { // CASE: InsertMany successful
		// make a list for badge update
		for i, feedContentItem := range w.feedContentItems {
			if feedContentItem.ProfileID != nil && len(*feedContentItem.ProfileID) > 0 {
				timestamp, _ := w.queueHeaders[i]["timestamp"]
				badgeItem := createBadgeItem(w.requestHeaders[i], w.feedContentItems[i], timestamp)
				items = append(items, badgeItem)
				ids = append(ids, *feedContentItem.ProfileID)
			}
		}
	}
	if len(ids) > 0 {
		updateBadgeMessage := message.UpdateBadgeMessage{
			// Data: &message.UpdateBadgeData{ProfileIDs: ids},
			Data: &message.UpdateBadgeData{UpdateBadgeItems: items},
		}
		go w.updateBadge(updateBadgeMessage)
	}
	w.resetState()
}

func buildIds(totalItem []model.IdingItem, errInsert, errInsertDuplicated interface{}) (totalIds []string, successIds []string, failIds []string, failDupIds []string, successProfileIds []string) {
	if failFeeds, ok := errInsert.(*[]model.IdingItem); ok && len(*failFeeds) > 0 {
		for _, failFeed := range *failFeeds {
			failIds = append(failIds, failFeed.FeedID)
		}
	}

	if failDupFeeds, ok := errInsertDuplicated.(*[]model.IdingItem); ok && len(*failDupFeeds) > 0 {
		for _, failDupFeed := range *failDupFeeds {
			failDupIds = append(failDupIds, failDupFeed.FeedID)
		}
	}

	for _, feed := range totalItem {
		feedId := feed.FeedID

		totalIds = append(totalIds, feedId)

		isFail := false
		for _, failId := range failIds {
			if failId == feedId {
				isFail = true
				break
			}
		}

		for _, failDupId := range failDupIds {
			if failDupId == feedId {
				isFail = true
				break
			}
		}

		if !isFail {
			successIds = append(successIds, feedId)
			successProfileIds = append(successProfileIds, *feed.ProfileID)
		}

	}

	return
}

func (w *BulkInsertWorker) putToRetry(requestMessage interface{}, queueHeaders map[string]string) {
	if data, err := json.Marshal(requestMessage); err != nil {
		log.L().Sugar().Error("Can't marshal request to put to retry queue", err, requestMessage)
	} else {
		if _, err := w.retryProducerClient.InsertMessage(data, &queueHeaders); err != nil {
			log.L().Sugar().Error("Can't put to retry queue", err, requestMessage)
		} else if log.IsLevelEnabled(zap.InfoLevel) {
			log.L().Info("Put to retry queue success")
		}
	}
}

func (w *BulkInsertWorker) resetState() {
	w.feeds = w.feeds[:0]
	w.queueHeaders = w.queueHeaders[:0]
	w.requestHeaders = w.requestHeaders[:0]
	w.feedContentItems = w.feedContentItems[:0]
	w.latestExecutedTime = time.Now().Unix()
}

func (w *BulkInsertWorker) RunScheduler() {
	ticker := time.NewTicker(time.Duration(w.timeOut) * time.Second)
	go func() {
		requestHeader := core_message.RequestHeader{}
		feedContentItem := message.ContentFeed{}
		for {
			select {
			case <-ticker.C:
				w.DoInsert(nil, nil, requestHeader, feedContentItem)
				// do stuff
			}
		}
	}()
}

func buildMsRequestHeader() ms.MsRequestHeader {
	now := time.Now()
	id := uuid.New().String()
	return ms.MsRequestHeader{
		AppId:           "715",
		RequestUniqueId: strings.Replace(id, "-", "", -1),
		RequestDateTime: &now,
		Language:        core_message.Thai,
	}
}

func buildBatchLog(feed model.IdingItem, queueHeader map[string]string, loc *time.Location, responseCode string) *model.BatchLogInsert {
	log := model.BatchLogInsert{}
	b, er1 := json.Marshal(feed)
	if er1 == nil {
		log.RawData = string(b)
	}
	queueDateTime, ok0 := queueHeader["UCT_logStartTime"]
	if ok0 {
		i64, er0 := strconv.ParseInt(queueDateTime, 10, 64)
		if er0 == nil {
			i64 = i64 / 1000
			t := time.Unix(i64, 0).In(loc)
			log.QueueDateTime = &t
		}
	} else {
		now := time.Now()
		log.QueueDateTime = &now
	}

	log.MobileNo = queueHeader["UCT_mobileNo"]
	log.BatchId = queueHeader["UCT_batchId"]
	log.Filename = queueHeader["UCT_fileName"]
	log.OriginalFilename = getOriginalFilename(log.Filename)

	lineNo, ok := queueHeader["UCT_lineNo"]
	if ok {
		if strings.HasSuffix(lineNo, ")") {
			i0 := strings.LastIndex(lineNo, "=")
			if i0 >= 0 {
				x2 := lineNo[i0+1 : len(lineNo)-1]
				i, er0 := strconv.Atoi(x2)
				if er0 == nil {
					log.LineNo = i
				}
			}
		} else {
			i, er0 := strconv.Atoi(lineNo)
			if er0 == nil {
				log.LineNo = i
			}
		}
	}
	log.IDingFlag = "F"

	log.TrackingId = feed.TrackingID
	log.UpdateState = feed.State
	log.ActionExpireDate = feed.ActionExpireDate
	log.CampaignCode = feed.CampaignCode
	log.FeedId = feed.FeedID

	if responseCode != "UPDATE_WITH_NO_DOCUMENT_MODIFIED" {
		log.FeedStatus = "F"
		log.ResponseCode = responseCode
	} else {
		log.FeedStatus = "S"
	}
	log.FailType = "FD"
	return &log
}

func getOriginalFilename(filename string) string {
	originalFilename := ""
	underScoreSeparates := strings.Split(filename, "_")
	dotSeparates := strings.Split(filename, ".")
	if len(underScoreSeparates) >= 3 && len(dotSeparates) >= 2 {
		lastTerm := underScoreSeparates[2]
		lastTermWithDot := strings.Split(lastTerm, ".")
		if len(lastTermWithDot) > 0 {
			lastTerm = lastTermWithDot[0]
		}
		originalFilename = underScoreSeparates[0] + "_" + underScoreSeparates[1] + "_" + lastTerm +
			"." + dotSeparates[1]
	}
	return originalFilename
}
