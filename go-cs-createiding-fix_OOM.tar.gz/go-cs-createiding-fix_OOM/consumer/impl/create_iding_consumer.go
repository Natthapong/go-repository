package impl

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	c "go.kbtg.tech/715_MicroService/go-common/core_message_queue/client"
	m "go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	const_key "go.kbtg.tech/715_microservice/go-cs-createiding/constant"
	"go.kbtg.tech/715_microservice/go-cs-createiding/message"
	"go.kbtg.tech/715_microservice/go-cs-createiding/model"
	"go.kbtg.tech/715_microservice/go-cs-createiding/worker"
	"go.uber.org/zap"
)

var Now = time.Now

type CreateIdingConsumer struct {
	name             string
	consumerClient   c.MessageQueueConsumerClient
	bulkInsertWorker *worker.BulkInsertWorker
}

func NewCreateIdingConsumer(name string, consumerClient c.MessageQueueConsumerClient, bulkInsertWorker *worker.BulkInsertWorker) *CreateIdingConsumer {
	return &CreateIdingConsumer{
		name:             name,
		consumerClient:   consumerClient,
		bulkInsertWorker: bulkInsertWorker,
	}
}

func (w *CreateIdingConsumer) isConcernLine(line message.ContentFeed) bool {
	return line.IdingFlag && line.IdingInfo != nil
}

func getChannelAndSourceAppID(mqHeaders map[string]string) (channel, sourceAppID string) {
	channel = mqHeaders["UCT_channel"]
	if mqHeaders["UCT_mode"] == "batch" {
		channel = fmt.Sprintf("Batch (%s)", mqHeaders["UCT_fileName"])
	}
	sourceAppID = mqHeaders["UCT_sourceAppId"]
	return
}

func (w *CreateIdingConsumer) CreateContentList(contentFeedList []message.ContentFeed, mqHeaders map[string]string) []model.IdingItem {
	channel, sourceAppID := getChannelAndSourceAppID(mqHeaders)
	idings := make([]model.IdingItem, 0)
	createTime := Now()
	expiryDate := createTime.AddDate(0, 0, 30)
	for _, item := range contentFeedList {
		if w.isConcernLine(item) {
			state := model.NEW.String()
			var iding = model.IdingItem{
				FeedID:                item.FeedID,
				ProfileID:             item.ProfileID,
				CampaignCode:          item.CampaignCode,
				TrackingID:            item.TrackingID,
				Hashtag:               item.Hashtag,
				ContentCategory:       item.ContentCategory,
				Command:               item.Command,
				Parameter:             item.Parameter,
				ActionExpireDate:      item.ActionExpireDate,
				ImodeFlag:             item.ImodeFlag,
				IdingFlag:             item.IdingFlag,
				LandingFlag:           item.LandingFlag,
				LandingTemplateID:     item.LandingTemplateID,
				LandingButtonLabelSet: item.LandingButtonLabelSet,
				IotherType:            item.IotherType,
				AuthType:              item.AuthType,
				CreateDate:            &createTime,
				ExpiryDate:            &expiryDate,
				State:                 &state,
				Key:                   item.Key,
				OnPremise:             item.OnPremise,
				SourceAppID:           sourceAppID,
				Channel:               channel,
			}
			if item.IdingInfo != nil {
				idingInfo := item.IdingInfo
				th := model.DingItemInfo{
					Image:     idingInfo.IdingImgTH,
					Topic:     idingInfo.IdingMsgTopicTH,
					Body:      idingInfo.IdingMsgBodyTH,
					Highlight: idingInfo.IdingMsgHighLightTH,
					Footer:    idingInfo.IdingMsgFooterTH,
				}
				en := model.DingItemInfo{
					Image:     idingInfo.IdingImgEN,
					Topic:     idingInfo.IdingMsgTopicEN,
					Body:      idingInfo.IdingMsgBodyEN,
					Highlight: idingInfo.IdingMsgHighLightEN,
					Footer:    idingInfo.IdingMsgFooterEN,
				}
				iding.En = &en
				iding.Th = &th
			}

			idings = append(idings, iding)
		}
	}
	return idings
}

func (w *CreateIdingConsumer) Consume() {
	log.Debugf(context.Background(), "Started %s consume create feed.", w.name)
	w.consumerClient.ConsumeMessage(func(err error, messageQueue *m.MessageQueue) {
		ctx := log.AddLogField(context.Background(), "consumer", w.name)
		if err != nil {
			log.Errorf(ctx, "Processing message error: %v", err)
			return
		} else if messageQueue == nil {
			log.Errorf(ctx, "Processing message: messageQueue empty. %v", messageQueue)
			return
		}

		var request message.RequestMessage
		if err := json.Unmarshal(messageQueue.Data, &request); err != nil {
			log.Errorf(ctx, "Error Unmarshal messageQueue: %s. Data: %s. Attributes: %v.", err.Error(), string(messageQueue.Data), messageQueue.Attributes)
			return
		} else if request.Data == nil {
			log.Errorf(ctx, "Error data message request nil. Attributes: %v.", messageQueue.Attributes)
			return
		}

		feeds := w.CreateContentList(request.Data.ContentFeedList, messageQueue.Attributes)
		for i, feed := range feeds {
			if log.IsLevelEnabled(zap.DebugLevel) {
				newCtx := ctx
				if feed.ProfileID != nil {
					newCtx = context.WithValue(newCtx, const_key.ProfileID, *feed.ProfileID)
				}
				log.Debugf(newCtx, "Put feed %s to bulk.", feed.FeedID)
				for k := range messageQueue.Attributes {
					log.Debugf(ctx, "key[%s]: %s", k, messageQueue.Attributes[k])
				}
			}
			w.bulkInsertWorker.DoInsert(&feed, messageQueue.Attributes, request.Header, request.Data.ContentFeedList[i])
		}
	})
}
