package impl

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"

	c "go.kbtg.tech/715_MicroService/go-common/core_message_queue/client"
	"go.kbtg.tech/715_microservice/go-cs-createiding/message"
	"go.kbtg.tech/715_microservice/go-cs-createiding/model"
	"go.kbtg.tech/715_microservice/go-cs-createiding/worker"
)

func init() {
	Now = func() time.Time {
		return time.Date(2006, 04, 05, 15, 55, 33, 0, time.UTC)
	}
}

func Test_getChannelAndSourceAppID(t *testing.T) {
	type args struct {
		mqHeaders map[string]string
	}
	tests := []struct {
		name            string
		args            args
		wantChannel     string
		wantSourceAppID string
	}{
		{
			name: "batch file",
			args: args{
				mqHeaders: map[string]string{
					"UCT_channel":     "something",
					"UCT_mode":        "batch",
					"UCT_sourceAppId": "509",
					"UCT_fileName":    "202107200750_509_CardOnDue.csv",
				},
			},
			wantChannel:     "Batch (202107200750_509_CardOnDue.csv)",
			wantSourceAppID: "509",
		},
		{
			name: "Feed Online",
			args: args{
				mqHeaders: map[string]string{
					"UCT_channel":     "Feed Online",
					"UCT_mode":        "online",
					"UCT_sourceAppId": "509",
					"UCT_fileName":    "202107200750_509_CardOnDue.csv",
				},
			},
			wantChannel:     "Feed Online",
			wantSourceAppID: "509",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotChannel, gotSourceAppID := getChannelAndSourceAppID(tt.args.mqHeaders)
			if gotChannel != tt.wantChannel {
				t.Errorf("getChannelAndSourceAppID() gotChannel = %v, want %v", gotChannel, tt.wantChannel)
			}
			if gotSourceAppID != tt.wantSourceAppID {
				t.Errorf("getChannelAndSourceAppID() gotSourceAppID = %v, want %v", gotSourceAppID, tt.wantSourceAppID)
			}
		})
	}
}

func TestNewCreateIdingConsumer(t *testing.T) {
	type args struct {
		name             string
		consumerClient   c.MessageQueueConsumerClient
		bulkInsertWorker *worker.BulkInsertWorker
	}
	tests := []struct {
		name string
		args args
		want *CreateIdingConsumer
	}{
		{
			name: "New_create_iding_consumer",
			args: args{
				name:             "main",
				consumerClient:   nil,
				bulkInsertWorker: &worker.BulkInsertWorker{},
			},
			want: &CreateIdingConsumer{
				name:             "main",
				consumerClient:   nil,
				bulkInsertWorker: &worker.BulkInsertWorker{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewCreateIdingConsumer(tt.args.name, tt.args.consumerClient, tt.args.bulkInsertWorker); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewCreateIdingConsumer() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCreateIdingConsumer_isConcernLine(t *testing.T) {
	type fields struct {
		name             string
		consumerClient   c.MessageQueueConsumerClient
		bulkInsertWorker *worker.BulkInsertWorker
	}
	type args struct {
		line message.ContentFeed
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   bool
	}{
		{
			name:   "Should false when IdingFlag is false",
			fields: fields{},
			args: args{
				line: message.ContentFeed{
					IdingFlag: false,
				},
			},
			want: false,
		},
		{
			name:   "Should false when IdingInfo is nil",
			fields: fields{},
			args: args{
				line: message.ContentFeed{
					IdingFlag: true,
					IdingInfo: nil,
				},
			},
			want: false,
		},
		{
			name:   "Should true when IdingFlag is true and IdingInfo is not nil",
			fields: fields{},
			args: args{
				line: message.ContentFeed{
					IdingFlag: true,
					IdingInfo: &message.FeedDingItemInfo{},
				},
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := &CreateIdingConsumer{
				name:             tt.fields.name,
				consumerClient:   tt.fields.consumerClient,
				bulkInsertWorker: tt.fields.bulkInsertWorker,
			}
			if got := w.isConcernLine(tt.args.line); got != tt.want {
				t.Errorf("CreateIdingConsumer.isConcernLine() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCreateIdingConsumer_CreateContentList(t *testing.T) {
	actionExpireDate := Now().Add(24 * time.Hour)
	createDate := Now()
	expiryDate := createDate.AddDate(0, 0, 30)
	notification := true
	notificationMessagePreview := true
	platform := "platform"
	pushToken := "pushToken"
	profileID := "profileID"
	language := "language"
	campaignCode := "campaignCode"
	hashtag := "hashtag"
	trackingID := "trackingID"
	contentCategory := "contentCategory"
	command := "command"
	landingTemplateID := "landingTemplateID"
	landingButtonLabelSet := "landingButtonLabelSet"
	key := "key"
	state := "new"
	type fields struct {
		name             string
		consumerClient   c.MessageQueueConsumerClient
		bulkInsertWorker *worker.BulkInsertWorker
	}
	type args struct {
		contentFeedList []message.ContentFeed
		mqHeaders       map[string]string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   []model.IdingItem
	}{
		{
			name: "Should got empty slice",
			fields: fields{
				name:             "main",
				consumerClient:   nil,
				bulkInsertWorker: &worker.BulkInsertWorker{}},
			args: args{
				contentFeedList: []message.ContentFeed{
					{
						IdingFlag: false,
						IdingInfo: &message.FeedDingItemInfo{},
					},
				},
				mqHeaders: map[string]string{},
			},
			want: []model.IdingItem{},
		},
		{
			name: "Should be ok",
			fields: fields{
				name:             "main",
				consumerClient:   nil,
				bulkInsertWorker: &worker.BulkInsertWorker{},
			},
			args: args{
				contentFeedList: []message.ContentFeed{
					{
						FeedID:                     "",
						Notification:               &notification,
						NotificationMessagePreview: &notificationMessagePreview,
						Platform:                   &platform,
						PushToken:                  &pushToken,
						ProfileID:                  &profileID,
						Language:                   &language,
						CampaignCode:               &campaignCode,
						Hashtag:                    &hashtag,
						TrackingID:                 &trackingID,
						ContentCategory:            &contentCategory,
						Command:                    &command,
						Parameter:                  nil,
						ActionExpireDate:           &actionExpireDate,
						LandingTemplateID:          &landingTemplateID,
						LandingButtonLabelSet:      &landingButtonLabelSet,
						ImodeFlag:                  false,
						IdingFlag:                  true,
						LandingFlag:                false,
						IotherType:                 0,
						AuthType:                   0,
						IdingInfo:                  &message.FeedDingItemInfo{},
						Key:                        &key,
						OnPremise:                  false,
					},
				},
				mqHeaders: map[string]string{},
			},
			want: []model.IdingItem{
				{
					FeedID:                "",
					ProfileID:             &profileID,
					CampaignCode:          &campaignCode,
					TrackingID:            &trackingID,
					Hashtag:               &hashtag,
					ContentCategory:       &contentCategory,
					Command:               &command,
					Parameter:             nil,
					ActionExpireDate:      &actionExpireDate,
					ImodeFlag:             false,
					IdingFlag:             true,
					LandingFlag:           false,
					LandingTemplateID:     &landingTemplateID,
					LandingButtonLabelSet: &landingButtonLabelSet,
					IotherType:            0,
					AuthType:              0,
					CreateDate:            &createDate,
					ExpiryDate:            &expiryDate,
					State:                 &state,
					Channel:               "",
					SourceAppID:           "",
					Th:                    &model.DingItemInfo{},
					En:                    &model.DingItemInfo{},
					Key:                   &key,
					OnPremise:             false,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := &CreateIdingConsumer{
				name:             tt.fields.name,
				consumerClient:   tt.fields.consumerClient,
				bulkInsertWorker: tt.fields.bulkInsertWorker,
			}
			got := w.CreateContentList(tt.args.contentFeedList, tt.args.mqHeaders)
			jsonGot, _ := json.Marshal(got)
			jsonWant, _ := json.Marshal(tt.want)
			if string(jsonGot) != string(jsonWant) {
				t.Errorf("CreateIdingConsumer.CreateContentList() = \n%s\n, want \n%s\n", string(jsonGot), string(jsonWant))
			}
		})
	}
}
