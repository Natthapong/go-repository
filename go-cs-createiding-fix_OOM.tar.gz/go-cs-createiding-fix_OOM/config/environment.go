package config

type Environment struct {
	Config *Root
}
