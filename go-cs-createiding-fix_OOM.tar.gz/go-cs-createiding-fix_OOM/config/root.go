package config

import (
	. "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
)

type Root struct {
	Server                   ServerConfig         `mapstructure:"server"`
	Mongo                    MongoConfig          `mapstructure:"mongo"`
	CreateFeedSubConfig      PubSubConsumerConfig `mapstructure:"createFeedSubConfig"`
	RetryCreateFeedSubConfig PubSubConsumerConfig `mapstructure:"retryCreateFeedSubConfig"`
	RetryCreateFeedPubConfig PubSubProducerConfig `mapstructure:"retryCreateFeedPubConfig"`
	BulkWorkerConfig         BulkWorkerConfig     `mapstructure:"bulkWorker"`
	UpdateBadgeConfig        PubSubProducerConfig `mapstructure:"updatebadge"`
	BatchLogConfig           PubSubProducerConfig `mapstructure:"batchlog"`
}

type BulkWorkerConfig struct {
	BulkSize   int   `mapstructure:"bulkSize"`
	TimeOut    int64 `mapstructure:"timeOut"`
	LimitRetry int   `mapstructure:"limitRetry"`
}
