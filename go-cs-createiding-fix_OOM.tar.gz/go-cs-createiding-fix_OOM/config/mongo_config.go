package config

type MongoConfig struct {
	Uri        string `mapstructure:"uri"`
	Database   string `mapstructure:"database"`
	MinConPool uint64 `mapstructure:"minConPool"`
	MaxConPool uint64 `mapstructure:"maxConPool"`
}
