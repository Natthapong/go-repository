package config

import (
	"context"
	"time"

	"go.kbtg.tech/715_MicroService/go-common/health"
	"go.kbtg.tech/715_MicroService/go-common/mongo"

	. "go.kbtg.tech/715_MicroService/go-common/core_message_queue/client/impl"
	. "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	. "go.kbtg.tech/715_microservice/go-cs-createiding/consumer"
	. "go.kbtg.tech/715_microservice/go-cs-createiding/consumer/impl"
	. "go.kbtg.tech/715_microservice/go-cs-createiding/repository/impl"
	"go.kbtg.tech/715_microservice/go-cs-createiding/worker"
)

type ApplicationContext struct {
	CreateIdingConsumer      Consumer
	RetryCreateIdingConsumer Consumer
	BulkInsertWorker         *worker.BulkInsertWorker
	HealthCheckController    *health.HealthCheckEchoController
}

func NewApplicationContext(ctx context.Context, mongoConfig MongoConfig, createFeedSubConfig PubSubConsumerConfig, retryCreateFeedSubConfig PubSubConsumerConfig, retryCreateFeedPubConfig PubSubProducerConfig, bulkWorkerConfig BulkWorkerConfig, updateBadgeConfig PubSubProducerConfig, batchlogConfig PubSubProducerConfig) (*ApplicationContext, error) {
	db, er1 := CreateConnection(ctx, mongoConfig.Uri, mongoConfig.Database, mongoConfig.MinConPool, mongoConfig.MaxConPool)
	if er1 != nil {
		return nil, er1
	}

	createFeedConsumerClient := NewPubSubConsumerClient(ctx, createFeedSubConfig)
	retryCreateFeedConsumerClient := NewPubSubConsumerClient(ctx, retryCreateFeedSubConfig)

	retryCreateFeedProducerClient := NewPubSubProducerClient(retryCreateFeedPubConfig)
	updateBadgeProducerClient := NewPubSubProducerClient(updateBadgeConfig)
	batchLogProducerClient := NewPubSubProducerClient(batchlogConfig)

	repository := NewMongoIdingRepositoryImpl(ctx, db)

	bulkInsertWorker := worker.NewBulkInsertWorker(bulkWorkerConfig.BulkSize, bulkWorkerConfig.TimeOut, bulkWorkerConfig.LimitRetry, repository, retryCreateFeedProducerClient, updateBadgeProducerClient,
		batchLogProducerClient)

	createLandingConsumer := NewCreateIdingConsumer("main", createFeedConsumerClient, bulkInsertWorker)
	retryCreateLandingConsumer := NewCreateIdingConsumer("retry", retryCreateFeedConsumerClient, bulkInsertWorker)

	healthCheckService := make([]health.HealthCheckService, 0)
	healthCheckService = append(healthCheckService, mongo.NewDefaultMongoHealthService(db))
	healthCheckService = append(healthCheckService, health.NewPubSubHealthService(
		"pubsubConsumer",
		createFeedConsumerClient.Client,
		10*time.Second,
		health.ConsumePermission,
		createFeedSubConfig.SubscriptionName,
	))

	healthCheckService = append(healthCheckService, health.NewPubSubHealthService(
		"pubsubPublisher",
		retryCreateFeedProducerClient.Client,
		10*time.Second,
		health.PublishPermission,
		retryCreateFeedPubConfig.TopicName,
	))

	healthCheckService = append(healthCheckService, health.NewPubSubHealthService(
		"pubsubPublisher",
		batchLogProducerClient.Client,
		10*time.Second,
		health.PublishPermission,
		retryCreateFeedPubConfig.TopicName,
	))

	healthCheckController := health.NewHealthCheckEchoController(healthCheckService)

	return &ApplicationContext{
		CreateIdingConsumer:      createLandingConsumer,
		RetryCreateIdingConsumer: retryCreateLandingConsumer,
		BulkInsertWorker:         bulkInsertWorker,
		HealthCheckController:    healthCheckController,
	}, nil
}
