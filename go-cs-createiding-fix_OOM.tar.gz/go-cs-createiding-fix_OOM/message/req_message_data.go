package message

import (
	"time"
)

type (
	RequestMessageData struct {
		ContentFeedList []ContentFeed `json:"contentFeedList"`
	}

	ContentFeed struct {
		FeedID                     string            `json:"feedID"`
		Notification               *bool             `json:"notification"`
		NotificationMessagePreview *bool             `json:"notificationMessagePreview"`
		Platform                   *string           `json:"platform"`
		PushToken                  *string           `json:"pushToken"`
		ProfileID                  *string           `json:"profileID"`
		Language                   *string           `json:"language"`
		CampaignCode               *string           `json:"campaignCode"`
		Hashtag                    *string           `json:"hashtag"`
		TrackingID                 *string           `json:"trackingID"`
		ContentCategory            *string           `json:"contentCategory"`
		Command                    *string           `json:"command"`
		Parameter                  interface{}       `json:"parameter"`
		ActionExpireDate           *time.Time        `json:"actionExpireDate"`
		LandingTemplateID          *string           `json:"landingTemplateID"`
		LandingButtonLabelSet      *string           `json:"landingButtonLabelSet"`
		ImodeFlag                  bool              `json:"imodeFlag"`
		IdingFlag                  bool              `json:"idingFlag"`
		LandingFlag                bool              `json:"landingFlag"`
		IotherType                 int32             `json:"iotherType"`
		AuthType                   int32             `json:"authType"`
		IdingInfo                  *FeedDingItemInfo `json:"idingInfo"`
		Key                        *string           `json:"key"`
		OnPremise                  bool              `json:"onPremise"`
	}

	FeedDingItemInfo struct {
		IdingNotiImgTH      *string `json:"idingNotiImgTH"`
		IdingNotiImgEN      *string `json:"idingNotiImgEN"`
		IdingNotiMsgTopicTH *string `json:"idingNotiMsgTopicTH"`
		IdingNotiMsgTopicEN *string `json:"idingNotiMsgTopicEN"`
		IdingNotiMsgBodyTH  *string `json:"idingNotiMsgBodyTH"`
		IdingNotiMsgBodyEN  *string `json:"idingNotiMsgBodyEN"`

		IdingImgTH          *string `json:"idingImgTH"`
		IdingImgEN          *string `json:"idingImgEN"`
		IdingMsgTopicTH     *string `json:"idingMsgTopicTH"`
		IdingMsgTopicEN     *string `json:"idingMsgTopicEN"`
		IdingMsgBodyTH      *string `json:"idingMsgBodyTH"`
		IdingMsgBodyEN      *string `json:"idingMsgBodyEN"`
		IdingMsgHighLightTH *string `json:"idingMsgHighLightTH"`
		IdingMsgHighLightEN *string `json:"idingMsgHighLightEN"`
		IdingMsgFooterTH    *string `json:"idingMsgFooterTH"`
		IdingMsgFooterEN    *string `json:"idingMsgFooterEN"`
	}

	UpdateBadgeData struct {
		UpdateBadgeItems []UpdateBadgeItem `json:"items"`
		// ProfileIDs []string `json:"ids"`
	}
	UpdateBadgeItem struct {
		MobileNo                   string            `json:"mobileNo,omitempty"`
		Notification               *bool             `json:"notification"`
		NotificationMessagePreview *bool             `json:"notificationMessagePreview"`
		Platform                   string            `json:"platform"`
		Token                      *string           `json:"token"` // ?
		Language                   *string           `json:"language"`
		FeedID                     string            `json:"feedID"`
		ProfileID                  *string           `json:"profileID"`
		CampaignCode               *string           `json:"campaignCode"`
		Hashtag                    *string           `json:"hashtag"`
		TrackingID                 *string           `json:"trackingID"`
		ContentCategory            *string           `json:"contentCategory"`
		Command                    *string           `json:"command"`
		Parameter                  interface{}       `json:"parameter"`
		ActionExpireDate           *time.Time        `json:"actionExpireDate"`
		LandingTemplateID          *string           `json:"landingTemplateID"`
		LandingButtonLabelSet      *string           `json:"landingButtonLabelSet"`
		ImodeFlag                  bool              `json:"imodeFlag"`
		IdingFlag                  bool              `json:"idingFlag"`
		LandingFlag                bool              `json:"landingFlag"`
		IotherType                 int32             `json:"iotherType"`
		AuthType                   int32             `json:"authType"`
		IdingInfo                  *FeedDingItemInfo `json:"idingInfo"`
		EnQueueDate                string            `json:"enQueueDate"`
	}
)
