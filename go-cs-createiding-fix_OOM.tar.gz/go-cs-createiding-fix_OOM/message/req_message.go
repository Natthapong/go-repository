package message

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type RequestMessage struct {
	Header message.RequestHeader `json:"header"`
	Data   *RequestMessageData   `json:"data"`
}

type UpdateBadgeMessage struct {
	Data *UpdateBadgeData `json:"data"`
}
