package repository

type IdingRepository interface {
	InsertMany(landing interface{}) (int64, interface{}, interface{}, error)
	UpdateMany(landing interface{}) (interface{}, error)
}
