package impl

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"strings"
	"time"

	log "go.kbtg.tech/715_MicroService/go-common/logging"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	"go.uber.org/zap"
)

func CreateConnection(ctx context.Context, url string, database string, minConPool, maxConPool uint64) (*mongo.Database, error) {
	hostname, _ := os.Hostname()

	tctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	client, err := mongo.Connect(tctx, options.Client().
		ApplyURI(url).
		SetAppName(hostname).
		SetMinPoolSize(minConPool).
		SetMaxPoolSize(maxConPool).
		SetDisableOCSPEndpointCheck(true))
	if err != nil {
		return nil, err
	}

	if err := MongoDBPing(client, 20*time.Second); err != nil {
		zf := zap.String("error", err.Error())
		log.L().Fatal("Cannot connect database", zf)
	}

	db := client.Database(database)
	return db, nil
}

func MongoDBPing(client *mongo.Client, timeout time.Duration) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	return client.Ping(ctx, readpref.Primary())
}

func InsertMany(ctx context.Context, coll *mongo.Collection, models interface{}, idName string, modelType reflect.Type) (int64, interface{}, interface{}, error) {
	models_ := make([]mongo.WriteModel, 0)
	switch reflect.TypeOf(models).Kind() {
	case reflect.Slice:
		values := reflect.ValueOf(models)
		for i := 0; i < values.Len(); i++ {
			row := values.Index(i).Interface()
			insertModel := mongo.NewInsertOneModel().SetDocument(row)
			models_ = append(models_, insertModel)
		}
	}
	if len(models_) == 0 {
		return int64(reflect.ValueOf(models).Len()), models, models, fmt.Errorf("Error model must be array and no empty")
	}
	var DefaultOrdered = false
	_, err := coll.BulkWrite(ctx, models_, &options.BulkWriteOptions{Ordered: &DefaultOrdered})
	modelsType := reflect.Zero(reflect.SliceOf(modelType)).Type()
	insertedFails := reflect.New(modelsType).Interface()
	insertDuplicatedFails := reflect.New(modelsType).Interface()
	countInserted := int64(reflect.ValueOf(models).Len())
	if err != nil {
		log.L().Sugar().Error("InsertMany Error: ", err.Error())
		values := reflect.ValueOf(models)
		if bulkWriteException, ok := err.(mongo.BulkWriteException); ok {
			for _, we := range bulkWriteException.WriteErrors {
				zf1 := zap.String("error", we.Message)
				zf2 := zap.Int("errorCode", we.Code)
				zf3 := zap.Int("errorIndex", we.Index)
				log.L().Error(we.Error(), zf1, zf2, zf3)
				//check error code duplicate key document
				if we.Code == 11000 {
					appendToArray(insertDuplicatedFails, values.Index(we.Index).Interface())
				} else {
					appendToArray(insertedFails, values.Index(we.Index).Interface())
				}
			}
		} else {
			for i := 0; i < values.Len(); i++ {
				appendToArray(insertedFails, values.Index(i).Interface())
			}
		}
		countInserted := int64(values.Len()) - int64(reflect.Indirect(reflect.ValueOf(insertedFails)).Len()) - int64(reflect.Indirect(reflect.ValueOf(insertDuplicatedFails)).Len())
		return countInserted, insertedFails, insertDuplicatedFails, err
	}
	return countInserted, insertedFails, insertDuplicatedFails, nil
}

func UpdateMany(ctx context.Context, coll *mongo.Collection, models interface{}, filter interface{}, idName string, modelType reflect.Type) (interface{}, error) {
	models_ := make([]mongo.WriteModel, 0)
	modelsType := reflect.Zero(reflect.SliceOf(modelType)).Type()
	noUpdateList := reflect.New(modelsType).Interface()
	switch reflect.TypeOf(models).Kind() {
	case reflect.Slice:
		values := reflect.ValueOf(models)
		for i := 0; i < values.Len(); i++ {
			row := values.Index(i).Interface()
			updateModel := mongo.NewUpdateOneModel().SetUpdate(values.Index(i)).SetFilter(filter)
			if filter == nil {
				v, err1 := getValue(row, idName)
				if err1 == nil && v != nil {
					if reflect.TypeOf(v).String() != "string" {
						updateModel = mongo.NewUpdateOneModel().SetUpdate(bson.M{
							"$set": row,
						}).SetFilter(bson.M{"_id": v})
					} else {
						if idStr, ok := v.(string); ok {
							updateModel = mongo.NewUpdateOneModel().SetUpdate(bson.M{
								"$set": row,
							}).SetFilter(bson.M{"_id": idStr})
						}
					}
				}
			}
			models_ = append(models_, updateModel)
		}
	}
	var DefaultOrdered = false
	_, err := coll.BulkWrite(ctx, models_, &options.BulkWriteOptions{Ordered: &DefaultOrdered})
	if err != nil {
		values := reflect.ValueOf(models)
		if bulkWriteException, ok := err.(mongo.BulkWriteException); ok {
			for _, writeError := range bulkWriteException.WriteErrors {
				appendToArray(noUpdateList, values.Index(writeError.Index).Interface())
			}
			return noUpdateList, err
		}
		return models, err
	}
	return noUpdateList, nil
}

func getValue(model interface{}, fieldName string) (interface{}, error) {
	valueObject := reflect.Indirect(reflect.ValueOf(model))
	numField := valueObject.NumField()
	for i := 0; i < numField; i++ {
		if fieldName == valueObject.Type().Field(i).Name {
			return reflect.Indirect(valueObject).FieldByName(fieldName).Interface(), nil
		}
	}
	return nil, fmt.Errorf("Error no found field: " + fieldName)
}

func appendToArray(arr interface{}, item interface{}) interface{} {
	arrValue := reflect.ValueOf(arr)
	elemValue := arrValue.Elem()

	itemValue := reflect.ValueOf(item)
	if itemValue.Kind() == reflect.Ptr {
		itemValue = reflect.Indirect(itemValue)
	}
	elemValue.Set(reflect.Append(elemValue, itemValue))
	return arr
}

func prettyPrint(i interface{}) string {
	s, _ := json.MarshalIndent(i, "", "\t")
	return string(s)
}

func getRemainElementsOfArray(arrayModelA interface{}, arrayModelsAll interface{}, idName string, isListID bool) interface{} {
	switch reflect.TypeOf(arrayModelsAll).Kind() {
	case reflect.Slice:
		valueObject := reflect.ValueOf(arrayModelsAll)
		arrayModelsB := make([]interface{}, 0)
		for i := 0; i < valueObject.Len(); i++ {
			row := valueObject.Index(i).Interface()
			valueRow := reflect.Indirect(reflect.ValueOf(row))
			numField := valueRow.NumField()
			for j := 0; j < numField; j++ {
				if idName == valueRow.Type().Field(j).Name {
					idModelAll := reflect.Indirect(valueRow).FieldByName(idName).Interface()
					valuesModelA := reflect.Indirect(reflect.ValueOf(arrayModelA))
					exist := false
					for k := 0; k < valuesModelA.Len(); k++ {
						rowModelA := valuesModelA.Index(k).Interface()
						if isListID {
							log.L().Sugar().Debug("compare: ", idModelAll.(string), rowModelA.(string))
							if strings.Compare(idModelAll.(string), rowModelA.(string)) == 0 {
								exist = true
								break
							}
						} else {
							idExist, _ := getValue(rowModelA, idName)
							if strings.Compare(idModelAll.(string), idExist.(string)) == 0 {
								exist = true
								break
							}
						}
					}
					if exist == false {
						arrayModelsB = append(arrayModelsB, idModelAll)
					}
				}
			}
		}
		log.L().Sugar().Debug("Len: ", len(arrayModelsB))
		return arrayModelsB
	}
	return nil
}
