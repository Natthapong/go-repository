package impl

import (
	"context"
	"reflect"

	"go.kbtg.tech/715_microservice/go-cs-createiding/model"
	"go.mongodb.org/mongo-driver/mongo"
)

type MongoIdingRepositoryImpl struct {
	Context        context.Context
	Collection     *mongo.Collection
	db             *mongo.Database
	idName         string
	collectionName string
	modelType      reflect.Type
}

func NewMongoIdingRepositoryImpl(ctx context.Context, db *mongo.Database) *MongoIdingRepositoryImpl {
	modelType := reflect.TypeOf(model.IdingItem{})
	collectionName := "content.iding"
	return &MongoIdingRepositoryImpl{ctx, db.Collection(collectionName), db, "feedID", collectionName, modelType}
}

func (r *MongoIdingRepositoryImpl) InsertMany(landing interface{}) (int64, interface{}, interface{}, error) {
	// countInserted, insertedFails, err := InsertMany(r.Context, r.Collection, landing, r.idName, r.modelType)
	// return countInserted, insertedFails, err
	return InsertMany(r.Context, r.Collection, landing, r.idName, r.modelType)
}

func (r *MongoIdingRepositoryImpl) UpdateMany(Iding interface{}) (interface{}, error) {
	return UpdateMany(r.Context, r.Collection, Iding, nil, r.idName, r.modelType)
}
