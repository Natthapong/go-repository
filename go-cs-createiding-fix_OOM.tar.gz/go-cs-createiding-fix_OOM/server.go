package main

import (
	"context"
	"encoding/json"
	"os"
	"os/signal"
	"strconv"
	"sync"
	"syscall"
	"time"

	"github.com/labstack/echo/v4"
	"go.uber.org/zap"

	"go.kbtg.tech/715_MicroService/go-common/health"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	c "go.kbtg.tech/715_microservice/go-cs-createiding/config"
)

func main() {
	log.InitialLogger()

	quit := make(chan os.Signal)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	ctx, cancel := context.WithCancel(context.Background())
	go func() {
		oscall := <-quit
		log.L().Sugar().Warnf("recieved an OS signal: %v", oscall)
		cancel()
	}()

	parentPath := ""
	resource := "resource"
	env := os.Getenv("ENV")
	log.L().Info("ENV value", zap.String("ENV", env))

	config := c.LoadConfig(parentPath, resource, env, "application")
	conf, _ := json.Marshal(config)
	log.L().Info("app config", zap.String("config", string(conf)))

	server := ""
	if config.Server.Port > 0 {
		server = ":" + strconv.Itoa(config.Server.Port)
	}

	applicationContext, err := c.NewApplicationContext(ctx, config.Mongo, config.CreateFeedSubConfig, config.RetryCreateFeedSubConfig, config.RetryCreateFeedPubConfig, config.BulkWorkerConfig, config.UpdateBadgeConfig, config.BatchLogConfig)

	if err != nil {
		log.L().Sugar().Fatalf("failed to start. %v", err)
	}

	go serve(ctx, server, applicationContext.HealthCheckController)

	applicationContext.BulkInsertWorker.RunScheduler()
	var wg sync.WaitGroup
	wg.Add(1)
	go func(wg *sync.WaitGroup) {
		defer wg.Done()
		applicationContext.CreateIdingConsumer.Consume()
		log.L().Info("main consumer stop")
	}(&wg)
	go func(wg *sync.WaitGroup) {
		defer wg.Done()
		applicationContext.RetryCreateIdingConsumer.Consume()
		log.L().Info("retry consumer stop")
	}(&wg)
	wg.Wait()
}

func serve(ctx context.Context, addr string, healthCheckController *health.HealthCheckEchoController) {
	e := echo.New()
	e.GET("/health", healthCheckController.Check)
	go func() {
		if err := e.Start(addr); err != nil {
			log.L().Sugar().Warn("shutting down the server.", err)
		}
	}()

	<-ctx.Done()

	ctxShutdown, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	if err := e.Shutdown(ctxShutdown); err != nil {
		log.L().Sugar().Warn("server shutdown failed. ", err)
	} else {
		log.L().Info("server exited properly")
	}
}
