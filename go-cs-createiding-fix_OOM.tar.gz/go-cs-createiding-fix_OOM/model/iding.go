package model

import "time"

type (
	IdingItem struct {
		//FEED
		FeedID                string      `json:"feedID" bson:"_id"`
		ProfileID             *string     `json:"profileID" bson:"profileID"`
		CampaignCode          *string     `json:"campaignCode" bson:"campaignCode"`
		TrackingID            *string     `json:"trackingID" bson:"trackingID"`
		Hashtag               *string     `json:"hashtag" bson:"hashtag"`
		ContentCategory       *string     `json:"contentCategory" bson:"contentCategory"`
		Command               *string     `json:"command" bson:"command"`
		Parameter             interface{} `json:"parameter" bson:"parameter"`
		ActionExpireDate      *time.Time  `json:"actionExpireDate" bson:"actionExpireDate"`
		ImodeFlag             bool        `json:"imodeFlag" bson:"imodeFlag"`
		IdingFlag             bool        `json:"idingFlag" bson:"idingFlag"`
		LandingFlag           bool        `json:"landingFlag" bson:"landingFlag"`
		LandingTemplateID     *string     `json:"landingTemplateID" bson:"landingTemplateID"`
		LandingButtonLabelSet *string     `json:"landingButtonLabelSet" bson:"landingButtonLabelSet"`
		IotherType            int32       `json:"iotherType" bson:"iotherType"`
		AuthType              int32       `json:"authType" bson:"authType"`
		CreateDate            *time.Time  `json:"createDate" bson:"createDate"`
		ExpiryDate            *time.Time  `json:"expiryDate" bson:"expiryDate"`
		State                 *string     `json:"state" bson:"state"`
		Channel               string      `json:"channel" bson:"channel"`
		SourceAppID           string      `json:"sourceAppID" bson:"sourceAppID"`

		//Landing
		Th *DingItemInfo `json:"th" bson:"th"`
		En *DingItemInfo `json:"en" bson:"en"`

		Key       *string `json:"key" bson:"key"`
		OnPremise bool    `json:"onPremise" bson:"onPremise"`
	}

	DingItemInfo struct {
		Image     *string `json:"image" bson:"image"`
		Topic     *string `json:"topic" bson:"topic"`
		Body      *string `json:"body" bson:"body"`
		Highlight *string `json:"highlight" bson:"highlight"`
		Footer    *string `json:"footer" bson:"footer"`
	}
)
