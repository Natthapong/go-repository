package model

import (
	"bytes"
	"encoding/json"
)

type FeedState int

const (
	NEW FeedState = iota
	COMPLETE
	EXPIRE
	FAIL
	CANCEL
	HIDE
)

func (d FeedState) String() string {
	return FeedStatesValue[d]
}

func (d *FeedState) FromString(s string) FeedState {
	return FeedStatesName[s]
}

var FeedStatesValue = map[FeedState]string{
	NEW:      "new",
	COMPLETE: "complete",
	EXPIRE:   "expire",
	FAIL:     "fail",
	CANCEL:   "cancel",
	HIDE:     "hide",
}

var FeedStatesName = map[string]FeedState{
	"new":      NEW,
	"complete": COMPLETE,
	"expire":   EXPIRE,
	"fail":     FAIL,
	"cancel":   CANCEL,
	"hide":     HIDE,
}

func (p FeedState) MarshalJSON() ([]byte, error) {
	buffer := bytes.NewBufferString(`"`)
	buffer.WriteString(FeedStatesValue[p])
	buffer.WriteString(`"`)
	return buffer.Bytes(), nil
}

func (p *FeedState) UnmarshalJSON(b []byte) error {
	var s string
	err := json.Unmarshal(b, &s)
	if err != nil {
		return err
	}
	*p = FeedStatesName[s]
	return nil
}
