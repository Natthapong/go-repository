package model

import (
	"time"
)

type BatchLogInsert struct {
	// Id           *primitive.ObjectID `json:"_id,omitempty" bson:"_id,omitempty"`
	BatchId      string  `json:"batchId,omitempty" bson:"batchId,omitempty"`
	LineNo       int     `json:"lineNo" bson:"lineNo"`
	CampaignCode *string `json:"campaignCode,omitempty" bson:"campaignCode,omitempty"` // ?
	FailType     string  `json:"failType,omitempty" bson:"failType,omitempty"`         // ?
	MobileNo     string  `json:"mobileNo,omitempty" bson:"mobileNo,omitempty"`         // ?
	FeedId       string  `json:"feedId,omitempty" bson:"feedId,omitempty"`
	FeedStatus   string  `json:"feedStatus,omitempty" bson:"feedStatus,omitempty"` // S on insert

	Filename         string  `json:"filename,omitempty" bson:"filename,omitempty"`
	OriginalFilename string  `json:"originalFilename,omitempty" bson:"originalFilename,omitempty"`
	TrackingId       *string `json:"trackingId,omitempty" bson:"trackingId,omitempty"` // ?

	IDingFlag    string `json:"iDingFlag,omitempty" bson:"iDingFlag,omitempty"`
	IModeFlag    string `json:"iModeFlag,omitempty" bson:"iModeFlag,omitempty"`
	IOtherFlag   string `json:"iOtherFlag,omitempty" bson:"iOtherFlag,omitempty"`
	ILandingFlag string `json:"iLandingFlag,omitempty" bson:"iLandingFlag,omitempty"`

	ResponseCode  string     `json:"responseCode,omitempty" bson:"responseCode,omitempty"` // ?
	RawData       string     `json:"rawData,omitempty" bson:"rawData,omitempty"`
	QueueDateTime *time.Time `json:"queueDateTime,omitempty" bson:"queueDateTime,omitempty"`
	UpdatedStatus *time.Time `json:"updatedStatus,omitempty" bson:"updatedStatus,omitempty"` // ?

	FeedReferenceID  string     `json:"feedReferenceID,omitempty" bson:"feedReferenceID,omitempty"`
	UpdateState      *string    `json:"updateState,omitempty" bson:"updateState,omitempty"`
	Hidden           bool       `json:"hidden,omitempty" bson:"hidden,omitempty"`
	ActionExpireDate *time.Time `json:"actionExpireDate,omitempty" bson:"actionExpireDate,omitempty"`
}

// batchId and LineNo are unique for update
