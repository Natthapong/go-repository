package constant

type key string

const (
	ProfileID key = "profileId"
	CorID     key = "corId"
	MobileNo  key = "mobileNo"
)
