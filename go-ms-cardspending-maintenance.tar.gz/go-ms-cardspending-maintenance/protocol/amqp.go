package protocol

import (
	"context"
	"net"
	"os"
	"time"

	"github.com/Azure/go-amqp"
	"go.uber.org/zap"
)

func NewSession(logger *zap.Logger, host, port, user, password string) *amqp.Session {
	conn, err := net.Dial("tcp", net.JoinHostPort(host, port))
	if err != nil {
		logger.Fatal("Dialing AMQP server", zap.String("error", err.Error()))
	}
	err = conn.(*net.TCPConn).SetKeepAlive(true)
	if err != nil {
		logger.Fatal("Error set keep alive", zap.String("error", err.Error()))
	}
	err = conn.(*net.TCPConn).SetKeepAlivePeriod(30 * time.Second)
	if err != nil {
		logger.Fatal("Error set keep alive period", zap.String("error", err.Error()))
	}

	hostname, _ := os.Hostname()
	client, err := amqp.New(conn,
		amqp.ConnSASLPlain(user, password),
		amqp.ConnSASLAnonymous(),
		amqp.ConnTLS(false),
		amqp.ConnContainerID(hostname),
		amqp.ConnConnectTimeout(30*time.Second),
		amqp.ConnIdleTimeout(0),
	)
	if err != nil {
		logger.Fatal("Creating AMQP client", zap.String("error", err.Error()))
	}

	session, err := client.NewSession()
	if err != nil {
		logger.Fatal("Creating AMQP session", zap.String("error", err.Error()))
	}
	return session
}

func NewSender(logger *zap.Logger, address string, session *amqp.Session) (*amqp.Sender, error) {
	sender, err := session.NewSender(
		amqp.LinkTargetAddress(address),
	)
	return sender, err
}

func CheckSender(logger *zap.Logger, session *amqp.Session, address string) bool {
	sender, err := session.NewSender(
		amqp.LinkTargetAddress(address),
		amqp.LinkName("healthcheck"),
	)
	if err != nil {
		logger.Error("Cannot create new sender", zap.Error(err))
		return false
	}
	defer func() {
		ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
		sender.Close(ctx)
		cancel()
	}()
	return true
}

func CloseSession(logger *zap.Logger, ctx context.Context, session *amqp.Session) {
	if err := session.Close(ctx); err != nil {
		logger.Sugar().Errorf("Error closing client: %v", err)
	}
}
