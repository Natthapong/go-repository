package protocol

import (
	"context"
	"io"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
	"github.com/valyala/fasthttp"
	"github.com/valyala/fasthttp/fasthttpadaptor"
	"go.uber.org/zap"
)

func ServeHTTP(ctx context.Context, cancel context.CancelFunc, logger *zap.Logger, addr string, readtimeout, writetimeout, idletimeout time.Duration, routes map[string]http.Handler, getRoutes map[string]http.Handler) *fasthttp.Server {
	r := mux.NewRouter()
	r.Use(httpMiddleware)
	r.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.WriteHeader(http.StatusOK)
		io.WriteString(w, `ms-cardspending alives.`)
	})

	handler := cors.Default().Handler(r)
	api := r.PathPrefix("/api").Subrouter()

	for r, f := range routes {
		api.Handle(r, f).Methods("POST")
	}

	for q, f := range getRoutes {
		r.Path(q).Handler(f).Methods("GET")
	}

	srv := newHTTPServer(readtimeout, writetimeout, idletimeout)
	hostname, err := os.Hostname()
	logger.Sugar().Infof("%s - Web server starting on port %v", hostname, addr)
	logger.Sugar().Infof("%s - Press Ctrl+C to stop", hostname)

	if err != nil {
		logger.Sugar().Fatalf("hostname unavailable: %s", err)
	}

	go func() {
		if err := fasthttp.ListenAndServe(addr, fasthttpadaptor.NewFastHTTPHandler(handler)); err != nil {
			logger.Sugar().Fatalf("HTTP server ListenAndServe: %v", err)
		}
	}()
	return srv
}

func newHTTPServer(readtimeout, writetimeout, idletimeout time.Duration) *fasthttp.Server {
	return &fasthttp.Server{
		ReadTimeout:          readtimeout,
		WriteTimeout:         writetimeout,
		IdleTimeout:          idletimeout,
		MaxConnsPerIP:        500,
		MaxRequestsPerConn:   500,
		MaxKeepaliveDuration: 5 * time.Second,
	}
}

func httpMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Add("Content-Type", "application/json")
		next.ServeHTTP(w, r)
	})
}

func CloseHttpServer(logger *zap.Logger, srv *fasthttp.Server) {
	if err := srv.Shutdown(); err != nil {
		logger.Sugar().Infof("HTTP server Shutdown: %v", err)
	}
}
