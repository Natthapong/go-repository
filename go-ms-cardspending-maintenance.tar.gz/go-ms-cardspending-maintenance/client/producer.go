package client

import (
	"context"
	"errors"
	"fmt"
	"io"
	"sync"
	"time"

	"github.com/Azure/go-amqp"
	"github.com/opentracing/opentracing-go"
	"github.com/thitiphong/go-amqptracer"
	"go.uber.org/zap"
	"ucenter.dev/service/logger"
	"ucenter.dev/service/protocol"
)

type Producer struct {
	l        *zap.Logger
	host     string
	port     string
	user     string
	password string
	addr     string
	Sender   *amqp.Sender
	retCnt   int
	retSlp   time.Duration
}

func NewProducer(logger *zap.Logger, host, port, user, password, addr string, s *amqp.Sender, retryCount int, retrySleep time.Duration) *Producer {
	return &Producer{l: logger, host: host, port: port, user: user, password: password, addr: addr, Sender: s, retCnt: retryCount, retSlp: retrySleep}
}

var w sync.WaitGroup
var m sync.Mutex

func (p *Producer) Produce(ctx context.Context, data []byte, messageAttributes *map[string]string) error {
	sp, ctx := opentracing.StartSpanFromContext(ctx, "Produce")
	defer sp.Finish()

	msg := &amqp.Message{
		Value: string(data),
	}
	if messageAttributes != nil {
		msg.ApplicationProperties = p.mapToAttributes(*messageAttributes)
	}
	if err := amqptracer.Inject(sp, msg.ApplicationProperties); err != nil {
		logger.L().Error("cannot inject span", zap.Error(err))
	}
	if err := p.Sender.Send(ctx, msg); err != nil {
		logger.L().Sugar().Errorf("Failed to publish feed(s). [%s]", err.Error())
		if errors.Is(err, io.EOF) {
			w.Add(1)
			p.reconnect(&w, &m)
			w.Wait()
		}
		rerr := p.retry(p.retCnt, p.retSlp*time.Second, func() (err error) {
			serr := p.Sender.Send(ctx, msg)
			if serr == nil {
				logger.L().Debug("Published feed(s) successfully after retry.")
			}
			return serr
		})
		if rerr != nil {
			logger.L().Sugar().Errorf("Failed to publish feed(s) after retry. [%s]", rerr.Error())
			return rerr
		}
	}
	logger.L().Debug("Published feed(s) successfully.")
	return nil
}

func (p *Producer) mapToAttributes(header map[string]string) map[string]interface{} {
	attributes := make(map[string]interface{}, 0)
	for k, v := range header {
		attributes[k] = fmt.Sprintf("%s", v)
	}
	return attributes
}

func (p *Producer) reconnect(wg *sync.WaitGroup, m *sync.Mutex) {
	m.Lock()
	amqpSession := protocol.NewSession(p.l, p.host, p.port, p.user, p.password)
	amqpSender, err := protocol.NewSender(logger.L(), p.addr, amqpSession)
	if err != nil {
		logger.L().Sugar().Fatalf("New sender error: %s\n", err.Error())
	}
	p.Sender = amqpSender
	m.Unlock()
	wg.Done()
}

func (p *Producer) retry(attempts int, sleep time.Duration, f func() error) (err error) {
	for i := 0; ; i++ {
		logger.L().Sugar().Debugf("retrying %d of %d ", i+1, attempts)
		err = f()
		if err == nil {
			return
		}
		logger.L().Sugar().Debugf("retrying %d of %d after error: %s", i+1, attempts, err.Error())
		if i >= (attempts - 1) {
			break
		}
		time.Sleep(sleep)
	}
	return fmt.Errorf("after %d attempts, last error: %s", attempts, err)
}

func CloseSender(logger *zap.Logger, ctx context.Context, sender *amqp.Sender) {
	if err := sender.Close(ctx); err != nil {
		logger.Error("Error close sender.")
	}
}
