package client

import (
	"context"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	"go.uber.org/zap"
)

func NewMongoDB(logger *zap.Logger, url, database string, minConPool, maxConPool uint64) (*mongo.Client, *mongo.Database, error) {
	hostname, _ := os.Hostname()

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	client, err := mongo.Connect(ctx, options.Client().
		ApplyURI(url).
		SetAppName(hostname).
		SetMinPoolSize(minConPool).
		SetMaxPoolSize(maxConPool).
		SetDisableOCSPEndpointCheck(true))
	if err != nil {
		return nil, nil, err
	}

	if err := client.Ping(ctx, readpref.Primary()); err != nil {
		logger.Fatal("Cannot connect database", zap.Error(err))
	}

	db := client.Database(database)
	return client, db, nil
}

func PingMongoDB(logger *zap.Logger, client *mongo.Client) bool {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := client.Ping(ctx, readpref.Primary()); err != nil {
		logger.Error("Cannot ping mongo", zap.Error(err))
		return false
	}
	return true
}

func CloseMongoDB(logger *zap.Logger, ctx context.Context, db *mongo.Database) {
	if err := db.Client().Disconnect(ctx); err != nil {
		logger.Sugar().Panicf("Error closing client: %v", err)
	}
}
