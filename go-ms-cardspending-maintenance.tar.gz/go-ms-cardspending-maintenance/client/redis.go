package client

import (
	"context"
	"time"

	"github.com/go-redis/redis/v8"
	"go.uber.org/zap"
)

func NewRedis(logger *zap.Logger, addr, password string, maxRetry, DB int) (*redis.Client, error) {
	var client *redis.Client
	client = redis.NewClient(&redis.Options{
		MaxRetries: maxRetry,
		Addr:       addr,
		Password:   password,
		DB:         DB,
	})

	err := client.Ping(context.Background()).Err()
	return client, err
}

func PingRedis(logger *zap.Logger, client *redis.Client) bool {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		logger.Error("Cannot ping redis", zap.Error(err))
		return false
	}
	return true
}

func CloseRedis(logger *zap.Logger, client *redis.Client) {
	if err := client.Close(); err != nil {
		logger.Error("Error close redis client.")
	}
}
