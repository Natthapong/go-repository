package logger

import (
	golog "log"
	"os"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

const (
	LOG_FIELDS_KEY = "logFields"
	// DebugLevel logs are typically voluminous, and are usually disabled in
	// production.
	DebugLevel = zap.DebugLevel
	// InfoLevel is the default logging priority.
	InfoLevel = zap.InfoLevel
	// WarnLevel logs are more important than Info, but don't need individual
	// human review.
	WarnLevel = zap.WarnLevel
	// ErrorLevel logs are high-priority. If an application is running smoothly,
	// it shouldn't generate any error-level logs.
	ErrorLevel = zap.ErrorLevel
	// DPanicLevel logs are particularly important errors. In development the
	// logger panics after writing the message.
	DPanicLevel = zap.DPanicLevel
	// PanicLevel logs a message, then panics.
	PanicLevel = zap.PanicLevel
	// FatalLevel logs a message, then calls os.Exit(1).
	FatalLevel = zap.FatalLevel
)

type (
	Level zapcore.Level
)

var logger *zap.Logger = zap.L()

func IsLevelEnabled(lvl zapcore.Level) bool {
	return logger.Core().Enabled(lvl)
}

func InitialLogger() *zap.Logger {
	var err error
	logger, err = NewProduction()
	if err != nil {
		golog.Fatalf("can't initialize zap logger: %v", err)
	}
	zap.ReplaceGlobals(logger)
	defer logger.Sync() // flushes buffer, if any
	return logger

}

// NewProduction builds a sensible production Logger that writes InfoLevel and
// above logs to standard error as JSON.
//
// It's a shortcut for NewProductionConfig().Build(...Option).
func NewProduction(options ...zap.Option) (*zap.Logger, error) {
	return NewProductionConfig().Build(options...)
}

func NewProductionConfig() zap.Config {
	var lv = zapcore.InfoLevel
	if envValue, isSet := os.LookupEnv("LOG_LEVEL"); isSet {
		if err := (&lv).Set(envValue); err != nil {
			golog.Fatalf("Can't parse LOG_LEVEL: %s.", envValue)
		}
	}
	return zap.Config{
		Level:       zap.NewAtomicLevelAt(lv),
		Development: false,
		Sampling: &zap.SamplingConfig{
			Initial:    100,
			Thereafter: 100,
		},
		Encoding:          "json",
		EncoderConfig:     NewProductionEncoderConfig(),
		OutputPaths:       []string{"stderr"},
		ErrorOutputPaths:  []string{"stderr"},
		DisableCaller:     true,
		DisableStacktrace: true,
	}
}

func NewProductionEncoderConfig() zapcore.EncoderConfig {
	config := zapcore.EncoderConfig{
		LevelKey:       "severity",
		NameKey:        "logger",
		CallerKey:      "caller",
		FunctionKey:    zapcore.OmitKey,
		MessageKey:     "msg",
		StacktraceKey:  "stacktrace",
		LineEnding:     zapcore.DefaultLineEnding,
		EncodeLevel:    zapcore.CapitalLevelEncoder,
		EncodeTime:     zapcore.ISO8601TimeEncoder,
		EncodeDuration: zapcore.MillisDurationEncoder,
		EncodeCaller:   zapcore.ShortCallerEncoder,
	}
	if _, isKibana := os.LookupEnv("LOG_FORMAT_ONPREM"); isKibana {
		config.TimeKey = "@timestamp"
		config.MessageKey = "@message"
		config.LevelKey = "level"
	} else {
		config.TimeKey = "time"
	}
	return config
}

func L() *zap.Logger {
	return logger
}
