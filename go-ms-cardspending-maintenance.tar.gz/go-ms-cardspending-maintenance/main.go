package main

import (
	"context"
	"io"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/Azure/go-amqp"
	"github.com/go-redis/redis/v8"
	"github.com/opentracing-contrib/go-stdlib/nethttp"
	"github.com/opentracing/opentracing-go"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	jaeger "github.com/uber/jaeger-client-go"
	jaegercfg "github.com/uber/jaeger-client-go/config"
	"github.com/valyala/fasthttp"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
	"ucenter.dev/service/client"
	"ucenter.dev/service/config"
	"ucenter.dev/service/logger"
	"ucenter.dev/service/pkg/cardspendingalert"
	"ucenter.dev/service/protocol"
)

func SetupTracer() (opentracing.Tracer, io.Closer) {
	defcfg := jaegercfg.Configuration{
		ServiceName: "ms-cardspending",
		Sampler: &jaegercfg.SamplerConfig{
			Type:  jaeger.SamplerTypeConst,
			Param: 1,
		},
		Reporter: &jaegercfg.ReporterConfig{
			LogSpans:            true,
			BufferFlushInterval: 1 * time.Second,
		},
	}
	cfg, err := defcfg.FromEnv()
	if err != nil {
		panic("Could not parse Jaeger env vars: " + err.Error())
	}
	tracer, closer, err := cfg.NewTracer()
	if err != nil {
		panic("Could not initialize jaeger tracer: " + err.Error())
	}
	opentracing.SetGlobalTracer(tracer)
	return tracer, closer
}

func main() {
	tracer, closer := SetupTracer()
	defer closer.Close()

	logger.InitialLogger()
	config.SetEnvTimezone(logger.L())

	parentPath := ""
	resource := "resource"
	env := os.Getenv("ENV")
	logger.L().Info("ENV value", zap.String("ENV", env))

	config := config.LoadConfig(parentPath, resource, env, "application")
	logger.L().Sugar().Debugf("AMQ HOST: %s", config.Amqp.Host)
	logger.L().Sugar().Debugf("AMQ PORT: %s", config.Amqp.Port)
	logger.L().Sugar().Debugf("AMQ ADDR: %s", config.Amqp.Addr)
	logger.L().Sugar().Debugf("REDIS_ADDR: %s", config.Redis.Addr)
	logger.L().Sugar().Debugf("REDIS_MAXRETRY: %d", config.Redis.MaxRetry)
	logger.L().Sugar().Debugf("MONGO_DATABASE: %s", config.Mongo.Database)
	logger.L().Sugar().Debugf("MONGO_COLLECTION: %s", config.Mongo.Collection)

	amqpSession := protocol.NewSession(logger.L(), config.Amqp.Host, config.Amqp.Port, config.Amqp.User, config.Amqp.Password)
	amqpSender, err := protocol.NewSender(logger.L(), config.Amqp.Addr, amqpSession)
	if err != nil {
		logger.L().Sugar().Fatalf("New sender error: %s\n", err.Error())
	}
	amqpProducer := client.NewProducer(logger.L(), config.Amqp.Host, config.Amqp.Port, config.Amqp.User, config.Amqp.Password, config.Amqp.Addr, amqpSender, config.Amqp.RetryCount, config.Amqp.RetrySleep)

	mdb, db, err := client.NewMongoDB(logger.L(), config.Mongo.Uri, config.Mongo.Database, config.Mongo.MinConPool, config.Mongo.MaxConPool)
	if err != nil {
		logger.L().Sugar().Fatalf("New mongoDB error: %s\n", err.Error())
	}

	rdb, err := client.NewRedis(logger.L(), config.Redis.Addr, config.Redis.Password, config.Redis.MaxRetry, config.Redis.DB)
	if err != nil {
		logger.L().Sugar().Fatalf("New NewRedis error: %s\n", err.Error())
	}

	cardSpendingAlertHandler := cardspendingalert.NewCardSpendingAlertHandler(logger.L(), amqpProducer, db, rdb, time.Duration(config.Redis.Expiration)*time.Minute, config.Mongo.Collection)
	cardSpendingAlertHandler = prometheusMiddleware(cardSpendingAlertHandler)
	cardSpendingAlertHandler = nethttp.Middleware(
		tracer,
		cardSpendingAlertHandler,
		nethttp.OperationNameFunc(func(r *http.Request) string {
			return "HTTP " + r.Method + ":" + r.URL.Path
		}),
	)
	m := map[string]http.Handler{
		"/card": cardSpendingAlertHandler,
	}

	q := map[string]http.Handler{
		"/metrics":       promhttp.Handler(),
		"/health/readyz": cardspendingalert.NewHealthCheckHandler(logger.L(), mdb, rdb, amqpSession, config.Amqp.Addr, "readyz"),
		"/health/livez":  cardspendingalert.NewHealthCheckHandler(logger.L(), mdb, rdb, amqpSession, config.Amqp.Addr, "livez"),
	}

	ctx, cancel := context.WithCancel(context.Background())
	srv := protocol.ServeHTTP(ctx, cancel, logger.L(), config.Server.Addr, config.Server.Readtimeout, config.Server.Writetimeout, config.Server.Idletimeout, m, q)
	graceful(ctx, cancel, logger.L(), srv, amqpSession, amqpSender, db, rdb)
}

var (
	reqCnt = promauto.NewCounterVec(
		prometheus.CounterOpts{
			Name: "http_requests_total",
			Help: "How many HTTP requests processed, partitioned by status code and HTTP method.",
		},
		[]string{"code", "method", "host", "url"},
	)
	reqDur = promauto.NewHistogramVec(
		prometheus.HistogramOpts{
			Name: "http_request_duration_seconds",
			Help: "The HTTP request latencies in seconds.",
		},
		[]string{"code", "method", "url"},
	)
)

type StatusRecorder struct {
	http.ResponseWriter
	Status int
}

func (r *StatusRecorder) WriteHeader(status int) {
	r.Status = status
	r.ResponseWriter.WriteHeader(status)
}

func prometheusMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		recorder := &StatusRecorder{
			ResponseWriter: w,
			Status:         200,
		}
		next.ServeHTTP(recorder, r)
		elapsed := float64(time.Since(start)) / float64(time.Second)
		status := strconv.Itoa(recorder.Status)
		reqDur.WithLabelValues(status, r.Method, r.URL.Path).Observe(elapsed)
		reqCnt.WithLabelValues(status, r.Method, r.Host, r.URL.Path).Inc()
	})
}

func graceful(ctx context.Context, cancel context.CancelFunc, logger *zap.Logger, srv *fasthttp.Server, session *amqp.Session, sender *amqp.Sender, db *mongo.Database, redis *redis.Client) {
	sigterm := make(chan os.Signal, 1)
	signal.Notify(sigterm, syscall.SIGINT, syscall.SIGTERM)

	select {
	case <-ctx.Done():
		logger.Info("terminating: context cancelled")
	case <-sigterm:
		logger.Info("terminating: via signal")
	}
	cancel()

	logger.Info("Shutdown signal received.")
	client.CloseRedis(logger, redis)
	client.CloseMongoDB(logger, context.Background(), db)
	client.CloseSender(logger, context.Background(), sender)
	protocol.CloseSession(logger, context.Background(), session)
	protocol.CloseHttpServer(logger, srv)
	time.Sleep(1 * time.Second)
	logger.Info("Server gracefully stopped.")
	os.Exit(0)
}
