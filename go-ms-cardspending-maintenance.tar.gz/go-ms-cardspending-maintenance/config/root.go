package config

import "time"

type Root struct {
	Server ServerConfig `mapstructure:"server"`
	Amqp   AmqpConfig   `mapstructure:"amqp"`
	Mongo  MongoConfig  `mapstructure:"mongo"`
	Redis  RedisConfig  `mapstructure:"redis"`
}

type ServerConfig struct {
	Addr         string        `mapstructure:addr`
	Writetimeout time.Duration `mapstructure:writetimeout`
	Readtimeout  time.Duration `mapstructure:readtimeout`
	Idletimeout  time.Duration `mapstructure:idletimeout`
}
type AmqpConfig struct {
	Host       string        `mapstructure:"host"`
	Port       string        `mapstructure:"port"`
	User       string        `mapstructure:"username"`
	Password   string        `mapstructure:"password"`
	Addr       string        `mapstructure:"addr"`
	RetryCount int           `mapstructure:"retrycount"`
	RetrySleep time.Duration `mapstructure:"retrysleep"`
}

type MongoConfig struct {
	Uri        string `mapstructure:"uri"`
	Database   string `mapstructure:"database"`
	MinConPool uint64 `mapstructure:"minConPool"`
	MaxConPool uint64 `mapstructure:"maxConPool"`
	Collection string `mapstructure:"collection"`
}

type RedisConfig struct {
	Addr       string `mapstructure:"addr"`
	Password   string `mapstructure:"password"`
	MaxRetry   int    `mapstructure:"maxRetry"`
	Expiration int    `mapstructure:"expiration"`
	DB         int    `mapstructure:"DB"`
}
