package config

import (
	"time"

	_ "time/tzdata"

	"go.uber.org/zap"
)

func SetEnvTimezone(logger *zap.Logger) {
	ict, err := time.LoadLocation("Asia/Bangkok")
	if err != nil {
		logger.Sugar().Errorf("error loading location 'Asia/Bangkok': %v\n", err)
	}
	time.Local = ict
	logger.Sugar().Infof("Local time zone %v", time.Now().In(ict))
}
