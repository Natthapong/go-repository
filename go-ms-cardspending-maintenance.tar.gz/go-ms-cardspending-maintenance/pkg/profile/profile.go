package profile

import (
	"context"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
)

type Profile struct {
	ProfileID                  string   `json:"profileID,omitempty" bson:"_id,omitempty"`
	MobileNo                   string   `json:"mobileNo" bson:"mobileNo"`
	Cis                        string   `json:"cis" bson:"cis"`
	CitizenID                  string   `json:"citizenID" bson:"citizenID"`
	Language                   string   `json:"language" bson:"language"`
	PlatformID                 string   `json:"platformID" bson:"platformID"`
	RegisterStatus             string   `json:"registerStatus" bson:"registerStatus"`
	PushToken                  string   `json:"pushToken" bson:"pushToken"`
	Notification               bool     `json:"notification" bson:"notification"`
	NotificationMessagePreview bool     `json:"notificationMessagePreview" bson:"notificationMessagePreview"`
	UnFollowing                []string `json:"unFollowing" bson:"unFollowing"`
	CurrentProfileType         string   `json:"currentProfileType" bson:"currentProfileType"`
}

type ProfileRepo struct {
	l  *zap.Logger
	db *mongo.Database
	c  *mongo.Collection
}

func NewProfileRepo(logger *zap.Logger, db *mongo.Database) *ProfileRepo {
	return &ProfileRepo{logger, db, db.Collection("profile")}
}

func (p *ProfileRepo) GetByMobileNo(ctx context.Context, mobileNo string) []Profile {
	profiles := make([]Profile, 0)
	filter := bson.M{
		"mobileNo": mobileNo,
	}
	cur, err := p.c.Find(ctx, filter)
	if err != nil {
		p.l.Error(err.Error())
	}
	if err = cur.All(ctx, &profiles); err != nil {
		p.l.Error(err.Error())
	}
	return profiles
}
