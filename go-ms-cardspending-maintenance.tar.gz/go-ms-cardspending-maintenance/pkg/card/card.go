package card

import (
	"context"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
)

type Card struct {
	CardID       string `json:"CardID,omitempty" bson:"_id,omitempty"`
	CardNoEncpt  string `json:"cardNoEncpt" bson:"cardNoEncpt"`
	CardNoHash   string `json:"cardNoHash" bson:"cardNoHash"`
	CardNoMasked string `json:"cardNoMasked" bson:"cardNoMasked"`
	MobileNo     string `json:"mobileNo" bson:"mobileNo"`
	CardType     string `json:"type" bson:"type"`
}

type CardRepo struct {
	l  *zap.Logger
	db *mongo.Database
	c  *mongo.Collection
}

func NewCardRepo(logger *zap.Logger, db *mongo.Database, collname string) *CardRepo {
	return &CardRepo{logger, db, db.Collection(collname)}
}

func (c *CardRepo) GetByCardNoEncpt(ctx context.Context, cardNoEncpt string) ([]Card, error) {
	cards := make([]Card, 0)
	filter := bson.M{
		"cardNoEncpt": cardNoEncpt,
	}
	cur, err := c.c.Find(ctx, filter)
	if err != nil {
		c.l.Error(err.Error())
		return cards, err
	}
	defer cur.Close(ctx)
	if err = cur.All(ctx, &cards); err != nil {
		c.l.Error(err.Error())
	}
	if err := cur.Err(); err != nil {
		c.l.Error(err.Error())
	}
	return cards, nil
}
