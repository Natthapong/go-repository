package cardspendingalert

import (
	"encoding/json"
	"net/http"

	"github.com/Azure/go-amqp"
	"github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
	"ucenter.dev/service/client"
	"ucenter.dev/service/protocol"
)

type HealthCheck struct {
	l      *zap.Logger
	mdb    *mongo.Client
	rdb    *redis.Client
	s      *amqp.Session
	target string
	typez  string
}

func NewHealthCheckHandler(logger *zap.Logger, mdb *mongo.Client, rdb *redis.Client, session *amqp.Session, addr, typez string) *HealthCheck {
	return &HealthCheck{
		l:      logger,
		mdb:    mdb,
		rdb:    rdb,
		s:      session,
		target: addr,
		typez:  typez,
	}
}

func (c *HealthCheck) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	c.l.Debug("Health Check handler server HTTP.")

	var httpStatus int
	var status string
	var checks []HealthChkRes

	if c.typez == "livez" {
		ms, mdb := c.checkMongoDB()
		rs, rdb := c.checkRedis()
		qs, amq := c.checkAmqp()

		checks = make([]HealthChkRes, 3)
		checks[0] = mdb
		checks[1] = rdb
		checks[2] = amq

		if ms && rs && qs {
			status = "UP"
			httpStatus = http.StatusOK
		} else {
			status = "DOWN"
			httpStatus = http.StatusBadRequest
		}
	} else if c.typez == "readyz" {
		checks = make([]HealthChkRes, 1)
		checks[0].ID = "http-server-running"
		checks[0].Status = "UP"

		status = "UP"
		httpStatus = http.StatusOK
	}

	data := HealthChkRes{Status: status, Checks: checks}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(httpStatus)
	json.NewEncoder(w).Encode(data)
}

func (c *HealthCheck) checkMongoDB() (bool, HealthChkRes) {
	status := "DOWN"
	res := client.PingMongoDB(c.l, c.mdb)
	if res {
		status = "UP"
	}
	return res, HealthChkRes{ID: "mongo", Status: status}
}

func (c *HealthCheck) checkRedis() (bool, HealthChkRes) {
	status := "DOWN"
	res := client.PingRedis(c.l, c.rdb)
	if res {
		status = "UP"
	}
	return res, HealthChkRes{ID: "redis", Status: status}
}

func (c *HealthCheck) checkAmqp() (bool, HealthChkRes) {
	status := "DOWN"
	res := protocol.CheckSender(c.l, c.s, c.target)
	if res {
		status = "UP"
	}
	return res, HealthChkRes{ID: "AMQP Sender", Status: status}
}
