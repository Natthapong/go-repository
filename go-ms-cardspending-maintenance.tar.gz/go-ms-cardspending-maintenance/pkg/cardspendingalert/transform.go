package cardspendingalert

import (
	"errors"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"

	"github.com/dustin/go-humanize"
)

const (
	DATE_TIME_FORMATTER_HEADER           = "20060102150405"
	DATE_TIME_FORMATTER_ACTIONEXPIREDATE = "2006-01-02T15:04:05.000"
	DATE_TIME_FORMATTER_TXN_DT_IN        = "2006-01-02"
	DATE_TIME_FORMATTER_TXN_DT_OUT       = "2 Jan 06"
	DATE_TIME_FORMATTER_TXN_TM_IN        = "15:04:05"
	DATE_TIME_FORMATTER_TXN_TM_TH_OUT    = "15:04"
	DATE_TIME_FORMATTER_TXN_TM_EN_OUT    = "3:04 PM"
)

var shortMonthTH = []string{
	"ม.ค.",
	"ก.พ.",
	"มี.ค.",
	"เม.ย.",
	"พ.ค.",
	"มิ.ย.",
	"ก.ค.",
	"ส.ค.",
	"ก.ย.",
	"ต.ค.",
	"พ.ย.",
	"ธ.ค.",
}

func FormatTxnDt(dt string, lang string) string {
	if lang == "TH" {
		t1, err := time.Parse(DATE_TIME_FORMATTER_TXN_DT_IN, dt)
		if err == nil {
			t2 := time.Now().AddDate(543, 0, 0)
			return FormatDate(t1, "2 ") + FormatShortMonthTH(t1.Month()) + FormatDate(t2, " 06")
		}
	} else {
		t, err := time.Parse(DATE_TIME_FORMATTER_TXN_DT_IN, dt)
		if err == nil {
			return FormatDate(t, DATE_TIME_FORMATTER_TXN_DT_OUT)
		}
	}
	return errors.New("Error format TxnDt").Error()
}

func FormatShortMonthTH(m time.Month) string {
	return shortMonthTH[m-1]
}
func FormatTxnTm(tm string, lang string) string {
	t, err := time.Parse(DATE_TIME_FORMATTER_TXN_TM_IN, tm)
	if err == nil {
		if lang == "TH" {
			return FormatDate(t, DATE_TIME_FORMATTER_TXN_TM_TH_OUT) + " น."
		} else if lang == "EN" {
			return FormatDate(t, DATE_TIME_FORMATTER_TXN_TM_EN_OUT)
		}
	}
	return errors.New("Error format TxnTm").Error()
}

func FormatCurrency(ccy string, lang string) string {
	if ccy == "THB" && lang == "TH" {
		return "บาท"
	}
	return ccy
}

func FormatAmount(txnAmt float64, exp int) (string, error) {
	amt := txnAmt / math.Pow10(exp-2)
	fmtAmt := strconv.FormatFloat(amt, 'f', exp, 64)
	splitAmt := strings.Split(fmtAmt, ".")
	if len(splitAmt) > 1 {
		significand, err := strconv.ParseInt(splitAmt[0], 10, 64)
		if err != nil {
			return splitAmt[0], err
		}
		return fmt.Sprintf("%s.%s", humanize.Comma(significand), splitAmt[1]), nil
	} else {
		significand, err := strconv.ParseInt(splitAmt[0], 10, 64)
		if err != nil {
			return splitAmt[0], err
		}
		return fmt.Sprintf("%s", humanize.Comma(significand)), nil
	}
}

func FormatDate(date time.Time, format string) string {
	return date.Format(format)
}

func FormatID(uid uint32) string {
	return fmt.Sprintf("%d", uid)
}

func FormatCardNoMasked(cardNoMasked string) string {
	return fmt.Sprintf("xxxx-xxxx-xxxx-%s", cardNoMasked[len(cardNoMasked)-4:])
}
