package cardspendingalert

import (
	"testing"
)

func TestFormatTxnDt(t *testing.T) {
	type args struct {
		dt   string
		lang string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			"success",
			args{dt: "2021-01-04", lang: "TH"},
			"4 ม.ค. 64",
		},
		{
			"fail",
			args{dt: "20210104", lang: "EN"},
			"Error format TxnDt",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := FormatTxnDt(tt.args.dt, tt.args.lang); got != tt.want {
				t.Errorf("FormatTxnDt() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFormatCardNoMasked(t *testing.T) {
	type args struct {
		cardNoMasked string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			"success",
			args{cardNoMasked: "441770******4223"},
			"xxxx-xxxx-xxxx-4223",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := FormatCardNoMasked(tt.args.cardNoMasked); got != tt.want {
				t.Errorf("FormatCardNoMasked() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFormatAmount(t *testing.T) {
	type args struct {
		txnAmt float64
		exp    int
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			"success",
			args{1.00, 0},
			"100",
			false,
		},
		{
			"success",
			args{10.00, 0},
			"1,000",
			false,
		},
		{
			"success",
			args{1.01, 0},
			"101",
			false,
		},
		{
			"success",
			args{10.01, 0},
			"1,001",
			false,
		},
		{
			"success",
			args{10.00, 1},
			"100.0",
			false,
		},
		{
			"success",
			args{100.00, 1},
			"1,000.0",
			false,
		},
		{
			"success",
			args{10.01, 1},
			"100.1",
			false,
		},
		{
			"success",
			args{100.01, 1},
			"1,000.1",
			false,
		},
		{
			"success",
			args{123.00, 2},
			"123.00",
			false,
		},
		{
			"success",
			args{1234.00, 2},
			"1,234.00",
			false,
		},
		{
			"success",
			args{123.01, 2},
			"123.01",
			false,
		},
		{
			"success",
			args{1234.01, 2},
			"1,234.01",
			false,
		},
		{
			"success",
			args{123.00, 3},
			"12.300",
			false,
		},
		{
			"success",
			args{12340.00, 3},
			"1,234.000",
			false,
		},
		{
			"success",
			args{123.01, 3},
			"12.301",
			false,
		},
		{
			"success",
			args{12340.01, 3},
			"1,234.001",
			false,
		},
		{
			"success",
			args{123.00, 4},
			"1.2300",
			false,
		},
		{
			"success",
			args{123400.00, 4},
			"1,234.0000",
			false,
		},
		{
			"success",
			args{123.01, 4},
			"1.2301",
			false,
		},
		{
			"success",
			args{123400.01, 4},
			"1,234.0001",
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := FormatAmount(tt.args.txnAmt, tt.args.exp)
			if (err != nil) != tt.wantErr {
				t.Errorf("FormatAmount() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("FormatAmount() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFormatTxnTm(t *testing.T) {
	type args struct {
		tm   string
		lang string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			"success",
			args{"06:29:05", "TH"},
			"06:29 น.",
		},
		{
			"success",
			args{"15:29:05", "TH"},
			"15:29 น.",
		},
		{
			"success",
			args{"06:29:05", "EN"},
			"6:29 AM",
		},
		{
			"success",
			args{"15:29:05", "EN"},
			"3:29 PM",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := FormatTxnTm(tt.args.tm, tt.args.lang); got != tt.want {
				t.Errorf("FormatTxnTm() = %v, want %v", got, tt.want)
			}
		})
	}
}
