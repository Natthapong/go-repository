package cardspendingalert

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/go-playground/validator/v10"
	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"github.com/opentracing/opentracing-go"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
	"ucenter.dev/service/client"
	"ucenter.dev/service/pkg/card"
	"ucenter.dev/service/pkg/profile"
)

const (
	APP_ID              = "715"
	SCORE               = 999
	HIDDEN              = false
	CAMPAIGN_CODE       = "CreditCardSpending"
	HASHTAG             = "#creditcardspending"
	CONTENT_CATEGORY    = "creditCardTxn"
	COMMAND             = "DUMMY_CONTENT"
	LANDING_TEMPLATE_ID = "Alert_TxnCard"
	FALSE_FLAG          = false
	TRUE_FLAG           = true
	ZERO_VALUE          = 0
	LANG_TH             = "TH"
	LANG_EN             = "EN"
)

type CardSpendingAlertHandler struct {
	l   *zap.Logger
	p   *client.Producer
	db  *mongo.Database
	rdb *redis.Client
	exp time.Duration
	col string
}

var validate *validator.Validate

func init() {
	validate = validator.New()
}

func NewCardSpendingAlertHandler(logger *zap.Logger, producer *client.Producer, mongoDB *mongo.Database, rdb *redis.Client, expire time.Duration, collection string) http.Handler {
	return &CardSpendingAlertHandler{l: logger, p: producer, db: mongoDB, rdb: rdb, exp: expire, col: collection}
}

func (c *CardSpendingAlertHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	c.l.Debug("Card spending alert handler server HTTP.")
	var req CardReq
	r.Body = http.MaxBytesReader(w, r.Body, 1048576)
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		errMsg := fmt.Sprintf("Decoder Error %s", err.Error())
		response(c.l, w, http.StatusBadRequest, errMsg, "")
		return
	}
	defer r.Body.Close()

	msgID := req.MsgID
	msgIDErr := validate.Var(msgID, "required")
	if msgIDErr != nil {
		errMsg := fmt.Sprintf("Error msgID is required.")
		response(c.l, w, http.StatusBadRequest, errMsg, msgID)
		return
	}

	validateErr := validate.Struct(req)
	if validateErr != nil {
		response(c.l, w, http.StatusBadRequest, validateErr.Error(), msgID)
		return
	}

	if c.IsDupTxn(c.l, r.Context(), msgID) {
		errMsg := fmt.Sprintf("Error duplicate message.")
		response(c.l, w, http.StatusBadRequest, errMsg, msgID)
		return
	}

	err := c.SaveTxn(c.l, r.Context(), msgID, c.exp)
	if err != nil {
		errMsg := fmt.Sprintf("Error set data into Redis.[%s]", err.Error())
		response(c.l, w, http.StatusBadRequest, errMsg, msgID)
		return
	}

	cards, err := card.NewCardRepo(c.l, c.db, c.col).GetByCardNoEncpt(r.Context(), req.CardNoEncpt)
	if err != nil {
		errMsg := fmt.Sprintf("Error get card from mongoDB.")
		response(c.l, w, http.StatusBadRequest, errMsg, msgID)
		return
	}
	if len(cards) == 0 {
		errMsg := fmt.Sprintf("Card not found.")
		response(c.l, w, http.StatusBadRequest, errMsg, msgID)
		return
	}
	for i, card := range cards {
		c.l.Sugar().Debugf("card no.%d", i+1)
		profiles := profile.NewProfileRepo(c.l, c.db).GetByMobileNo(r.Context(), card.MobileNo)
		if len(profiles) == 0 {
			errMsg := fmt.Sprintf("Profile not found.")
			c.l.Warn(errMsg, zap.String("msgID", msgID), zap.String("mobileNo", card.MobileNo))
			continue
		}
		header := setHeader(profiles[0])
		feeds := setFeeds(c.l, card, profiles, req)
		amqpMsg := AMQMessage{
			Header: header,
			Data:   AMQMessageData{ContentFeeds: feeds},
		}
		data, err := json.Marshal(amqpMsg)
		if err != nil {
			errMsg := fmt.Sprintf("Error marshal data to produce message.")
			c.l.Warn(errMsg, zap.String("msgID", msgID), zap.String("mobileNo", card.MobileNo))
			continue
		}
		if err := c.p.Produce(r.Context(), data, nil); err != nil {
			errMsg := fmt.Sprintf("Error produce message.")
			c.l.Warn(errMsg, zap.String("msgID", msgID), zap.String("mobileNo", card.MobileNo))
			continue
		}
	}
	response(c.l, w, http.StatusAccepted, http.StatusText(http.StatusAccepted), msgID)
}

func setHeader(p profile.Profile) AMQMessageHeader {
	header := AMQMessageHeader{
		MobileNo:        p.MobileNo,
		AppID:           APP_ID,
		RequestUniqueID: FormatID(uuid.New().ID()),
		RequestDateTime: FormatDate(time.Now(), DATE_TIME_FORMATTER_HEADER),
		CorrID:          FormatID(uuid.New().ID()),
		Language:        p.Language,
	}
	return header
}

func setFeeds(logger *zap.Logger, c card.Card, profiles []profile.Profile, cRq CardReq) []ContentFeed {
	feeds := make([]ContentFeed, 0)
	txnAmt, err := FormatAmount(cRq.TxnAmt, cRq.CcyNbrDcm)
	if err != nil {
		logger.Sugar().Errorf("Error format amount: %s [%s]", err.Error(), txnAmt)
	}
	ccyAbrTH := FormatCurrency(cRq.CcyAbr, LANG_TH)
	ccyAbrEN := FormatCurrency(cRq.CcyAbr, LANG_EN)
	cardNoMasked := FormatCardNoMasked(cRq.CardNoMasked)
	cardNoAcptCity := fmt.Sprintf("%s %s", cRq.CardNoAcptCity, cRq.CardNoAcptCty)
	cardNoAcptNm := cRq.CardNoAcptNm
	txnDtTH := FormatTxnDt(cRq.TxnDt, LANG_TH)
	txnDtEN := FormatTxnDt(cRq.TxnDt, LANG_EN)
	txnTmTH := FormatTxnTm(cRq.TxnTm, LANG_TH)
	tnxTmEN := FormatTxnTm(cRq.TxnTm, LANG_EN)
	ahrCd := cRq.AhrCd
	for _, profile := range profiles {
		var feed ContentFeed
		feed.FeedID = primitive.NewObjectID().Hex()
		feed.MobileNo = profile.MobileNo
		feed.Notification = profile.Notification
		feed.NotificationMessagePreview = profile.NotificationMessagePreview
		feed.Platform = profile.PlatformID
		feed.PushToken = profile.PushToken
		feed.ProfileID = profile.ProfileID
		feed.Language = profile.Language
		feed.Score = float64(SCORE)
		feed.Hidden = FALSE_FLAG
		feed.CampaignCode = CAMPAIGN_CODE
		feed.Hashtag = HASHTAG
		feed.TrackingID = ahrCd
		feed.ContentCategory = CONTENT_CATEGORY
		feed.Command = COMMAND
		feed.ActionExpireDate = setActExpDt()
		feed.LandingTemplateID = LANDING_TEMPLATE_ID
		feed.IdingFlag = TRUE_FLAG
		feed.LandingFlag = TRUE_FLAG
		if contains(profile.UnFollowing, CONTENT_CATEGORY) {
			feed.IdingFlag = FALSE_FLAG
			feed.LandingFlag = FALSE_FLAG
		}
		feed.ImodeFlag = FALSE_FLAG
		feed.IotherType = ZERO_VALUE
		feed.AuthType = ZERO_VALUE
		feed.BadgeCount = ZERO_VALUE
		feed.IdingInfo = IdingInfo{
			IdingNotiMsgTopicTH: setTopic(cRq.AprvF, LANG_TH),
			IdingNotiMsgTopicEN: setTopic(cRq.AprvF, LANG_EN),
			IdingNotiMsgBodyTH:  fmt.Sprintf("หมายเลขบัตร %s จำนวนเงิน %s %s ที่ %s", cardNoMasked, txnAmt, ccyAbrTH, cardNoAcptNm),
			IdingNotiMsgBodyEN:  fmt.Sprintf("Card No. %s Amount %s %s at %s", cardNoMasked, txnAmt, ccyAbrEN, cardNoAcptNm),
			IdingImgTH:          "#[image/logo_kbank_56]",
			IdingImgEN:          "#[image/logo_kbank_56]",
			IdingMsgTopicTH:     setTopic(cRq.AprvF, LANG_TH),
			IdingMsgTopicEN:     setTopic(cRq.AprvF, LANG_EN),
			IdingMsgBodyTH:      fmt.Sprintf("หมายเลขบัตร %s \nที่ %s", cardNoMasked, cardNoAcptNm),
			IdingMsgBodyEN:      fmt.Sprintf("Card No. %s \nat %s", cardNoMasked, cardNoAcptNm),
			IdingMsgHighLightTH: fmt.Sprintf("%s %s", txnAmt, ccyAbrTH),
			IdingMsgHighLightEN: fmt.Sprintf("%s %s", txnAmt, ccyAbrEN),
		}
		feed.ImodeInfo = ImodeInfo{}
		feed.LandingInfo = LandingInfo{
			LandingPageAuthorTH:     "KBank",
			LandingPageAuthorEN:     "KBank",
			LandingPageAuthorIconTH: "#[image/logo_kbank_56]",
			LandingPageAuthorIconEN: "#[image/logo_kbank_56]",
			LandingPageMsgTopicTH:   setTopic(cRq.AprvF, LANG_TH),
			LandingPageMsgTopicEN:   setTopic(cRq.AprvF, LANG_EN),
			LandingPageMsgBodyTH: LandingPageMsgBodyTH{
				Left01:  "จ่าย/กดที่: ",
				Left02:  "วันที่: ",
				Left03:  "เวลา: ",
				Left04:  "หมายเลขบัตร ",
				Left05:  "รหัสอนุมัติ: ",
				Left06:  "จำนวนเงิน: ",
				Right01: fmt.Sprintf("%s %s", cardNoAcptNm, cardNoAcptCity),
				Right02: fmt.Sprintf("%s", txnDtTH),
				Right03: fmt.Sprintf("%s", txnTmTH),
				Right04: fmt.Sprintf("%s", cardNoMasked),
				Right05: fmt.Sprintf("%s", ahrCd),
				Right06: fmt.Sprintf("%s %s", txnAmt, ccyAbrTH),
			},
			LandingPageMsgBodyEN: LandingPageMsgBodyEN{
				Left01:  "Pay/Withdraw at: ",
				Left02:  "Date: ",
				Left03:  "Time: ",
				Left04:  "Card No: ",
				Left05:  "Approval Code: ",
				Left06:  "Amount: ",
				Right01: fmt.Sprintf("%s %s", cardNoAcptNm, cardNoAcptCity),
				Right02: fmt.Sprintf("%s", txnDtEN),
				Right03: fmt.Sprintf("%s", tnxTmEN),
				Right04: fmt.Sprintf("%s", cardNoMasked),
				Right05: fmt.Sprintf("%s", ahrCd),
				Right06: fmt.Sprintf("%s %s", txnAmt, ccyAbrEN),
			},
		}
		feeds = append(feeds, feed)
		logger.Debug("Append", zap.String("msgID", cRq.MsgID), zap.String("feedID", feed.FeedID))
	}
	return feeds
}

func contains(s []string, e string) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

func setActExpDt() string {
	t := time.Now().AddDate(0, 1, 0)
	return FormatDate(t, DATE_TIME_FORMATTER_ACTIONEXPIREDATE)
}

func setTopic(aprvF, lang string) string {
	if aprvF == "Y" && lang == LANG_TH {
		return fmt.Sprintf("%s", "รายการใช้บัตร")
	}
	if aprvF == "Y" && lang == LANG_EN {
		return fmt.Sprintf("%s", "Card Transaction")
	}
	if aprvF == "N" && lang == LANG_TH {
		return fmt.Sprintf("%s", "รายการยกเลิก")
	}
	if aprvF == "N" && lang == LANG_EN {
		return fmt.Sprintf("%s", "Void Transaction")
	}
	return fmt.Sprintf("%s", "N/A")
}

func (c *CardSpendingAlertHandler) IsDupTxn(logger *zap.Logger, ctx context.Context, msgID string) bool {
	ret := false
	val, err := c.rdb.Get(ctx, msgID).Result()
	if err == redis.Nil {
		ret = false
	} else if err != nil {
		logger.Sugar().Errorf("Error get data from Redis: %s", err.Error())
		ret = false
	} else if val != "" {
		ret = true
	}
	return ret
}

func (c *CardSpendingAlertHandler) SaveTxn(logger *zap.Logger, ctx context.Context, msgID string, expiration time.Duration) error {
	sp, ctx := opentracing.StartSpanFromContext(ctx, "SaveTxn")
	defer sp.Finish()
	return c.rdb.Set(ctx, msgID, msgID, expiration).Err()
}

func response(logger *zap.Logger, w http.ResponseWriter, httpStatus int, result, msgID string) {
	if httpStatus == http.StatusAccepted {
		logger.Info(result, zap.String("msgID", msgID))
	} else {
		logger.Error(result, zap.String("msgID", msgID))
	}
	data := CardRes{MsgID: msgID, Result: result}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(httpStatus)
	json.NewEncoder(w).Encode(data)
}
