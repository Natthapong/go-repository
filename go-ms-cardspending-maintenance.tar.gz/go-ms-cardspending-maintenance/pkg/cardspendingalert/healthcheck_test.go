package cardspendingalert

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/Azure/go-amqp"
	"github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/zap"
	"ucenter.dev/service/logger"
)

func TestHealthCheck_ServeHTTP(t *testing.T) {
	type fields struct {
		l      *zap.Logger
		mdb    *mongo.Client
		rdb    *redis.Client
		s      *amqp.Session
		target string
		typez  string
	}
	type args struct {
		w http.ResponseWriter
		r *http.Request
	}
	tests := []struct {
		name       string
		fields     fields
		args       args
		method     string
		uri        string
		statusCode int
		want       string
	}{
		{
			"readiness healthcheck success",
			fields{logger.L(), &mongo.Client{}, &redis.Client{}, &amqp.Session{}, "", "readyz"},
			args{},
			http.MethodGet,
			"/health/readyz",
			200,
			strings.TrimSpace(`{"status":"UP","checks":[{"status":"UP","id":"http-server-running"}]}`),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &HealthCheck{
				l:      tt.fields.l,
				mdb:    tt.fields.mdb,
				rdb:    tt.fields.rdb,
				s:      tt.fields.s,
				target: tt.fields.target,
				typez:  tt.fields.typez,
			}
			request := httptest.NewRequest(tt.method, tt.uri, nil)
			responseRecorder := httptest.NewRecorder()

			c.ServeHTTP(responseRecorder, request)

			if responseRecorder.Code != tt.statusCode {
				t.Errorf("Want status '%d', got '%d'", tt.statusCode, responseRecorder.Code)
			}

			if strings.TrimSpace(responseRecorder.Body.String()) != tt.want {
				t.Errorf("Want '%s', got '%s'", tt.want, responseRecorder.Body)
			}
		})
	}
}
