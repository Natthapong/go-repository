package cardspendingalert

type (
	AMQMessage struct {
		Header AMQMessageHeader `json:"header"`
		Data   AMQMessageData   `json:"data"`
	}

	AMQMessageHeader struct {
		MobileNo        string `json:"mobileNo"`
		AppID           string `json:"appId"`
		RequestUniqueID string `json:"requestUniqueId"`
		RequestDateTime string `json:"requestDateTime"`
		CorrID          string `json:"corrId"`
		Language        string `json:"language"`
	}

	AMQMessageData struct {
		ContentFeeds []ContentFeed `json:"contentFeedList"`
	}

	ContentFeed struct {
		MobileNo                   string                 `json:"mobileNo"`
		FeedID                     string                 `json:"feedID"`
		Notification               bool                   `json:"notification"`
		NotificationMessagePreview bool                   `json:"notificationMessagePreview"`
		Platform                   string                 `json:"platform"`
		PushToken                  string                 `json:"pushToken"`
		ProfileID                  string                 `json:"profileID"`
		Language                   string                 `json:"language"`
		Score                      float64                `json:"score"`
		Hidden                     bool                   `json:"hidden"`
		CampaignCode               string                 `json:"campaignCode"`
		Hashtag                    string                 `json:"hashtag"`
		TrackingID                 string                 `json:"trackingID"`
		ContentCategory            string                 `json:"contentCategory"`
		Command                    string                 `json:"command"`
		Parameter                  map[string]interface{} `json:"parameter"`
		ActionExpireDate           string                 `json:"actionExpireDate"`
		LandingTemplateID          string                 `json:"landingTemplateID"`
		LandingButtonLabelSet      string                 `json:"landingButtonLabelSet"`
		ImodeFlag                  bool                   `json:"imodeFlag"`
		IdingFlag                  bool                   `json:"idingFlag"`
		LandingFlag                bool                   `json:"landingFlag"`
		IotherType                 int32                  `json:"iotherType"`
		AuthType                   int32                  `json:"authType"`
		BadgeCount                 int32                  `json:"badgeCount"`
		IdingInfo                  IdingInfo              `json:"idingInfo"`
		ImodeInfo                  ImodeInfo              `json:"imodeInfo"`
		LandingInfo                LandingInfo            `json:"landingInfo"`
	}

	IdingInfo struct {
		IdingNotiImgTH      string `json:"idingNotiImgTH"`
		IdingNotiImgEN      string `json:"idingNotiImgEN"`
		IdingNotiMsgTopicTH string `json:"idingNotiMsgTopicTH"`
		IdingNotiMsgTopicEN string `json:"idingNotiMsgTopicEN"`
		IdingNotiMsgBodyTH  string `json:"idingNotiMsgBodyTH"`
		IdingNotiMsgBodyEN  string `json:"idingNotiMsgBodyEN"`
		IdingImgTH          string `json:"idingImgTH"`
		IdingImgEN          string `json:"idingImgEN"`
		IdingMsgTopicTH     string `json:"idingMsgTopicTH"`
		IdingMsgTopicEN     string `json:"idingMsgTopicEN"`
		IdingMsgBodyTH      string `json:"idingMsgBodyTH"`
		IdingMsgBodyEN      string `json:"idingMsgBodyEN"`
		IdingMsgHighLightTH string `json:"idingMsgHighLightTH"`
		IdingMsgHighLightEN string `json:"idingMsgHighLightEN"`
		IdingMsgFooterTH    string `json:"idingMsgFooterTH"`
		IdingMsgFooterEN    string `json:"idingMsgFooterEN"`
	}

	ImodeInfo struct {
		ImodeImgTH          string `json:"imodeImgTH"`
		ImodeImgEN          string `json:"imodeImgEN"`
		ImodeBadgeTH        string `json:"imodeBadgeTH"`
		ImodeBadgeEN        string `json:"imodeBadgeEN"`
		ImodeMsgTopicTH     string `json:"imodeMsgTopicTH"`
		ImodeMsgTopicEN     string `json:"imodeMsgTopicEN"`
		ImodeMsgBodyTH      string `json:"imodeMsgBodyTH"`
		ImodeMsgBodyEN      string `json:"imodeMsgBodyEN"`
		ImodeMsgHighLightTH string `json:"imodeMsgHighLightTH"`
		ImodeMsgHighLightEN string `json:"imodeMsgHighLightEN"`
		ImodeMsgFooterTH    string `json:"imodeMsgFooterTH"`
		ImodeMsgFooterEN    string `json:"imodeMsgFooterEN"`
	}

	LandingInfo struct {
		LandingPageImgTH        []string             `json:"landingPageImgTH"`
		LandingPageImgEN        []string             `json:"landingPageImgEN"`
		LandingPageAuthorTH     string               `json:"landingPageAuthorTH"`
		LandingPageAuthorEN     string               `json:"landingPageAuthorEN"`
		LandingPageAuthorIconTH string               `json:"landingPageAuthorIconTH"`
		LandingPageAuthorIconEN string               `json:"landingPageAuthorIconEN"`
		LandingPageMsgTopicTH   string               `json:"landingPageMsgTopicTH"`
		LandingPageMsgTopicEN   string               `json:"landingPageMsgTopicEN"`
		LandingPageMsgBodyTH    LandingPageMsgBodyTH `json:"landingPageMsgBodyTH"`
		LandingPageMsgBodyEN    LandingPageMsgBodyEN `json:"landingPageMsgBodyEN"`
	}

	LandingPageMsgBodyTH struct {
		Left01  string `json:"left01"`
		Left02  string `json:"left02"`
		Left03  string `json:"left03"`
		Left04  string `json:"left04"`
		Left05  string `json:"left05"`
		Left06  string `json:"left06"`
		Right01 string `json:"right01"`
		Right02 string `json:"right02"`
		Right03 string `json:"right03"`
		Right04 string `json:"right04"`
		Right05 string `json:"right05"`
		Right06 string `json:"right06"`
	}

	LandingPageMsgBodyEN struct {
		Left01  string `json:"left01"`
		Left02  string `json:"left02"`
		Left03  string `json:"left03"`
		Left04  string `json:"left04"`
		Left05  string `json:"left05"`
		Left06  string `json:"left06"`
		Right01 string `json:"right01"`
		Right02 string `json:"right02"`
		Right03 string `json:"right03"`
		Right04 string `json:"right04"`
		Right05 string `json:"right05"`
		Right06 string `json:"right06"`
	}
)

type CardReq struct {
	MsgID          string  `json:"msgID" validate:"required"`
	CardNoEncpt    string  `json:"cardNoEncpt" validate:"required"`
	CardNoMasked   string  `json:"cardNoMasked" validate:"required"`
	CardNoAcptNm   string  `json:"cardNoAcptNm"`
	CardNoAcptCity string  `json:"cardNoAcptCity"`
	CardNoAcptCty  string  `json:"cardNoAcptCty"`
	TxnDt          string  `json:"txnDt" validate:"required"`
	TxnTm          string  `json:"txnTm" validate:"required"`
	TxnAmt         float64 `json:"txnAmt" validate:"required"`
	TxnCcyCd       string  `json:"ccyCd"`
	TxnCd          string  `json:"txnCd"`
	AhrCd          string  `json:"ahrCd" validate:"required"`
	GcyCardTp      string  `json:"gcyCardTp"`
	AprvF          string  `json:"aprvF" validate:"required"`
	CcyNbrDcm      int     `json:"ccyNbrDcm" validate:"gte=0"`
	CcyAbr         string  `json:"ccyAbr" validate:"required"`
}

type CardRes struct {
	MsgID  string `json:"msgID"`
	Result string `json:"result"`
}

type HealthChkRes struct {
	Status string         `json:"status"`
	ID     string         `json:"id,omitempty"`
	Checks []HealthChkRes `json:"checks,omitempty"`
}
