package utils

import (
	"fmt"
	"os"

	"github.com/sirupsen/logrus"
)

func Hello(s string) string {
	result := fmt.Sprint("Hello ", s)
	fmt.Println(result)
	return result
}

func FileExists(filename string) bool {
	if _, err := os.Stat(filename); err == nil {
		return true
	} else if os.IsNotExist(err) {
		return false
	} else {
		logrus.Error(err)
	}
	return false
}
