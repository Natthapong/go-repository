package utils

import "testing"

func TestHello(t *testing.T) {
	t.Run("sample unit test", func(t *testing.T) {
		rs := Hello("Go-UCenter")
		if rs != "Hello Go-UCenter" {
			t.Errorf("expected : %s, but got %s", "Hello Go-UCenter", rs)
		}
	})
}
