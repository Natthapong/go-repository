package common

import "errors"

var ErrFeedNotFound = errors.New("Feed Not Found")
