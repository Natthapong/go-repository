package errors

import "fmt"

type SampleError struct {
	Path string
}

func (e *SampleError) Error() string {
	return fmt.Sprintf("parse %v: sample error", e.Path)
}
