package logger

import (
	"log"
	"os"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

type Log struct {
	logger *zap.Logger
}

type LogData struct {
	Header interface{} `json:"header"`
	Data   interface{} `json:"data"`
}

func InitialLogger() *Log {
	config := zap.NewProductionConfig()
	config.EncoderConfig.EncodeLevel = zapcore.CapitalLevelEncoder
	config.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
	config.DisableCaller = true
	if _, isKibana := os.LookupEnv("LOG_FORMAT_ONPREM"); isKibana {
		config.EncoderConfig.TimeKey = "@timestamp"
		config.EncoderConfig.MessageKey = "@message"
	} else {
		config.EncoderConfig.LevelKey = "severity"
		config.EncoderConfig.TimeKey = "time"
	}

	logger, err := config.Build()
	if err != nil {
		log.Fatalf("can't initialize zap logger: %v", err)
	}
	zap.ReplaceGlobals(logger)
	defer logger.Sync() // flushes buffer, if any
	return &Log{logger}
}

func (l *Log) BuildRequestLog(method, path, requestBody string) {
	l.logger.Info("Entering",
		zap.String("method", method),
		zap.String("path", path),
		zap.String("data", requestBody),
	)
}

func (l *Log) BuildResponseLog(method, path, responseBody string, responseTime string) {
	l.logger.Info("Exiting",
		zap.String("method", method),
		zap.String("path", path),
		zap.String("data", responseBody),
	)
}

func (l *Log) BuildInfoLog(info string, mobileNo string, corrId string) {
	l.logger.Info(info,
		zap.String("mobileNo", mobileNo),
		zap.String("corrId", corrId),
	)
}

func (l *Log) BuildErrorLog(info string, mobileNo string, corrId string) {
	l.logger.Error(info,
		zap.String("mobileNo", mobileNo),
		zap.String("corrId", corrId),
	)
}
