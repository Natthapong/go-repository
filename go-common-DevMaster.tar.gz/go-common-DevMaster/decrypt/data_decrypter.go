package decrypt

import (
	"crypto/aes"
	"crypto/cipher"
)

type (
	// DataDecrypter decrypts data with the given key
	DataDecrypter interface {
		Decrypt(data, key []byte) ([]byte, error)
	}

	// MSDataDecrypter decrypts data for ms messages
	MSDataDecrypter struct {
	}
)

// NewMSDataDecrypter initializes an instance of ms decrypter
func NewMSDataDecrypter() *MSDataDecrypter {
	return &MSDataDecrypter{}
}

// Decrypt decrypts data with the provided key
func (m *MSDataDecrypter) Decrypt(data, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonceSize := gcm.NonceSize()
	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, err
	}

	return plaintext, nil
}
