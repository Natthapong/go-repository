package decrypt_test

import (
	"context"
	"fmt"
	"testing"

	"go.kbtg.tech/715_MicroService/go-common/decrypt"

	gax "github.com/googleapis/gax-go/v2"
	"github.com/magiconair/properties/assert"
	"github.com/stretchr/testify/mock"
	kmspb "google.golang.org/genproto/googleapis/cloud/kms/v1"
)

type MockKeyManagementClient struct {
	mock.Mock
}

func (m *MockKeyManagementClient) AsymmetricDecrypt(ctx context.Context, req *kmspb.AsymmetricDecryptRequest, opts ...gax.CallOption) (*kmspb.AsymmetricDecryptResponse, error) {
	ret := m.Called(ctx, req)

	var r0 *kmspb.AsymmetricDecryptResponse
	if rf, ok := ret.Get(0).(func(context.Context, *kmspb.AsymmetricDecryptRequest) *kmspb.AsymmetricDecryptResponse); ok {
		r0 = rf(ctx, req)
	} else {
		if ret.Get(0) != nil {
			r0 = ret.Get(0).(*kmspb.AsymmetricDecryptResponse)
		}
	}

	var r1 error
	if rf, ok := ret.Get(1).(func(context.Context, *kmspb.AsymmetricDecryptRequest) error); ok {
		r1 = rf(ctx, req)
	} else {
		r1 = ret.Error(1)
	}

	return r0, r1
}
func TestKeyDecrypt(t *testing.T) {
	tests := map[string]struct {
		encryptedKey    []byte
		mockKeyResponse *kmspb.AsymmetricDecryptResponse
		mockErr         error
		want            []byte
	}{
		"Decrypt key success": {
			encryptedKey: []byte("key"),
			mockKeyResponse: &kmspb.AsymmetricDecryptResponse{
				Plaintext: []byte("key"),
			},
			mockErr: nil,
			want:    []byte("key"),
		},
		"Key management service return error": {
			encryptedKey:    []byte("key"),
			mockKeyResponse: nil,
			mockErr:         fmt.Errorf("Error"),
			want:            nil,
		},
		"Invalid key": {
			encryptedKey:    nil,
			mockKeyResponse: nil,
			mockErr:         fmt.Errorf("Error"),
			want:            nil,
		},
	}

	resourceName := "aes"
	for name, tc := range tests {
		client := new(MockKeyManagementClient)
		d := decrypt.NewMSKeyDecrypter(client, resourceName)
		client.On("AsymmetricDecrypt", context.Background(), &kmspb.AsymmetricDecryptRequest{
			Name:       resourceName,
			Ciphertext: tc.encryptedKey,
		}).Return(tc.mockKeyResponse, tc.mockErr)

		t.Run(name, func(t *testing.T) {
			got, _ := d.Decrypt(tc.encryptedKey)
			assert.Equal(t, tc.want, got, "keys should be equal")
		})
	}
}
