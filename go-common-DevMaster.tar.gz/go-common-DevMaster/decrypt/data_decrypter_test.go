package decrypt_test

import (
	"encoding/base64"
	"encoding/hex"
	"testing"

	"go.kbtg.tech/715_MicroService/go-common/decrypt"

	"github.com/magiconair/properties/assert"
)

func TestDataDecrypt(t *testing.T) {
	tests := map[string]struct {
		key  string
		data string
		want []byte
	}{
		"Decrypt data success": {
			key:  "d8ad3a922498a8c4649f961c13df3bc6a953e96a66a931f30b3599883717c491",
			data: "0esk5dbbThUdujFKgZOeYHlZz1+rXSAyqyOIkFZpTEEE",
			want: []byte("test1"),
		},
		"Invalid key length": {
			key:  "invalid key length",
			data: "data",
			want: nil,
		},
		"Invalid data": {
			key:  "d8ad3a922498a8c4649f961c13df3bc6a953e96a66a931f30b3599883717c491",
			data: "1esk5dbbThUdujFKgZOeYHlZz1+rXSAyqyOIkFZpTEEE",
			want: nil,
		},
	}

	d := decrypt.NewMSDataDecrypter()
	for name, tc := range tests {
		key, _ := hex.DecodeString(tc.key)
		data, _ := base64.StdEncoding.DecodeString(tc.data)
		t.Run(name, func(t *testing.T) {
			got, _ := d.Decrypt(data, key)
			assert.Equal(t, tc.want, got, "data should be equal")
		})
	}
}
