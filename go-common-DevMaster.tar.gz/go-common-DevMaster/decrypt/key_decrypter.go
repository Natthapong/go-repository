package decrypt

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"time"

	"github.com/go-redis/redis/v8"
	gax "github.com/googleapis/gax-go/v2"
	"go.uber.org/zap"
	kmspb "google.golang.org/genproto/googleapis/cloud/kms/v1"
)

var ctx = context.Background()

type (
	// KeyDecrypter decrypts the given encrypted key to its original key
	KeyDecrypter interface {
		Decrypt(key []byte) ([]byte, error)
	}

	// KeyManagementClient represents the client of a Key Management Service
	KeyManagementClient interface {
		AsymmetricDecrypt(ctx context.Context, req *kmspb.AsymmetricDecryptRequest, opts ...gax.CallOption) (*kmspb.AsymmetricDecryptResponse, error)
	}

	// MSKeyDecrypter decrypts ms encrypted key
	MSKeyDecrypter struct {
		name        string
		client      KeyManagementClient
		redisClient *redis.Client
		ttl         time.Duration
		logger      *zap.Logger
	}
)

// NewMSKeyDecrypter initializes an instance of MSKeyDecrypter
func NewMSKeyDecrypter(redisClient *redis.Client, client KeyManagementClient, name string, ttl time.Duration) *MSKeyDecrypter {
	return NewMSKeyDecrypterWithLogger(redisClient, client, name, ttl, zap.L())
}
func NewMSKeyDecrypterWithLogger(redisClient *redis.Client, client KeyManagementClient, name string, ttl time.Duration, logger *zap.Logger) *MSKeyDecrypter {
	return &MSKeyDecrypter{
		name:        name,
		client:      client,
		redisClient: redisClient,
		ttl:         ttl,
		logger:      logger,
	}
}

// Decrypt decrypts the encrypted key
// 'RSA_DECRYPT_OAEP_2048_SHA256' private key stored on Cloud KMS.
// name := "projects/PROJECT_ID/locations/global/keyRings/RING_ID/cryptoKeys/KEY_ID/cryptoKeyVersions/1"
func (m *MSKeyDecrypter) Decrypt(key []byte) ([]byte, error) {
	// First retrieve key from Redis
	redisKey := fmt.Sprintf("%x", sha256.Sum256(key))
	encryptedKey, err := m.retrieveKeyFromRedis(redisKey)
	if err == nil {
		if ce := m.logger.Check(zap.DebugLevel, "Cache hit"); ce != nil {
			kstr := base64.StdEncoding.EncodeToString(key)
			ce.Write(
				zap.String("key", kstr),
				zap.String("hashkey", redisKey),
				zap.ByteString("encryptedKey", encryptedKey),
			)
		}
		return encryptedKey, nil
	}

	// If key not found in redis, get key from kms
	if ce := m.logger.Check(zap.DebugLevel, "Cache missed"); ce != nil {
		kstr := base64.StdEncoding.EncodeToString(key)
		ce.Write(
			zap.String("key", kstr),
			zap.String("hashkey", redisKey),
		)
	}

	encryptedKey, err = m.retrieveKeyFromKms(key)
	if err != nil {
		return nil, err
	}

	// Set key in redis in a separated goroutine for performance
	m.setKeyInRedis(redisKey, string(encryptedKey))

	return encryptedKey, nil
}

func (m *MSKeyDecrypter) retrieveKeyFromRedis(key string) ([]byte, error) {
	val, err := m.redisClient.Get(ctx, key).Result()
	return []byte(val), err
}

func (m *MSKeyDecrypter) retrieveKeyFromKms(key []byte) ([]byte, error) {
	req := &kmspb.AsymmetricDecryptRequest{
		Name:       m.name,
		Ciphertext: key,
	}

	// Call the API.
	response, err := m.client.AsymmetricDecrypt(context.Background(), req)
	if err != nil {
		return nil, fmt.Errorf("AsymmetricDecrypt: %v", err)
	}

	return response.Plaintext, nil
}

func (m *MSKeyDecrypter) setKeyInRedis(key string, value string) {
	err := m.redisClient.Set(ctx, key, value, m.ttl).Err()
	if err != nil {
		m.logger.Error(fmt.Sprintf("Failed to set hashed key: %s with value: %s in redis. %v", key, value, err))
		return
	}

	m.logger.Debug(fmt.Sprintf("Set hashed key: %s with value: %s in redis successfully", key, value))
}
