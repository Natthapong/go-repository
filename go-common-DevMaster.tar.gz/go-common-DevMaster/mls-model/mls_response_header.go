package mls_model

type MlsResponseHeader struct {
	MessageUid    string `bson:"messageUid" json:"messageUid"`
	MessageDt     string `bson:"messageDt" json:"messageDt"`
	RespCode      string `bson:"respCode" json:"respCode"`
	RespDesc      string `bson:"respDesc" json:"respDesc"`
	ReqMessageUid string `bson:"reqMessageUid" json:"reqMessageUid"`
}
