package mls_model

type MlsRequestHeader struct {
	AppId      string `bson:"appId" json:"appId"` // = "715"
	AppUser    string `bson:"appUser" json:"appUser"`
	AppPwd     string `bson:"appPwd" json:"appPwd"`
	MessageUid string `bson:"messageUid" json:"messageUid"`
	MessageDt  string `bson:"messageDt" json:"messageDt"`
}
