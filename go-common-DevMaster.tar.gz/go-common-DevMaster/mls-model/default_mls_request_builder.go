package mls_model

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type DefaultMlsRequestBuilder struct {
}

func formatRequestId(appID string, reqDate string, reqUID string) string {
	return appID + "_" + reqDate + "_" + reqUID
}

func (p *DefaultMlsRequestBuilder) BuildRequestHeader(rqHeader message.RequestHeader) MlsRequestHeader {
	var mlsHeader = MlsRequestHeader{}
	mlsHeader.AppId = rqHeader.AppId
	var reqUID string  //IDGenerator.randomNumber(15);
	var reqDate string //LocalDateTime.now().format(reqDateFm);
	var messageUid = formatRequestId(rqHeader.AppId, reqDate, reqUID)
	var messageDt string //= LocalDateTime.now().format(messageDateFm);

	mlsHeader.MessageUid = messageUid
	mlsHeader.MessageDt = messageDt
	return mlsHeader
}
