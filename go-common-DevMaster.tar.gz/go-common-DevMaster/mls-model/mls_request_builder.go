package mls_model

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type MlsRequestBuilder interface {
	BuildRequestHeader(rqHeader message.RequestHeader) MlsRequestHeader
}
