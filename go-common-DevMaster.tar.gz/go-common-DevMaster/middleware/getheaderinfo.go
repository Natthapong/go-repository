package middleware

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"go.uber.org/zap"
)

type (
	// GetHeaderInfoConfig defines the config for GetHeaderInfo middleware.
	GetHeaderInfoConfig struct {
		// Skipper defines a function to skip middleware.
		Skipper middleware.Skipper

		// Handler receives request and response payload.
		// Required.
		Handler GetHeaderInfoHandler

		EnableBodyDump bool
	}

	// GetHeaderInfoHandler receives the request and response payload.
	GetHeaderInfoHandler func(echo.Context, []byte, []byte)

	bodyDumpResponseWriter struct {
		io.Writer
		http.ResponseWriter
	}

	AccessLogger struct {
		Logger *zap.Logger
	}
)

var (
	emptyBytes                 = []byte{}
	DefaultGetHeaderInfoConfig = GetHeaderInfoConfig{
		Skipper: NoBodySkipper,
	}
)

func (a *AccessLogger) GetHeaderInfoHandler() GetHeaderInfoHandler {
	var logger = a.Logger
	return func(c echo.Context, reqBody []byte, resBody []byte) {
		if ce := logger.Check(zap.InfoLevel, "HS"); ce != nil {
			fields := []zap.Field{
				zap.String("path", c.Request().URL.Path),
				zap.String("method", c.Request().Method),
				zap.Int("status", c.Response().Status),
			}
			if latency, ok := c.Get("latency").(time.Duration); ok {
				fields = append(fields, zap.Int64("latency", latency.Milliseconds()))
			}
			if hv := c.Request().Header.Get(HeaderXCorrelationID); len(hv) > 0 {
				fields = append(fields, zap.String("corrId", hv))
			}
			if hv := c.Request().Header.Get(HeaderXRequestID); len(hv) > 0 {
				fields = append(fields, zap.String("rqId", hv))
			}
			if hv := c.Request().Header.Get("Uct-Profileid"); len(hv) > 0 {
				fields = append(fields, zap.String("profileId", hv))
			}
			if hv := c.Request().Header.Get("Uct-Mobileno"); len(hv) > 0 {
				fields = append(fields, zap.String("mobileNo", hv))
			}
			if hv := c.Request().Header.Get("Uct-Inboxsessionid"); len(hv) > 0 {
				fields = append(fields, zap.String("inboxSessionId", hv))
			}
			if len(resBody) > 0 {
				fields = append(fields, zap.ByteString("request", reqBody))
				fields = append(fields, zap.ByteString("response", resBody))
			}
			ce.Write(fields...)
		}
	}
}

func GetHeaderInfo(handler GetHeaderInfoHandler) echo.MiddlewareFunc {
	c := DefaultGetHeaderInfoConfig
	c.Handler = handler
	return GetHeaderInfoWithConfig(c)
}

// GetHeaderInfoWithConfig returns a GetHeaderInfo middleware with config.
func GetHeaderInfoWithConfig(config GetHeaderInfoConfig) echo.MiddlewareFunc {
	// Defaults
	if config.Handler == nil {
		panic("echo: get-header-info middleware requires a handler function")
	}
	if config.Skipper == nil {
		config.Skipper = DefaultGetHeaderInfoConfig.Skipper
	}

	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) (err error) {
			if config.Skipper(c) {
				return next(c)
			}

			// Request
			reqBody := []byte{}
			if c.Request().Body != nil { // Read
				reqBody, _ = ioutil.ReadAll(c.Request().Body)
			}
			c.Request().Body = ioutil.NopCloser(bytes.NewBuffer(reqBody)) // Reset

			ctx := c.Request().Context()
			var body map[string]map[string]interface{}
			if err = json.Unmarshal(reqBody, &body); err != nil {
				if ute, ok := err.(*json.UnmarshalTypeError); ok {
					zap.L().Warn(fmt.Sprintf("Unmarshal type error: expected=%v, got=%v, field=%v, offset=%v", ute.Type, ute.Value, ute.Field, ute.Offset))
				} else if se, ok := err.(*json.SyntaxError); ok {
					zap.L().Warn(fmt.Sprintf("Syntax error: offset=%v, error=%v", se.Offset, se.Error()))
				}
			} else {
				if headers, ok := body["header"]; ok {
					ctx = context.WithValue(ctx, "reqHeaders", headers)
					c.SetRequest(c.Request().Clone(ctx))
					for k, v := range headers {
						if vstr, ok := v.(string); ok {
							// add all from json header to http header with uct- prefix and lowercase key
							// header key will format when call Set function (http.CanonicalHeaderKey)
							if len(vstr) > 0 {
								switch k {
								case corrId:
									c.Request().Header.Set(HeaderXCorrelationID, vstr)
								case requestUniqueId:
									c.Request().Header.Set(HeaderXRequestID, vstr)
								default:
									c.Request().Header.Set("uct-"+k, vstr)
								}
							}
						} else {
							zap.S().Warnf("Header have non string (Key=%s)", k)
						}
					}
				}
			}

			// Auto generate Request ID and Correlation ID
			var reqId string
			var hk string
			hk = http.CanonicalHeaderKey(HeaderXRequestID)
			if _, ok := c.Request().Header[hk]; !ok {
				reqId = "uct" + strings.Replace(uuid.New().String(), "-", "", -1)[:29]
				c.Request().Header.Set(hk, reqId)
			} else {
				reqId = c.Request().Header.Get(hk)
			}
			hk = http.CanonicalHeaderKey(HeaderXCorrelationID)
			if _, ok := c.Request().Header[hk]; !ok {
				c.Request().Header.Set(hk, reqId)
			}

			var resBody *bytes.Buffer
			if config.EnableBodyDump {
				// Response
				resBody = new(bytes.Buffer)
				mw := io.MultiWriter(c.Response().Writer, resBody)
				writer := &bodyDumpResponseWriter{Writer: mw, ResponseWriter: c.Response().Writer}
				c.Response().Writer = writer
			}

			start := time.Now()
			if err = next(c); err != nil {
				c.Error(err)
			}
			stop := time.Now()
			c.Set("latency", stop.Sub(start))

			// callback
			if config.EnableBodyDump {
				config.Handler(c, reqBody, resBody.Bytes())
			} else {
				config.Handler(c, reqBody, emptyBytes)
			}

			return
		}
	}
}

// WriteHeader copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) WriteHeader(code int) {
	w.ResponseWriter.WriteHeader(code)
}

// Write copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Write(b []byte) (int, error) {
	return w.Writer.Write(b)
}

// Flush copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Flush() {
	w.ResponseWriter.(http.Flusher).Flush()
}

// Hijack copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return w.ResponseWriter.(http.Hijacker).Hijack()
}
