package middleware

import (
	"context"
	"net/http"
	"strings"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	// "ucenter.dev/service/message"
	// ms "ucenter.dev/service/ms-model"
)

type (
	SessionAuth struct {
		// SessionGetter         SessionGetter
		Handler SessionAuthHandler
	}

	// SessionAuthHandler request to ms-sesion with inboxsessionID to get profileID, mobileNo, kplusLoginBy
	SessionAuthHandler func(ctx context.Context, inboxSessionID string) (string, string, string, error)
	// SessionGetter interface {
	// 	// GetSession(ctx context.Context, rq message.GetSessionRq) (session.SessionRs, error)
	// 	Get(ctx context.Context, inboxSessionID string) (string, string, string, error)
	// }
)

func NewSessionAuth(handler SessionAuthHandler) *SessionAuth {
	return &SessionAuth{Handler: handler}
}

func (p *SessionAuth) CheckSession() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			ctx := c.Request().Context()
			inboxSID := c.Request().Header.Get("Uct-Inboxsessionid")
			corID := c.Request().Header.Get(HeaderXCorrelationID)

			if len(inboxSID) == 0 {
				return echo.ErrUnauthorized
			}
			if len(corID) == 0 {
				corID = "uct" + strings.Replace(uuid.New().String(), "-", "", -1)[:29]
			}
			ctx = context.WithValue(ctx, "corrId", corID)
			// get from CLOUD Redis
			// Get(ctx context.Context, inboxSessionID string) (profileID , mobileNo , kplusLoginBy string, error)
			if profileID, mobileNo, kplusLoginBy, err := p.Handler(ctx, inboxSID); err != nil {
				log.Errorf(ctx, "Call ms-session got error: %s", err)
				return err
			} else {
				// invalid session on cloud
				if len(mobileNo) == 0 || len(profileID) == 0 {
					return echo.NewHTTPError(http.StatusUnauthorized, "Invalid session")
				}
				c.Set("profileId", profileID)
				c.Set("mobileNo", mobileNo)
				c.Request().Header.Set("Uct-Profileid", profileID)
				c.Request().Header.Set("Uct-Mobileno", mobileNo)
				c.Request().Header.Set("Uct-Kplusloginby", kplusLoginBy)
				return next(c)
			}
		}
	}
}
