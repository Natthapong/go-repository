package middleware

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"go.uber.org/zap"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

// type MetaData struct {
// }

const (
	requestUniqueId      string = "requestUniqueId"
	corrId               string = "corrId"
	HeaderXRequestID            = "X-Request-Id"
	HeaderXCorrelationID        = "X-Correlation-Id"
)

type blRsHeader struct {
	CorrId            string        `json:"corrId,omitempty"`
	RequestDateTime   string        `json:"requestedDateTime,omitempty"`
	RequestedUniqueId string        `json:"requestedUniqueId,omitempty"`
	ResponseCode      string        `json:"responseCode,omitempty"`
	ResponseDateTime  string        `json:"responseDateTime,omitempty"`
	ResponseDesc      string        `json:"responseDesc,omitempty"`
	ResponseId        string        `json:"responseId,omitempty"`
	Status            string        `json:"status,omitempty"`
	InboxSessionId    string        `json:"inboxSessionId,omitempty"`
	Errors            []interface{} `json:"errors,omitempty"`
}

type msRsHeader struct {
	CorrId            string        `json:"corrId,omitempty"`
	Errors            []interface{} `json:"errors,omitempty"`
	InboxSessionId    string        `json:"inboxSessionId,omitempty"`
	MobileNo          string        `json:"mobileNo,omitempty"`
	RequestDateTime   string        `json:"requestedDateTime,omitempty"`
	RequestedUniqueId string        `json:"requestedUniqueId,omitempty"`
	ResponseDateTime  string        `json:"responseDateTime,omitempty"`
	ResponseId        string        `json:"responseId,omitempty"`
	StatusCode        string        `json:"statusCode,omitempty"`
	StatusMessage     string        `json:"statusMessage,omitempty"`
}

func DefaultSkipper(c echo.Context) bool {
	return c.Path() == `/health` || c.Path() == `/metrics` // || c.Request().Method == http.MethodGet
}

func NoBodySkipper(c echo.Context) bool {
	return DefaultSkipper(c) || (c.Request().Method != http.MethodPut && c.Request().Method != http.MethodPost && c.Request().Method != http.MethodPatch)
}

// Depecated
func BLHTTPErrorHandler(err error, c echo.Context) {
	code := http.StatusInternalServerError
	desc := echo.ErrInternalServerError.Message.(string)
	if he, ok := err.(*echo.HTTPError); ok {
		code = he.Code
		if msg, ok := he.Message.(string); ok {
			desc = msg
		}
	}
	rs := buildFailBLResponse(c, strconv.Itoa(code), desc, err)
	// zap.S().With(
	// 	"corrId", rs.Header.CorrId,
	// 	"requestedUniqueId", rs.Header.RequestedUniqueId,
	// 	"responseId", rs.Header.ResponseId,
	// 	"error", err.Error(),
	// ).Error("response error")
	// zap.S().Debugf("response message = %+v", rs)
	if !c.Response().Committed {
		c.JSON(code, rs)
	}
}

func buildFailBLResponse(c echo.Context, responseCode string, responseDesc string, err error) map[string]interface{} {
	responseId := strings.Replace(uuid.New().String(), "-", "", -1)
	responseDateTime := time.Now().Format("20060102030405")
	var header = &blRsHeader{
		// CorrId: "",
		// RequestDateTime:   "",
		// RequestedUniqueId: "",
		ResponseCode:     responseCode,
		ResponseDateTime: responseDateTime,
		ResponseDesc:     responseDesc,
		ResponseId:       responseId,
		Status:           "F",
	}
	fields := []zap.Field{}
	fields = append(fields, zap.String("path", c.Path()))
	fields = append(fields, zap.String("statusCode", responseCode))
	fields = append(fields, zap.Error(err))
	var hk string
	hk = http.CanonicalHeaderKey(HeaderXCorrelationID)
	if _, ok := c.Request().Header[hk]; ok {
		header.CorrId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("corrId", header.CorrId))
	}
	hk = http.CanonicalHeaderKey("uct-" + "requestedDateTime")
	if _, ok := c.Request().Header[hk]; ok {
		header.RequestDateTime = c.Request().Header.Get(hk)
	}
	hk = http.CanonicalHeaderKey(HeaderXRequestID)
	if _, ok := c.Request().Header[hk]; ok {
		header.RequestedUniqueId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("rqId", header.RequestedUniqueId))
	}
	hk = http.CanonicalHeaderKey("uct-" + "inboxSessionId")
	if _, ok := c.Request().Header[hk]; ok {
		header.InboxSessionId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("inboxSessionId", header.InboxSessionId))
	}
	logging.L().Warn(responseDesc, fields...)
	return map[string]interface{}{"header": &header}
}

func buildFailMSResponse(c echo.Context, statusCode string, statusMessage string, err error) map[string]interface{} {
	responseId := strings.Replace(uuid.New().String(), "-", "", -1)
	responseDateTime := time.Now().Format("20060102030405")
	var header = &msRsHeader{
		// CorrId: "",
		// RequestDateTime:   "",
		// RequestedUniqueId: "",
		StatusCode:       statusCode,
		ResponseDateTime: responseDateTime,
		StatusMessage:    statusMessage,
		ResponseId:       responseId,
	}
	fields := []zap.Field{}
	fields = append(fields, zap.String("path", c.Path()))
	fields = append(fields, zap.String("statusCode", statusCode))
	fields = append(fields, zap.Error(err))
	var hk string
	hk = http.CanonicalHeaderKey(HeaderXCorrelationID)
	if _, ok := c.Request().Header[hk]; ok {
		header.CorrId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("corrId", header.CorrId))
	}
	hk = http.CanonicalHeaderKey("uct-" + "requestedDateTime")
	if _, ok := c.Request().Header[hk]; ok {
		header.RequestDateTime = c.Request().Header.Get(hk)
	}
	hk = http.CanonicalHeaderKey(HeaderXRequestID)
	if _, ok := c.Request().Header[hk]; ok {
		header.RequestedUniqueId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("rqId", header.RequestedUniqueId))
	}
	hk = http.CanonicalHeaderKey("uct-" + "inboxSessionId")
	if _, ok := c.Request().Header[hk]; ok {
		header.InboxSessionId = c.Request().Header.Get(hk)
		fields = append(fields, zap.String("inboxSessionId", header.InboxSessionId))
	}
	logging.L().Warn(statusMessage, fields...)
	return map[string]interface{}{"header": &header}
}

type HTTPErrorHandler struct {
	ResponseBuilder ResponseBuilder
}

func (h *HTTPErrorHandler) Handle(err error, c echo.Context) {
	code := http.StatusInternalServerError
	desc := echo.ErrInternalServerError.Message.(string)
	if he, ok := err.(*echo.HTTPError); ok {
		code = he.Code
		if msg, ok := he.Message.(string); ok {
			desc = msg
		}
		if he.Internal != nil {
			err = he.Internal
		}
	}
	rs := h.ResponseBuilder(c, strconv.Itoa(code), desc, err)
	if !c.Response().Committed {
		c.JSON(code, rs)
	}
}

type ResponseBuilder func(c echo.Context, statusCode string, statusMessage string, err error) map[string]interface{}

func MSResponseFailBuilder() ResponseBuilder {
	return buildFailMSResponse
}

func BLResponseFailBuilder() ResponseBuilder {
	return buildFailBLResponse
}
