package firestore

import (
	"cloud.google.com/go/firestore"
	"context"
	"firebase.google.com/go"
	"google.golang.org/api/option"
	"log"
	"reflect"
)

func Connect(ctx context.Context, credentials []byte) (*firestore.Client, error) {
	adminClient, err := firebase.NewApp(ctx, nil, option.WithCredentialsJSON(credentials))
	if err != nil {
		log.Fatalf("Could not create admin client: %v", err)
		return nil, err
	}

	client, err := adminClient.Firestore(ctx)
	if err != nil {
		log.Fatalf("Could not create data operations client: %v", err)
		return nil, err
	}
	return client, nil
}

func FindOne(ctx context.Context, collection *firestore.CollectionRef, rowKey string, modelType reflect.Type, fields ...string) (interface{}, error) {
	docsnap, err := collection.Doc(rowKey).Get(ctx)
	result := reflect.New(modelType).Interface()
	if err != nil {
		return result, err
	}
	docsnap.DataTo(&result)
	if len(fields) >= 1 {
		rv := reflect.Indirect(reflect.ValueOf(result))
		fv := rv.FieldByName(fields[0])
		if fv.IsValid() {
			fv.Set(reflect.ValueOf(docsnap.Ref.ID))
		}
	}
	//fmt.Println(result)
	return result, nil
}
