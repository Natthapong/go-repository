package firestore

type QueryFireStore struct {
	Key      string
	Operator string
	Value    interface{}
}
