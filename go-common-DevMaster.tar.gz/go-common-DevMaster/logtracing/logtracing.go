package logtracing

func NewTracingField(corID string, profileID string, mobileNo string) LoggingField {
	lb := &LoggingFieldBuilder{}
	lf := lb.CorID(corID).ProfileID(profileID).MobileNo(mobileNo).Build()
	return lf
}

type LoggingField struct {
	CorID     string
	ProfileID string
	MobileNo  string
}

type LoggingFieldBuilder struct {
	LoggingField
}

func (lb *LoggingFieldBuilder) Build() LoggingField {
	return lb.LoggingField
}

func (lb *LoggingFieldBuilder) CorID(corID string) *LoggingFieldBuilder {
	lb.LoggingField.CorID = corID
	return lb
}

func (lb *LoggingFieldBuilder) ProfileID(profileID string) *LoggingFieldBuilder {
	lb.LoggingField.ProfileID = profileID
	return lb
}

func (lb *LoggingFieldBuilder) MobileNo(mobileNo string) *LoggingFieldBuilder {
	lens := len(mobileNo)
	head := mobileNo[:lens-8]
	tail := mobileNo[lens-3:]
	lb.LoggingField.MobileNo = head + "-xxxx-x" + tail
	return lb
}
