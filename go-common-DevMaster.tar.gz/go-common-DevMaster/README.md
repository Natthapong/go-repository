# go.kbtg.tech/715_MicroService/go-common
a golang package for share codes

# การใช้ GOPROXY
Ref. https://agilepm.kasikornbank.com:8444/display/CICD/How+to+use+Go+with+KBTG+proxy+repository

set environment variable ที่ ~/.zshrc หรือ ~/.bash_profile

```
export GOPRIVATE=ucenter.dev,kscm.kasikornbank.com,go.kasikornbank.com,go.kbtg.tech
export GOPROXY="https://artifactory.kasikornbank.com:8443/artifactory/api/go/go-virtual,direct"
export GONOSUMDB=ucenter.dev,kscm.kasikornbank.com,go.kasikornbank.com,go.kbtg.tech,gopkg.in/mgo.v2
```
เนื่องจาก [kscm.kasikornbank.com](https://kscm.kasikornbank.com:8443/) และ [artifactory.kasikornbank.com](https://artifactory.kasikornbank.com:8443/artifactory/webapp) จำเป็นต้อง login โดยสามารถใส่ username:password@domain ใน URL ได้ แต่แนะนำให้ใช้ไฟล์ ~/.netrc แทน

อย่างตัวไฟล์ .netrc (ใช้ [Personal-Access-Token](https://kscm.kasikornbank.com:8443/profile/personal_access_tokens) และ [API-KEY](https://artifactory.kasikornbank.com:8443/artifactory/webapp/#/profile) แทน password)
```
machine kscm.kasikornbank.com login K0965XXX password Personal-Access-Token
machine artifactory.kasikornbank.com login k0965XXX password API-KEY

```

# การ Tag Version
ในภาษา Go ใช้ [Semantic Versioning (semver)](https://semver.org/) vX.Y.Z ไม่ใช่ v.X.Y.Z



ข้างล่าง ⬇️ เป็น readme ตัวเก่า

---

## How to use⚒ (PLEASE UPGRADE GOLANG TO VERSION 1.13+)

1. git config
   ```
   git config --global url."https://kscm.kasikornbank.com:8443/715_MicroService".insteadOf "https://kscm.kasikornbank.com/715_MicroService"
   ```
1. in another git repo for golang service
1. initialise go module in that repo  (use "ucenter.dev/svc" for all service.)
    ```
    $ go mod init ucenter.dev/svc
    ```
1. run go get command 

    For Unix/Linux
    ```
    $ export GIT_TERMINAL_PROMPT=1
    $ export GOPRIVATE=ucenter.dev,kscm.kasikornbank.com
    $ go mod edit -replace go.kbtg.tech/715_MicroService/go-common=kscm.kasikornbank.com/715_MicroService/go-common.git@DevMaster
    $ go get -u go.kbtg.tech/715_MicroService/go-common
    ```
    For Windows (Start > Edit environment variables for your accout > New GOPRIVATE=ucenter.dev)
    ```
    > set GIT_TERMINAL_PROMPT=1
    > set GOPRIVATE=ucenter.dev,kscm.kasikornbank.com
    > go mod edit -replace go.kbtg.tech/715_MicroService/go-common=kscm.kasikornbank.com/715_MicroService/go-common.git@DevMaster
    > go get -u go.kbtg.tech/715_MicroService/go-common
    ```
Note: GOPRIVATE come with Go 1.13. For Go 1.12 you must use GOPROXY=direct and GOSUMDB=off

1. insert 'import "go.kbtg.tech/715_MicroService/go-common"' into source code
1. run
    ```
    $ go mod vendor
    ```
1. push all source code (include vendor directory) to Git


## Building a service project with go mod vendor (Jenkins pipeline also)


```
$ go build -mod=vendor
```

or

```
$ export GOFLAGS="-mod=vendor"
$ go build
```




## How to update version

go-common

1. tag with format v0.0.0 (not v.0.0.0 or not 0.0.0)

another repo which wanna update common version
   ```
   git config --global url."https://kscm.kasikornbank.com:8443/715_MicroService".insteadOf "https://kscm.kasikornbank.com/715_MicroService"
   export GOPRIVATE=ucenter.dev,kscm.kasikornbank.com
   go mod edit -replace go.kbtg.tech/715_MicroService/go-common=kscm.kasikornbank.com/715_MicroService/go-common.git@DevMaster
   go mod tidy
   go mod vendor
   
   git add .
   git commit -m "update go.kbtg.tech/715_MicroService/go-common version"
   git push
   ```

