package core_message

type BaseResponse struct {
	Header ResponseHeader `json:"header"`
	Data   *interface{}   `json:"data,omitempty"`
	Error  *interface{}   `json:"error,omitempty"`
}
