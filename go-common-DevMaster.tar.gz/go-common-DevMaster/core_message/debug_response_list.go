package core_message

type DebugResponseList struct {
	Header DebugResponseHeader `json:"header,omitempty"`
	Data   *DebugListData     `json:"data,omitempty"`
}

type DebugListData struct {
	PageSize        int32        `json:"pageSize,omitempty"`
	HasMore         bool         `json:"hasMore,omitempty"`
	ResetFlag       bool         `json:"resetFlag,omitempty"`
	ContentFeedList *[]DebugFeed `json:"contentFeedList,omitempty"`
}
