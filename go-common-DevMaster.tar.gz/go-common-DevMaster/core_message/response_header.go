package core_message

type ResponseHeader struct {
	Status            ResponseStatus `json:"status" bson:"status"`
	ResponseCode      string         `json:"responseCode" bson:"responseCode"`
	ResponseDesc      string         `json:"responseDesc,omitempty" bson:"responseDesc"`
	MobileNo          string         `json:"-"`
	RequestedUniqueId string         `json:"requestedUniqueId" bson:"requestedUniqueId"`
	RequestDateTime   string         `json:"requestedDateTime,omitempty" bson:"requestDateTime"`
	ResponseId        string         `json:"responseId,omitempty" bson:"responseId"`
	ResponseDateTime  string         `json:"responseDateTime,omitempty" bson:"responseDateTime"`
	InboxSessionId    string         `json:"inboxSessionId,omitempty" bson:"inboxSessionId"`
	Errors            []ErrorMessage `json:"errors" bson:"errors"`
	CorrId            string         `json:"corrId" bson:"corrId"`
}
