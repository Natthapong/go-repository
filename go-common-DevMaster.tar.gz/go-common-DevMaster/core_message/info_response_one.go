package core_message

type InfoResponseOne struct {
	Header InfoResponseHeader `json:"header,omitempty"`
	Data   *InfoFeed          `json:"data,omitempty"`
}
