package core_message

import (
	"bytes"
	"encoding/json"
)

type ResponseStatus int

const (
	Success ResponseStatus = iota
	Fail    ResponseStatus = iota
)

func (p ResponseStatus) String() string {
	return ResponseStatusValue[p]
}

func (p *ResponseStatus) FromString(s string) ResponseStatus {
	return ResponseStatusName[s]
}

var ResponseStatusValue = map[ResponseStatus]string{
	Success: "S",
	Fail:    "F",
}

var ResponseStatusName = map[string]ResponseStatus{
	"S": Success,
	"F": Fail,
}

func (p ResponseStatus) MarshalJSON() ([]byte, error) {
	buffer := bytes.NewBufferString(`"`)
	buffer.WriteString(ResponseStatusValue[p])
	buffer.WriteString(`"`)
	return buffer.Bytes(), nil
}

func (p *ResponseStatus) UnmarshalJSON(b []byte) error {
	var s string
	err := json.Unmarshal(b, &s)
	if err != nil {
		return err
	}
	*p = ResponseStatusName[s]
	return nil
}
