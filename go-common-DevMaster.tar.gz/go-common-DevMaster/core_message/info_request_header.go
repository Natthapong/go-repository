package core_message

type DebugRequestHeader struct {
	OS      string `json:"os,omitempty"`
	AppVer  string `json:"appver,omitempty"`
	Rqdt    string `json:"rqdt,omitempty"`
	CorId   string `json:"corid,omitempty"`
	Inbxsid string `json:"inbxsid,omitempty"`
	Rquid   string `json:"rquid,omitempty"`

	MobileNo        string `json:"mobileNo,omitempty"`
	ProfileId       string `json:"profileId,omitempty"`
	MobileOS        string `json:"mobileOS,omitempty"`
	AppVersion      string `json:"appVersion,omitempty"`
	AppId           string `json:"appId,omitempty"`
	RequestDateTime string `json:"requestDateTime,omitempty"`
	CorrId          string `json:"corrId,omitempty"`
	Language        string `json:"language,omitempty"`
	InboxSessionId  string `json:"inboxSessionId,omitempty"`
	RequestUniqueId string `json:"requestUniqueId,omitempty"`
}

type InfoRequestHeader struct {
	OS     string `json:"os,omitempty"`
	AppVer string `json:"appver,omitempty"`
	Rqdt   string `json:"rqdt,omitempty"`
	CorId  string `json:"corid,omitempty"`

	MobileNo        string `json:"mobileNo,omitempty"`
	ProfileId       string `json:"profileId,omitempty"`
	MobileOS        string `json:"mobileOS,omitempty"`
	AppVersion      string `json:"appVersion,omitempty"`
	AppId           string `json:"appId,omitempty"`
	RequestDateTime string `json:"requestDateTime,omitempty"`
	CorrId          string `json:"corrId,omitempty"`
	Language        string `json:"language,omitempty"`
}
