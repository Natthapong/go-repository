package core_message

type DebugResponseHeader struct {
	Rscode  string `json:"rscode,omitempty"`
	Rsdesc  string `json:"rsdesc,omitempty"`
	Rquid   string `json:"rquid,omitempty"`
	Rqdt    string `json:"rqdt,omitempty"`
	Rsid    string `json:"rsid,omitempty"`
	Rsdt    string `json:"rsdt,omitempty"`
	Inbxsid string `json:"inbxsid,omitempty"`
	Corid   string `json:"corid,omitempty"`

	Status            string         `json:"status,omitempty"`
	ResponseCode      string         `json:"responseCode,omitempty"`
	ResponseDesc      string         `json:"responseDesc,omitempty"`
	RequestedUniqueId string         `json:"requestedUniqueId,omitempty"`
	RequestDateTime   string         `json:"requestedDateTime,omitempty"`
	ResponseId        string         `json:"responseId,omitempty"`
	ResponseDateTime  string         `json:"responseDateTime,omitempty"`
	InboxSessionId    string         `json:"inboxSessionId,omitempty"`
	CorrId            string         `json:"corrId,omitempty"`
	Errors            []ErrorMessage `json:"errors,omitempty" bson:"errors"`
}

type InfoResponseHeader struct {
	Rscode string `json:"rscode,omitempty"`
	Rsdesc string `json:"rsdesc,omitempty"`
	Rqdt   string `json:"rqdt,omitempty"`
	Rsid   string `json:"rsid,omitempty"`
	Rsdt   string `json:"rsdt,omitempty"`
	Corid  string `json:"corid,omitempty"`
	//Status            string `json:"status"`
	ResponseCode string `json:"responseCode,omitempty"`
	ResponseDesc string `json:"responseDesc,omitempty"`
	//RequestedUniqueId string `json:"requestedUniqueId"`
	RequestDateTime  string `json:"requestedDateTime,omitempty"`
	ResponseId       string `json:"responseId,omitempty"`
	ResponseDateTime string `json:"responseDateTime,omitempty"`
	//InboxSessionId    string         `json:"inboxSessionId,omitempty"`
	CorrId string `json:"corrId,omitempty"`
}
