package core_message

type InfoFeed struct {
	Id string `json:"id,omitempty"`
	// ProfileID       string     `json:"profileID,omitempty"`
	CreateDate            interface{} `json:"createDate,omitempty"`
	State                 *string     `json:"state,omitempty"`
	ContentCategory       *string     `json:"contentCategory,omitempty"`
	Command               *string     `json:"command,omitempty"`
	ActionExpireDate      interface{} `json:"actionExpireDate,omitempty"`
	AuthType              *int32      `json:"authType,omitempty"`
	LandingTemplateID     *string     `json:"landingTemplateID,omitempty"`
	LandingButtonLabelSet *string     `json:"landingButtonLabelSet,omitempty"`
	// Additional Fields extracted from LanguageModel for Landing
	// Body       interface{} `json:"body,omitempty"`
	// Key for decryption process
	// OnPremise bool   `json:"onPremise,omitempty"`
	// Key       string `json:"key,omitempty" bson:"key,omitempty"`
	// for iding
}
