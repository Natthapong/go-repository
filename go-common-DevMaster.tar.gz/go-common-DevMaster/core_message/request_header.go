package core_message

type RequestHeader struct {
	MobileNo        string   `json:"mobileNo" bson:"mobileNo" `
	ProfileId       string   `json:"profileId" bson:"profileId"`
	MobileOS        string   `json:"mobileOS" bson:"mobileOS"`
	AppVersion      string   `json:"appVersion" bson:"appVersion"`
	AppId           string   `json:"appId" bson:"appId"`
	InboxSessionId  string   `json:"inboxSessionId" bson:"inboxSessionId"`
	RequestUniqueId string   `json:"requestUniqueId" bson:"requestUniqueId"`
	RequestDateTime string   `json:"requestDateTime" bson:"requestDateTime"`
	CorrId          string   `json:"corrId" bson:"corrId"`
	Language        Language `json:"language" bson:"language"`
}
