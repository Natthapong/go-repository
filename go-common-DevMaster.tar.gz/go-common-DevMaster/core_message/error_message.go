package core_message

type ErrorMessage struct {
	ErrorCode string `bson:"errorCode" json:"errorCode"`
	ErrorDesc string `bson:"errorDesc" json:"errorDesc"`
}
