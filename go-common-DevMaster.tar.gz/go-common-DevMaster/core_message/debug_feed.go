package core_message

type DebugFeed struct {
	Id              string    `json:"id,omitempty"`
	// ProfileID       string    `json:"profileID,omitempty"`
	CreateDate      interface{} `json:"createDate,omitempty"`
	State           *string   `json:"state,omitempty"`
	CampaignCode    *string   `json:"campaignCode,omitempty"` // debug
	Hashtag         *string   `json:"hashtag,omitempty"`      // debug
	TrackingID      *string   `json:"trackingID,omitempty"`   // debug
	ContentCategory *string   `json:"contentCategory,omitempty"`
	Command         *string   `json:"command,omitempty"`
	// Parameter             interface{} `json:"parameter,omitempty"`
	ActionExpireDate      interface{} `json:"actionExpireDate,omitempty"`
	ImodeFlag             *bool     `json:"imodeFlag,omitempty"`   // debug
	IdingFlag             *bool     `json:"idingFlag,omitempty"`   // debug
	LandingFlag           *bool     `json:"landingFlag,omitempty"` // debug
	IotherType            *int32    `json:"iotherType,omitempty"`  // debug
	AuthType              *int32    `json:"authType,omitempty"`
	LabelSetVersion       *int64    `json:"labelSetVersion,omitempty"` // debug
	LandingTemplateID     *string   `json:"landingTemplateID,omitempty"`
	LandingButtonLabelSet *string   `json:"landingButtonLabelSet,omitempty"`
	TemplateVersion       *int64    `json:"templateVersion,omitempty"` // debug
	// Additional Fields extracted from LanguageModel for Landing
	Images     *[]string `json:"images,omitempty"`     // debug
	Author     *string   `json:"author,omitempty"`     // debug
	AuthorIcon *string   `json:"authorIcon,omitempty"` // debug
	Topic      *string   `json:"topic,omitempty"`      // debug
	// Body       interface{} `json:"body,omitempty"`
	// Key for decryption process
	// OnPremise bool   `json:"onPremise,omitempty"`
	// Key       string `json:"key,omitempty" bson:"key,omitempty"`

	// for iding
	Image *string `json:"image,omitempty" bson:"image,omitempty"` // debug
	// Topic     *string `json:"topic,omitempty" bson:"topic,omitempty"`
	Highlight *string `json:"highlight,omitempty" bson:"highlight,omitempty"` // debug
	Body      *string `json:"body,omitempty" bson:"body,omitempty"`           // debug
	Footer    *string `json:"footer,omitempty" bson:"footer,omitempty"`       // debug

	Read bool `json:"read,omitempty"` // debug

	// for imode
	Badge *string `json:"badge,omitempty" bson:"badge,omitempty"` // debug
	// Body                  *string             `json:"body,omitempty" bson:"body,omitempty"`
	// Footer                *string             `json:"footer,omitempty" bson:"footer,omitempty"`
	// Highlight             *string             `json:"highlight,omitempty" bson:"highlight,omitempty"`
	// Image                 *string             `json:"image,omitempty" bson:"image,omitempty"`
	// Topic                 *string             `json:"topic,omitempty" bson:"topic,omitempty"`
	// Hidden                *bool               `json:"-,omitempty" bson:"hidden,omitempty"`
	Score *float64 `json:"score,omitempty" bson:"score,omitempty"` // debug
}
