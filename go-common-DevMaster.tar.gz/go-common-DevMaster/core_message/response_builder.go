package core_message

type ResponseBuilder interface {
	HasAnyError(errors []ErrorMessage) bool
	CreateResponseHeader(requestHeader RequestHeader) *ResponseHeader
	BuildResponseStatus(header *ResponseHeader) *ResponseHeader
	BuildNotFoundResponse(header *ResponseHeader) *ResponseHeader
	BuildResponseFromErrors(header *ResponseHeader, errors []ErrorMessage) *ResponseHeader
	BuildNotFoundResponseWithMessage(header *ResponseHeader, message string) *ResponseHeader
	BuildFailedBusinessResponseWithMessageAndCode(response *ResponseHeader, message string, code string) *ResponseHeader
	BuildFailedBusinessResponseFromErrorCodeAndDescription(header *ResponseHeader, responseCode string, responseDesc string) *ResponseHeader
}
