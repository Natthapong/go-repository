package core_message

type DebugResponseOne struct {
	Header DebugResponseHeader `json:"header,omitempty"`
	Data   *DebugFeed     `json:"data,omitempty"`
}
