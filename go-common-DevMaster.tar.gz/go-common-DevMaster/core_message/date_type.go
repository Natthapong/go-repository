package core_message

import (
	"fmt"
	"strings"
	"time"
)

type DateType struct {
	time.Time
}

func (t *DateType) getTimestamp() int64 {
	return t.UnixNano() / int64(time.Millisecond)
}
func (t *DateType) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`%d`, t.getTimestamp())), nil
}

func (t *DateType) UnmarshalJSON(b []byte) error { // return long
	fmt.Println(string(b))
	strInput := string(b)
	strInput = strings.Trim(strInput, `"`)
	if len(strInput) > 10 {
		newTime, err := time.Parse(time.RFC3339, strInput)
		if err != nil {
			return err
		}
		t.Time = newTime
	}
	return nil
}
