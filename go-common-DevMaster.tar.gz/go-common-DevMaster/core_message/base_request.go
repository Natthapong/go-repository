package core_message

type BaseRequest struct {
	Header RequestHeader `json:"header"`
	Data   *interface{}  `json:"data"`
}
