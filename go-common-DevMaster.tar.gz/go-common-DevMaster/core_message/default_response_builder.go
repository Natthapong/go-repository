package core_message

import (
	"github.com/google/uuid"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const (
	MobileDatetimePattern = "20060102150405" // format java : yyyyMMddHHmmss
)

type DefaultResponseBuilder struct {
}

func (p *DefaultResponseBuilder) HasAnyError(errors []ErrorMessage) bool {
	return !(errors == nil || len(errors) == 0)
}

func FormatDate(date time.Time, format string) string {
	return date.Format(format)
}

func (p *DefaultResponseBuilder) CreateResponseHeader(requestHeader RequestHeader) *ResponseHeader {
	id := strings.Replace(uuid.New().String(), "-", "", -1)
	var header = ResponseHeader{}
	header.CorrId = requestHeader.CorrId
	header.MobileNo = requestHeader.MobileNo
	header.RequestedUniqueId = requestHeader.RequestUniqueId
	header.RequestDateTime = requestHeader.RequestDateTime
	header.ResponseId = id
	header.ResponseDateTime = FormatDate(time.Now(), MobileDatetimePattern)
	header.InboxSessionId = requestHeader.InboxSessionId
	header.CorrId = requestHeader.CorrId
	header.Errors = make([]ErrorMessage, 0)
	return &header
}

func (p *DefaultResponseBuilder) BuildResponseStatus(header *ResponseHeader) *ResponseHeader {
	var status ResponseStatus
	var errors = header.Errors
	if len(errors) == 0 {
		header.Status = status.FromString("S")
		header.ResponseCode = strconv.Itoa(http.StatusOK)
		header.ResponseDesc = "Success"
	} else {
		header.Status = status.FromString("F")
		header.ResponseCode = strconv.Itoa(http.StatusInternalServerError)
		header.ResponseDesc = "Fail"
	}
	return header
}

func (p *DefaultResponseBuilder) BuildNotFoundResponse(header *ResponseHeader) *ResponseHeader {
	return p.BuildNotFoundResponseWithMessage(header, http.StatusText(http.StatusNotFound))
}

func (p *DefaultResponseBuilder) BuildNotFoundResponseWithMessage(header *ResponseHeader, message string) *ResponseHeader {
	var status ResponseStatus
	header.Status = status.FromString("F")
	header.ResponseCode = strconv.Itoa(http.StatusNotFound)
	header.ResponseDesc = message
	return header
}

func (p *DefaultResponseBuilder) BuildFailedBusinessResponseWithMessageAndCode(response *ResponseHeader, message string, code string) *ResponseHeader {
	var error = ErrorMessage{}
	error.ErrorCode = code
	error.ErrorDesc = message
	return p.BuildResponseFromError(response, error)
}

func (p *DefaultResponseBuilder) BuildResponseFromErrors(header *ResponseHeader, errors []ErrorMessage) *ResponseHeader {
	var status ResponseStatus
	if errors != nil && len(header.Errors) > 0 {
		for i := 0; i < len(errors); i++ {
			// fmt.Println(errors[i])
			header.Errors = append(header.Errors, errors[i])
		}
	} else {
		header.Errors = errors
	}
	if len(header.Errors) == 0 {
		header.Status = status.FromString("S")
		header.ResponseCode = "200"
		header.ResponseDesc = "Success"
	} else {
		header.Status = status.FromString("F")
		header.ResponseCode = "500"
		header.ResponseDesc = "Fail"
	}
	var responseDesc string
	header.Errors, responseDesc = p.transformErrors(header.Errors)
	if len(responseDesc) > 0 {
		header.ResponseDesc = responseDesc
	}
	return header
}

func (p *DefaultResponseBuilder) transformErrors(errors []ErrorMessage) ([]ErrorMessage, string) {
	var responseDesc string
	var errs = make([]ErrorMessage, 0)
	for _, elem := range errors {
		if !((elem.ErrorCode == "503" && strings.HasPrefix(elem.ErrorDesc, "Network Error: ")) || (elem.ErrorCode == "500" && strings.HasPrefix(elem.ErrorDesc, "Database Error: "))) {
			errs = append(errs, elem)
		}
		if arr := strings.Split(elem.ErrorDesc, "||"); len(arr) > 1 {
			responseDesc = arr[1]
		}
	}
	return errs, responseDesc
}

func (p *DefaultResponseBuilder) BuildResponseFromError(responseHeader *ResponseHeader, error ErrorMessage) *ResponseHeader {
	if error.ErrorDesc == "" {
		return p.BuildResponseFromErrors(responseHeader, nil)
	} else {
		var errors = make([]ErrorMessage, 0)
		errors = append(errors, error)
		return p.BuildResponseFromErrors(responseHeader, errors)
	}
}

func (p *DefaultResponseBuilder) BuildFailedBusinessResponseFromErrorCodeAndDescription(header *ResponseHeader, responseCode string, responseDesc string) *ResponseHeader {
	return p.BuildFailedBusinessResponseWithMessageAndCode(header, responseCode, responseDesc)
}
