package core_message

type BaseDebugRequest struct {
	Header DebugRequestHeader `json:"header,omitempty"`
	Data   interface{}        `json:"data",omitempty`
}

type BaseInfoRequest struct {
	Header InfoRequestHeader `json:"header,omitempty"`
	Data   interface{}       `json:"data",omitempty`
}
