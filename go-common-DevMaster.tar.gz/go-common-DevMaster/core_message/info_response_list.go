package core_message

type InfoResponseList struct {
	Header InfoResponseHeader `json:"header,omitempty"`
	Data   *InfoListData      `json:"data,omitempty"`
}

type InfoListData struct {
	PageSize        int32       `json:"pageSize,omitempty"`
	HasMore         bool        `json:"hasMore,omitempty"`
	ResetFlag       bool        `json:"resetFlag,omitempty"`
	ContentFeedList *[]InfoFeed `json:"contentFeedList,omitempty"`
}
