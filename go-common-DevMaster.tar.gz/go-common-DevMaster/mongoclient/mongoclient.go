package mongoclient

import (
	"context"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.uber.org/zap"
)

func CreateMongoClient(url string, minPoolSize uint64, maxPoolSize uint64) (*mongo.Client, error) {

	ctx := context.Background()
	option := options.Client().ApplyURI(url).SetMinPoolSize(minPoolSize).SetMaxPoolSize(maxPoolSize)
	mongoClient, err := mongo.Connect(ctx, option)
	if err != nil {
		return nil, err
	}
	err = mongoClient.Ping(context.TODO(), nil)
	if err != nil {
		zap.L().Error(err.Error())
	}
	zap.L().Info("Connected to MongoDB!")
	return mongoClient, nil
}

func FindAllWithQuery(ctx context.Context, collection *mongo.Collection,
	query bson.M, limit int64) ([]bson.Raw, error) {
	var cursor *mongo.Cursor
	var err error
	if limit > 0 {
		findOption := options.Find()
		findOption.SetLimit(limit)
		cursor, err = collection.Find(ctx, query, findOption)
	} else {
		cursor, err = collection.Find(ctx, query)
	}

	if err != nil {
		return nil, err
	}
	var resultArray []bson.Raw
	defer cursor.Close(context.TODO())
	for cursor.Next(context.TODO()) {
		resultArray = append(resultArray, cursor.Current)
	}
	if err := cursor.Err(); err != nil {
		return nil, err
	}
	return resultArray, nil
}
