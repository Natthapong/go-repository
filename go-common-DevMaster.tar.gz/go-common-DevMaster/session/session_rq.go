package session

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type SessionRq struct {
	Header message.RequestHeader `bson:"header" json:"header"`
}
