package session

type KPlusLogin struct {
	LoginBy *string `json:"loginBy,omitempty"`
}
