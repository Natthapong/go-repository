package session

import "time"

type SessionRs struct {
	InboxSessionId string      `json:"inboxSessionId,omitempty"`
	MobileNo       string      `json:"mobileNo,omitempty"`
	ProfileId      string      `json:"profileId,omitempty"`
	CreateDateTime *time.Time  `json:"createDateTime,omitempty"`
	KPlusLogin     *KPlusLogin `json:"kplusLogin,omitempty"`
}
