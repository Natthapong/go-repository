package session

import "context"

type MsSessionService interface {
	GetSession(rq SessionRq) (SessionRs, error)
	GetSessionWithContext(ctx context.Context, rq SessionRq) (SessionRs, error)
	GetFromPremise(ctx context.Context, rq SessionRq) (SessionRs, error)
	GetURL() string
}
