package grpc

import (
	"context"
	"github.com/golang/protobuf/ptypes"
	pb "go.kbtg.tech/715_MicroService/go-common/grpc"
	session "go.kbtg.tech/715_MicroService/go-common/session"
)

type GRPCMsSessionService struct {
	Context         context.Context
	MsSessionUrl    string
	MsSessionClient pb.MsSessiongRPCServiceClient
}

func NewGRPCMsSessionService(msSessionUrl string, client pb.MsSessiongRPCServiceClient) *GRPCMsSessionService {
	ctx := context.Background()
	return &GRPCMsSessionService{Context: ctx, MsSessionUrl: msSessionUrl, MsSessionClient: client}
}

func (s *GRPCMsSessionService) GetSession(rq session.SessionRq) (session.SessionRs, error) {
	var response = session.SessionRs{}
	sessionRq := pb.SessionRq{
		Header: &pb.RequestHeader{
			CorrId:         rq.Header.CorrId,
			InboxSessionId: rq.Header.InboxSessionId,
		},
	}
	sessionRs, err := s.MsSessionClient.GetSession(s.Context, &sessionRq)
	if err != nil {
		return response, err
	}
	createDateTime, _ := ptypes.Timestamp(sessionRs.CreateDateTime)
	//if err != nil {
	//	return response, err
	//}
	response = session.SessionRs{
		InboxSessionId: sessionRs.InboxSessionId,
		MobileNo:       sessionRs.MobileNo,
		ProfileId:      sessionRs.ProfileId,
		CreateDateTime: &createDateTime,
	}

	return response, nil
}

func (s *GRPCMsSessionService) GetURL() string {
	return s.MsSessionUrl
}
