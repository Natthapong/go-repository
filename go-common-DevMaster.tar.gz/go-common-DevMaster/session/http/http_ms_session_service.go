package http

import (
	"context"

	session "go.kbtg.tech/715_MicroService/go-common/session"
	"go.kbtg.tech/715_MicroService/go-common/util/web_client"
)

var postObject = web_client.PostObjectWithContext

type HttpMsSessionService struct {
	MsSessionUrl string
}

func NewHttpMsSessionService(msSessionUrl string) *HttpMsSessionService {
	return &HttpMsSessionService{MsSessionUrl: msSessionUrl}
}

func (s *HttpMsSessionService) GetSession(rq session.SessionRq) (session.SessionRs, error) {
	return s.GetSessionWithContext(context.TODO(), rq)
}

func (s *HttpMsSessionService) GetSessionWithContext(ctx context.Context, rq session.SessionRq) (session.SessionRs, error) {
	return s.getSession(ctx, s.MsSessionUrl, rq)
}

func (s *HttpMsSessionService) getSession(ctx context.Context, url string, rq session.SessionRq) (session.SessionRs, error) {
	var response = session.SessionRs{}
	decoder, er1 := postObject(ctx, url, false, rq)
	if er1 != nil {
		return response, er1
	}
	er2 := decoder.Decode(&response)
	if er2 != nil {
		return response, er2
	}
	return response, nil
}

func (s *HttpMsSessionService) GetFromPremise(ctx context.Context, rq session.SessionRq) (session.SessionRs, error) {
	var url = s.MsSessionUrl + "?location=premise"
	return s.getSession(ctx, url, rq)
}

func (s *HttpMsSessionService) GetURL() string {
	return s.MsSessionUrl
}
