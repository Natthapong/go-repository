package http

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"
	"go.kbtg.tech/715_MicroService/go-common/core_message"
	"go.kbtg.tech/715_MicroService/go-common/logging"
	"go.kbtg.tech/715_MicroService/go-common/session"
)

func TestGetTemplateSession(t *testing.T) {
	logging.InitialLogger()
	testCases := []struct {
		name        string
		request     session.SessionRq
		response    interface{}
		expectedRs  interface{}
		expectedErr error
	}{
		{"Success",
			session.SessionRq{core_message.RequestHeader{CorrId: "UnitTest"}},
			session.SessionRs{InboxSessionId: "Test"},
			session.SessionRs{InboxSessionId: "Test"},
			nil,
		},
		{"HttpResponseError",
			session.SessionRq{core_message.RequestHeader{CorrId: "UnitTest"}},
			session.SessionRs{},
			session.SessionRs{},
			fmt.Errorf("err"),
		},
		{"DecodeFail",
			session.SessionRq{core_message.RequestHeader{CorrId: "UnitTest"}},
			1,
			session.SessionRs{},
			nil,
		},
	}
	old := postObject
	defer func() { postObject = old }()
	service := NewHttpMsSessionService("TestGetSessionUrl")

	for _, tc := range testCases {
		postObject = func(ctx context.Context, url string, insecureSkipVerify bool, data interface{}) (*json.Decoder, error) {
			b, _ := json.Marshal(tc.response)
			bytes.NewReader(b)
			return json.NewDecoder(bytes.NewReader(b)), tc.expectedErr
		}
		rs, err := service.GetSession(tc.request)
		assert.Equal(t, tc.expectedRs, rs, tc.name)
		assert.Equal(t, tc.expectedErr, err, tc.name)
	}
}
