package contenttemplateversion

type (
	// VersionCache is responsible for content template version caching.
	VersionCache interface {
		GetTemplateIDVersion(landingPageTemplateID string) (int64, error)
	}
)
