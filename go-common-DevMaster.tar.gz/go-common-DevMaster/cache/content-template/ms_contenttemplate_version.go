package contenttemplateversion

import (
	"errors"
	"sync"

	"go.uber.org/zap"
	mscontenttemplatesrv "go.kbtg.tech/715_MicroService/go-common/ms-contenttemplate"

	"github.com/robfig/cron/v3"
)

type (
	// MsContentTemplateVersionCache is an simple implementation of caching service.
	// Cache is invalidated corresponding to the schedule(in cron expression format).
	// During invalidating process if we can not retrieve the lastest versions from
	// contenttemplate.ContentTemplateVersionRetriever this cache will remain unchange.
	MsContentTemplateVersionCache struct {
		cron     *cron.Cron
		srv      mscontenttemplatesrv.ContentTemplateVersionRetriever
		versions map[string]int64
		mu       sync.RWMutex
		logger   *zap.Logger
	}
)

func NewWithLogger(srv mscontenttemplatesrv.ContentTemplateVersionRetriever, schedule string, logger *zap.Logger) (*MsContentTemplateVersionCache, error) {
	cache := MsContentTemplateVersionCache{
		cron:     cron.New(),
		versions: make(map[string]int64),
		srv:      srv,
		logger:   logger,
	}

	// Initiialize cache at app startup
	if err := cache.initialize(); err != nil {
		return nil, err
	}

	cache.cron.AddFunc(schedule, cache.invalidate)
	cache.cron.Start()

	return &cache, nil
}

// New initializes an instance of MsContentTemplateVersionCache
func New(srv mscontenttemplatesrv.ContentTemplateVersionRetriever, schedule string) (*MsContentTemplateVersionCache, error) {
	return NewWithLogger(srv, schedule, zap.L())
}

func (m *MsContentTemplateVersionCache) invalidate() {
	m.logger.Debug("Invalidate content template version cache")
	if err := m.initialize(); err != nil {
		m.logger.Error("Failed to invalidate content template version cache. " + err.Error())
	}
}

func (m *MsContentTemplateVersionCache) initialize() error {
	versions, err := m.srv.GetVersions()
	if err != nil {
		m.logger.Error("Failed to retrieve version. " + err.Error())
		return err
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	m.versions = make(map[string]int64)
	for _, v := range versions {
		m.versions[v.ID] = v.Version
	}

	return nil
}

// GetTemplateIDVersion returns a version associating with landingPageTemplateID.
// If no version has been found 0 and an error will be returned.
func (m *MsContentTemplateVersionCache) GetTemplateIDVersion(landingPageTemplateID string) (int64, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	version, ok := m.versions[landingPageTemplateID]
	if !ok {
		return 0, errors.New("unable get template version in cache")
	}
	return version, nil
}
