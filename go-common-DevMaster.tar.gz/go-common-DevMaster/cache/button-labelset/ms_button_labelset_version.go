package buttonlbelsetversion

import (
	"fmt"
	"sync"

	"go.uber.org/zap"
	mscontenttemplatesrv "go.kbtg.tech/715_MicroService/go-common/ms-contenttemplate"

	"github.com/robfig/cron/v3"
)

type (
	// MsButtonLabelsetVersionCache is an simple implementation of caching service.
	// Cache is invalidated corresponding to the schedule(in cron expression format).
	// During invalidating process if we can not retrieve the lastest versions from
	// contenttemplate.VersionRetriever this cache will remain unchange.
	MsButtonLabelsetVersionCache struct {
		cron     *cron.Cron
		srv      mscontenttemplatesrv.ButtonLabelsetVersionRetriever
		versions map[string]int64
		mu       sync.RWMutex
		logger   *zap.Logger
	}
)

// New initializes an instance of MsButtonLabelsetVersionCache
func New(srv mscontenttemplatesrv.ButtonLabelsetVersionRetriever, schedule string) (*MsButtonLabelsetVersionCache, error) {
	return NewWithLogger(srv, schedule, zap.L())
}

func NewWithLogger(srv mscontenttemplatesrv.ButtonLabelsetVersionRetriever, schedule string, logger *zap.Logger) (*MsButtonLabelsetVersionCache, error) {
	cache := MsButtonLabelsetVersionCache{
		cron:     cron.New(),
		versions: make(map[string]int64),
		srv:      srv,
		logger:   logger,
	}

	// Initiialize cache at app startup
	if err := cache.initialize(); err != nil {
		return nil, err
	}

	cache.cron.AddFunc(schedule, cache.invalidate)
	cache.cron.Start()

	return &cache, nil
}

func (m *MsButtonLabelsetVersionCache) L() *zap.Logger {
	return m.logger
}

func (m *MsButtonLabelsetVersionCache) invalidate() {

	m.L().Debug("Invalidate button label set version cache")
	if err := m.initialize(); err != nil {
		m.L().Error("Failed to invalidate button label set version cache. " + err.Error())
	}
}

func (m *MsButtonLabelsetVersionCache) initialize() error {
	versions, err := m.srv.GetVersions()
	if err != nil {
		m.L().Error("Failed to retrieve version. " + err.Error())
		return err
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	m.versions = make(map[string]int64)
	for _, v := range versions {
		m.versions[v.ID] = v.Version
	}
	return nil
}

// GetButtonLabelSetVersion returns a version associating with id.
// If no version has been found 0 and an error will be returned.
func (m *MsButtonLabelsetVersionCache) GetButtonLabelSetVersion(id string) (int64, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	version, ok := m.versions[id]
	if !ok {
		return 0, fmt.Errorf("unable get button label set version in cache")
	}
	return version, nil
}
