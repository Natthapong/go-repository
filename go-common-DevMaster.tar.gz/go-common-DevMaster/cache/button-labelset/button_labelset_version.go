package buttonlbelsetversion

type (
	// VersionCache is responsible for button label set version caching.
	VersionCache interface {
		GetButtonLabelSetVersion(id string) (int64, error)
	}
)
