package webclient

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"io"
	"net/http"
	"time"
)

type WebClient struct {
	HttpClient *http.Client
}

func InitWebClient(skipSSL bool, timeout time.Duration) *http.Client {
	handshakeTimeout := time.Duration(5 * time.Second)
	transport := &http.Transport{
		TLSHandshakeTimeout: handshakeTimeout,
		TLSClientConfig:     &tls.Config{InsecureSkipVerify: skipSSL},
	}
	return &http.Client{
		Timeout:   timeout,
		Transport: transport,
	}
}

func (c *WebClient) NewRequest(method, url string, body interface{}) (*http.Request, error) {
	return c.NewRequestWtihContext(nil, method, url, body)
}
func (c *WebClient) NewRequestWtihContext(ctx context.Context, method, url string, body interface{}) (req *http.Request, err error) {
	var buf io.Reader
	if body != nil {
		reqBody, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		buf = bytes.NewReader(reqBody)
	}

	if ctx != nil {
		req, err = http.NewRequestWithContext(ctx, method, url, buf)
	} else {
		req, err = http.NewRequest(method, url, buf)
	}
	if err != nil {
		return nil, err
	}
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	req.Header.Set("Accept", "application/json")
	return
}

func (c *WebClient) Do(req *http.Request, v interface{}) (*bytes.Buffer, error) {
	res, err := c.HttpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	buf := new(bytes.Buffer)
	buf.ReadFrom(res.Body)
	return buf, nil
}
