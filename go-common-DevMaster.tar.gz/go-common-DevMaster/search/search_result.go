package search

type SearchResult struct {
	Results   interface{} `json:"results"`
	PageIndex    int64 `json:"pageIndex"`
	PageSize     int64 `json:"pageSize"`
	InitPageSize int64 `json:"initPageSize"`
	ItemTotal    int64 `json:"itemTotal"`
	LastPage     bool  `json:"lastPage"`
}
