package search

import (
	message "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type MsSearchRs struct {
	Header message.MsResponseHeader `json:"header,omitempty" bson:"header,omitempty"`
	Data   *SearchResult   `json:"data,omitempty" bson:"data,omitempty"`
}
