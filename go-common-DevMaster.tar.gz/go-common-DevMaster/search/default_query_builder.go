package search

import (
	"go.mongodb.org/mongo-driver/bson"
	"reflect"
	"strings"
)

type DefaultQueryBuilder struct {
}

func (b *DefaultQueryBuilder) BuildQuery(sm interface{}, resultModelType reflect.Type) bson.M {
	var query = bson.M{}

	if _, ok := sm.(*SearchModel); ok {
		return query
	}

	value := reflect.Indirect(reflect.ValueOf(sm))
	numField := value.NumField()

	for i := 0; i < numField; i++ {
		x := value.Field(i).Interface()
		if rangeDate, ok := x.(RangeDateTime); ok {
			columnName := GetBsonName(resultModelType, value.Type().Field(i).Name)

			actionDateQuery := bson.M{}

			if rangeDate.StartDate == nil && rangeDate.EndDate == nil {
				continue
			}  else if rangeDate.StartDate == nil {
				actionDateQuery["$lte"] = rangeDate.EndDate.Time.UTC()
			} else if rangeDate.EndDate == nil {
				actionDateQuery["$gte"] = rangeDate.StartDate.Time.UTC()
			} else {
				actionDateQuery["$lte"] = rangeDate.EndDate.Time.UTC()
				actionDateQuery["$gte"] = rangeDate.StartDate.Time.UTC()
			}

			query[columnName] = actionDateQuery
		} else if value.Field(i).Kind().String() == "slice" {
			actionDateQuery := bson.M{}
			columnName := GetBsonName(resultModelType, value.Type().Field(i).Name)
			actionDateQuery["$in"] = x
			query[columnName] = actionDateQuery
		} else {
			t := value.Field(i).Kind().String()
			if _, ok := x.(*SearchModel); t == "bool" || (strings.Contains(t, "int") && x != 0) || (strings.Contains(t, "string") && len(value.Field(i).String()) > 0) || (strings.Contains(t, "float") && x != 0)  || (!ok && t == "ptr" &&
				value.Field(i).Pointer() != 0) {
				columnName := GetBsonName(resultModelType, value.Type().Field(i).Name)
				if len(columnName) > 0 {
					query[columnName] = x
				}
			}
		}
	}
	return query
}
func GetBsonName(modelType reflect.Type, fieldName string) string {
	field, found := modelType.FieldByName(fieldName)
	if !found {
		return fieldName
	}
	if tag, ok := field.Tag.Lookup("bson"); ok {
		return strings.Split(tag, ",")[0]
	}
	return fieldName
}
