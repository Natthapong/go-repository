package search

import (
	"fmt"
	"strings"
	"time"
)

type RangeDateTime struct {
	StartDate *MobileDateTime `json:"startDate"`
	EndDate   *MobileDateTime `json:"endDate"`
}

const RESPONSE_DATE_TIME_FORMATTER = "2006-01-02T15:04:05.000Z"
const DATE_TIME_FORMATTER = "20060102150405"

type MobileDateTime struct {
	*time.Time
}


// Request: From json to time: yyyyMMddHHmmss
func (t *MobileDateTime) UnmarshalJSON(b []byte) error {
	strInput := string(b)
	strInput = strings.Trim(strInput, `"`)
	if len(strInput) > 10 {
		newTime, err := time.ParseInLocation(DATE_TIME_FORMATTER, strInput, time.Local)
		if err != nil {
			return err
		}
		t.Time = &newTime
	}
	return nil
}
func (t MobileDateTime) MarshalJSON() ([]byte, error) {
	timeString := fmt.Sprintf("\"%s\"", t.Time.UTC().Format(RESPONSE_DATE_TIME_FORMATTER))
	return []byte(timeString), nil
}

