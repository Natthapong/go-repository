package search

import (
	"context"
	"go.mongodb.org/mongo-driver/mongo"
	"reflect"
)

type DefaultSearchService struct {
	modelType     reflect.Type
	collection    *mongo.Collection
	searchBuilder SearchResultBuilder
}

func NewDefaultSearchService(db *mongo.Database, modelType reflect.Type, collectionName string, searchBuilder SearchResultBuilder) *DefaultSearchService {
	return &DefaultSearchService{modelType, db.Collection(collectionName), searchBuilder}
}

func (s *DefaultSearchService) Search(ctx context.Context, m interface{}) (*SearchResult, error) {
	return s.searchBuilder.BuildSearchResult(ctx, s.collection, m, s.modelType)
}
