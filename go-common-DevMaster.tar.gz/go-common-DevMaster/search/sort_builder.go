package search

import (
	"go.mongodb.org/mongo-driver/bson"
	"reflect"
)

type SortBuilder interface {
	BuildSort(searchModel SearchModel, modelType reflect.Type) bson.M
}
