package search

type SearchModel struct {
	Keyword      string `json:"keyword"`
	PageIndex    int64  `json:"pageIndex"`
	PageSize     int64  `json:"pageSize"`
	InitPageSize int64  `json:"initPageSize"`
	TagName      string `json:"tagName"`
	IncludeTotal bool   `json:"includeTotal"`
	SortField    string `json:"sortField"`
	SortType     string `json:"sortType"`
}
