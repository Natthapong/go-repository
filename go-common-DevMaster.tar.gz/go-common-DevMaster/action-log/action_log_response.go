package action_log

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type ActionLogResponse struct {
	Header ms.MsResponseHeader `bson:"header" json:"header"`
	Data   interface{}         `bson:"data" json:"data"`
}
