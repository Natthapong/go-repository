package action_log

import "log"

type MockActionLogClient struct {
}

func (c *MockActionLogClient) SaveActionLog(req ActionLogRequest) (ActionLogResponse, error) {
	var res = ActionLogResponse{}
	log.Println("Send action log success")
	return res, nil
}
