package action_log

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"time"
)

var client *http.Client

func init() {
	client = &http.Client{
		Timeout: 10 * time.Second,
	}
}

func basicAuth(username, password string) string {
	auth := username + ":" + password
	return base64.StdEncoding.EncodeToString([]byte(auth))
}

func PostObjectWithAuth(url string, data interface{}, response interface{}, userId string, password string) (*json.Decoder, error) {
	if userId != "" && password != "" {
		//basicAuth := basicAuth("715_U-Center", "715_Password")
		basicAuth := basicAuth(userId, password)
		client.CheckRedirect = func(req *http.Request, via []*http.Request) error {
			req.Header.Add("Authorization", "Basic "+basicAuth)
			return nil
		}
	}
	rq, _ := json.Marshal(data)
	res, err := client.Post(url, "application/json", bytes.NewReader(rq))
	if err != nil {
		return nil, err
	}
	return json.NewDecoder(res.Body), nil
}
