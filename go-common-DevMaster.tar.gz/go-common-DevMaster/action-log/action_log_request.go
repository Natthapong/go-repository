package action_log

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type ActionLogRequest struct {
	Header ms.MsRequestHeader   `bson:"header" json:"header"`
	Data   ActionLogRequestData `bson:"data" json:"data"`
}
