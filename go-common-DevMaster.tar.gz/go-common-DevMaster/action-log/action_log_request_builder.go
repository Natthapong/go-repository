package action_log

import msg "go.kbtg.tech/715_MicroService/go-common/core_message"

type ActionLogRequestBuilder interface {
	BuildActionLogRequest(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequest
	BuildFailedActionLogRequest(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequest
}
