package action_log

type ActionLogClient interface {
	SaveActionLog(req ActionLogRequest) (ActionLogResponse, error)
}
