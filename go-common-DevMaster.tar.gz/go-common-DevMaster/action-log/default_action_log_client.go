package action_log

import (
	"go.uber.org/zap"
)

type DefaultActionLogClient struct {
	Url      string
	Username string
	Password string
}

func (c *DefaultActionLogClient) SaveActionLog(req ActionLogRequest) (ActionLogResponse, error) {
	var res = ActionLogResponse{}
	actionLogResponse, err := PostObjectWithAuth(c.Url, req, res, c.Username, c.Password)
	if err != nil {
		zap.L().Error("Send action log fail. " + err.Error())
		actionLogResponse.Decode(&res)
		return res, err
	}
	zap.L().Debug("Send action log success")
	return res, nil
}
