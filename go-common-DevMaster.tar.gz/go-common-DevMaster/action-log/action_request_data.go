package action_log

import "time"

type ActionLogRequestData struct {
	LogId     string    `json:"logId" bson:"logId"`
	LogType   string    `json:"logType" bson:"logType"`
	Timestamp time.Time `json:"timestamp" bson:"timestamp"`
	MobileNo  string    `json:"mobileNo" bson:"mobileNo"`
	Action    string    `json:"action" bson:"action"`
	Status    string    `json:"status" bson:"status"`
	ContentId string    `json:"rsUid" bson:"contentId"`
	Remark    string    `json:"remark" bson:"remark"`
}
