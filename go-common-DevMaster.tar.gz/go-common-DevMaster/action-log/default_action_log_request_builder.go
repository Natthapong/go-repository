package action_log

import (
	"github.com/google/uuid"
	"strings"
	"time"
	msg "go.kbtg.tech/715_MicroService/go-common/core_message"
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type DefaultActionLogRequestBuilder struct {
}

func (b *DefaultActionLogRequestBuilder) BuildActionLogRequest(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequest {
	return ActionLogRequest{
		Header: b.buildMsRequestHeader(reqHeader),
		Data:   b.buildActionLogDetail(reqHeader, contentId, logType, action, remark),
	}
}

func (b *DefaultActionLogRequestBuilder) BuildFailedActionLogRequest(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequest {
	return ActionLogRequest{
		Header: b.buildMsRequestHeader(reqHeader),
		Data:   b.buildFailedActionLogDetail(reqHeader, contentId, logType, action, remark),
	}
}

func (b *DefaultActionLogRequestBuilder) buildMsRequestHeader(rqHeader msg.RequestHeader) ms.MsRequestHeader {
	now := time.Now()
	id := uuid.New().String()
	return ms.MsRequestHeader{
		MobileNo:        rqHeader.MobileNo,
		AppId:           "715",
		RequestUniqueId: strings.Replace(id, "-", "", -1),
		RequestDateTime: &now,
		CorrId:          rqHeader.CorrId,
		Language:        rqHeader.Language}
}

func (b *DefaultActionLogRequestBuilder) assembleLogDetail(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequestData {
	id := strings.Replace(uuid.New().String(), "-", "", -1)
	var actionLogRequestData = ActionLogRequestData{}
	actionLogRequestData.LogId = id
	actionLogRequestData.LogType = logType
	actionLogRequestData.Timestamp = time.Now()
	actionLogRequestData.MobileNo = reqHeader.MobileNo
	actionLogRequestData.ContentId = contentId
	actionLogRequestData.Action = action
	actionLogRequestData.Remark = remark
	return actionLogRequestData
}

func (b *DefaultActionLogRequestBuilder) createActionLogDetail(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string, status string) ActionLogRequestData {
	var actionLog = b.assembleLogDetail(reqHeader, contentId, logType, action, remark)
	actionLog.Status = status
	return actionLog
}

func (b *DefaultActionLogRequestBuilder) timeCalculation(startTime time.Time) int64 {
	t := time.Now()
	return t.Sub(startTime).Nanoseconds()
}

func (b *DefaultActionLogRequestBuilder) buildActionLogDetail(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequestData {
	return b.createActionLogDetail(reqHeader, contentId, logType, action, remark, "Success")
}

func (b *DefaultActionLogRequestBuilder) buildFailedActionLogDetail(reqHeader msg.RequestHeader, contentId string, logType string, action string, remark string) ActionLogRequestData {
	return b.createActionLogDetail(reqHeader, contentId, logType, action, remark, "Fail")
}
