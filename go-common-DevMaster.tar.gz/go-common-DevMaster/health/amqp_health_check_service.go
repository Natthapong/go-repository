package health

import (
	"context"
	"time"

	"github.com/Azure/go-amqp"
)

type AMQPHealthCheckService struct {
	Session *amqp.Session
	id      string
	des     string
}

func NewAMQPHealthCheckService(s *amqp.Session, id string, des string) *AMQPHealthCheckService {
	return &AMQPHealthCheckService{s, id, des}
}

func (s *AMQPHealthCheckService) GetId() string {
	return s.id
}

func (s *AMQPHealthCheckService) Check(ctx context.Context) error {
	session := s.Session
	receiver, err := session.NewReceiver(
		amqp.LinkSourceAddress(s.des),
		amqp.LinkCredit(1),
		// remove this to prevent healthcheck fail cause by link name duplicated
		// amqp.LinkName("healthcheck"),
	)
	if err != nil {
		return err
	}
	defer func() {
		ctx, cancel := context.WithTimeout(ctx, 1*time.Second)
		receiver.Close(ctx)
		cancel()
	}()
	return err
}
