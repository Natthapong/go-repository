package health

import (
	"context"
	"github.com/go-stomp/stomp"
)

type AMQHealthCheckService struct {
	Client *stomp.Conn
	id     string
	des    string
}

func NewActiveMqHealthCheckService(client *stomp.Conn, id string, des string) *AMQHealthCheckService {
	return &AMQHealthCheckService{client, id, des}
}

func (s *AMQHealthCheckService) GetId() string {
	return s.id
}

func (s *AMQHealthCheckService) Check(ctx context.Context) error {
	des := s.des
	subscription, err := s.Client.Subscribe(des, stomp.AckAuto,
		stomp.SubscribeOpt.Header("subscription-type", "ANYCAST"),
	)
	if err != nil {
		return err
	}
	err = subscription.Unsubscribe()
	return err
}
