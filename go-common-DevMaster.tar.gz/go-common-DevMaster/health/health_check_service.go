package health

import "context"

type HealthCheckService interface {
	GetId() string
	Check(ctx context.Context) error
}
