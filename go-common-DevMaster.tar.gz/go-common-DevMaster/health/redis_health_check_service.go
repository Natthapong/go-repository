package health

import (
	"context"
	"fmt"
	"time"

	"github.com/go-redis/redis/v8"
)

type RedisHealthCheckService struct {
	client  *redis.Client
	id      string
	timeout time.Duration
	context context.Context
}

func NewRedisHealthService(db *redis.Client, name string, timeout time.Duration) *RedisHealthCheckService {
	var ctx = context.Background()
	return &RedisHealthCheckService{db, name, timeout, ctx}
}

func (s *RedisHealthCheckService) GetId() string {
	return s.id
}

func (s *RedisHealthCheckService) Check(ctx context.Context) error {
	cancel := func() {}
	if s.timeout > 0 {
		ctx, cancel = context.WithTimeout(ctx, s.timeout)
	}
	defer cancel()

	checkerChan := make(chan error)
	go func() {
		_, err := s.client.Ping(s.context).Result()
		checkerChan <- err
	}()
	select {
	case err := <-checkerChan:
		return err
	case <-ctx.Done():
		return fmt.Errorf("timeout")
	}
}
