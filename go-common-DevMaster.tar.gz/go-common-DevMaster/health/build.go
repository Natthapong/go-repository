package health

import "context"

func Build(ctx context.Context, services []HealthCheckService) HealthCheck {
	health := HealthCheck{}
	health.Status = StatusUp
	health.Checks = make([]HealthCheck, 0)
	for _, service := range services {
		sub := HealthCheck{}
		sub.Id = service.GetId()
		err := service.Check(context.Background())
		if err == nil {
			sub.Status = StatusUp
		} else {
			sub.Status = StatusDown
			data := make(map[string]interface{})
			data["error"] = err.Error()
			sub.Data = data
			health.Status = StatusDown
		}
		health.Checks = append(health.Checks, sub)
	}
	return health
}
