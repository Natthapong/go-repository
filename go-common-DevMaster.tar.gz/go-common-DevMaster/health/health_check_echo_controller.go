package health

import (
	"net/http"

	"github.com/labstack/echo/v4"
)

type HealthCheckEchoController struct {
	services []HealthCheckService
}

func NewHealthCheckEchoController(services []HealthCheckService) *HealthCheckEchoController {
	return &HealthCheckEchoController{services}
}

func (c *HealthCheckEchoController) Check(ctx echo.Context) error {
	logCtx := ctx.Request().Context()
	res := Build(logCtx, c.services)
	if res.Status == StatusUp {
		return ctx.JSON(http.StatusOK, res)
	}
	return ctx.JSON(http.StatusInternalServerError, res)
}
