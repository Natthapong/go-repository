package health

import (
	"context"
	"fmt"
	"time"

	"cloud.google.com/go/pubsub"

	"go.kbtg.tech/715_MicroService/go-common/logging"
)

type PermissionType int

const (
	PublishPermission PermissionType = 1
	ConsumePermission PermissionType = 2
)

type PubSubHealthCheckService struct {
	id             string
	client         *pubsub.Client
	timeout        time.Duration
	permissionType PermissionType
	resourceId     string
}

func NewPubSubHealthService(name string, client *pubsub.Client, timeout time.Duration, permissionType PermissionType, resourceId string) *PubSubHealthCheckService {
	return &PubSubHealthCheckService{name, client, timeout, permissionType, resourceId}
}

func (s *PubSubHealthCheckService) GetId() string {
	return s.id
}

func (s *PubSubHealthCheckService) Check(ctx context.Context) error {
	var permissions []string
	var err error

	timeoutCtx, _ := context.WithTimeout(ctx, s.timeout)
	if s.permissionType == PublishPermission {
		permissions, err = s.client.Topic(s.resourceId).IAM().TestPermissions(timeoutCtx, []string{"pubsub.topics.publish"})
	} else if s.permissionType == ConsumePermission {
		permissions, err = s.client.Subscription(s.resourceId).IAM().TestPermissions(timeoutCtx, []string{"pubsub.subscriptions.consume"})
	}

	if err != nil {
		logging.Errorf(ctx, "Can't TestPermissions %s: %s", s.resourceId, err.Error())
		return err
	} else if len(permissions) != 1 {
		return fmt.Errorf("invalid permissions: %v", permissions)
	} else {
		return nil
	}
}
