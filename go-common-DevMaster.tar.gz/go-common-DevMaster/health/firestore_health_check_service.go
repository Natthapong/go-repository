package health

import (
	"context"

	"cloud.google.com/go/firestore"
	"google.golang.org/api/option"
)

type (
	FirestoreHealthCheckService struct {
		id        string
		projectID string
		opts      []option.ClientOption
	}
)

func NewFirestoreHealthCheckService(projectID string, opts ...option.ClientOption) *FirestoreHealthCheckService {
	return &FirestoreHealthCheckService{
		id:        "firestore",
		projectID: projectID,
		opts:      opts,
	}
}

func (f FirestoreHealthCheckService) GetId() string {
	return f.id
}

func (f FirestoreHealthCheckService) Check(ctx context.Context) error {
	client, err := firestore.NewClient(ctx, f.projectID, f.opts...)
	if err != nil {
		return err
	}
	defer client.Close()
	return nil
}
