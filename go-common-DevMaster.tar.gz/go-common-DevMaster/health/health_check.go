package health

type HealthCheck struct {
	Id     string                 `json:"id,omitempty"`
	Status Status                 `json:"status,omitempty"`
	Data   map[string]interface{} `json:"data,omitempty"`
	Checks []HealthCheck          `json:"checks,omitempty"`
}
