package health

import (
	"context"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"time"
)

type HttpHealthCheckService struct {
	id      string
	url     string
	timeout time.Duration
	client  *http.Client
}

func NewHttpHealthService(name, url string, timeout time.Duration) *HttpHealthCheckService {
	client := &http.Client{
		Timeout: timeout,
		// never follow redirects
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	return &HttpHealthCheckService{
		id:      name,
		url:     url,
		timeout: timeout,
		client:  client,
	}
}

func (s *HttpHealthCheckService) GetId() string {
	return s.id
}

func (s *HttpHealthCheckService) Check(ctx context.Context) error {
	resp, err := s.client.Get(s.url)
	if e, ok := err.(net.Error); ok && e.Timeout() {
		return fmt.Errorf("time out: %w", e)
	} else if err != nil {
		return err
	}
	_, _ = io.Copy(ioutil.Discard, resp.Body)
	_ = resp.Body.Close()
	if resp.StatusCode >= 500 {
		return fmt.Errorf("status code is: %d", resp.StatusCode)
	}
	return nil
}
