package ms_model

type MsRequest struct {
	Header MsRequestHeader `json:"header"`
	Data   *interface{}    `json:"data"`
}
