package ms_model

type MsResponse struct {
	Header MsResponseHeader `json:"header"`
}
