package ms_model

type MsErrorMessage struct {
	ErrorCode string `bson:"code" json:"errorCode"`
	ErrorDesc string `bson:"message" json:"errorDesc"`
}
