package ms_model

import (
	"time"
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
)

type MsRequestHeader struct {
	MobileNo        string           `bson:"mobileNo" json:"mobileNo"`
	AppId           string           `bson:"appId" json:"appId"`
	RequestUniqueId string           `bson:"requestUniqueId" json:"requestUniqueId"`
	RequestDateTime *time.Time       `bson:"requestDateTime" json:"requestDateTime"`
	CorrId          string           `bson:"corrId" json:"corrId"`
	Language        message.Language `bson:"language" json:"language"`
}
