package ms_model

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type MsBuilder interface {
	BuildMsRequestHeader(rqHeader message.RequestHeader) MsRequestHeader
	BuildMsResponseHeader(rqHeader MsRequestHeader, statusCode string, statusMessage string) MsResponseHeader
	BuildFailResponse(rqHeader MsRequestHeader, errorCode string, description string) MsResponse
}
