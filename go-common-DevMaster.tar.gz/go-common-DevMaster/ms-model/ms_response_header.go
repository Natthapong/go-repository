package ms_model

type MsResponseHeader struct {
	MobileNo          string           `bson:"mobileNo" json:"mobileNo"`
	RequestedUniqueId string           `bson:"requestedUniqueId" json:"requestedUniqueId"`
	RequestedDateTime string           `bson:"requestedDateTime" json:"requestedDateTime"`
	ResponseId        string           `bson:"responseId" json:"responseId"`
	ResponseDateTime  string           `bson:"responseDateTime" json:"responseDateTime"`
	StatusCode        string           `bson:"statusCode" json:"statusCode"`
	StatusMessage     string           `bson:"statusMessage" json:"statusMessage"`
	CorrId            string           `bson:"corrId" json:"corrId"`
	Errors            []MsErrorMessage `bson:"errors" json:"errors"`
}
