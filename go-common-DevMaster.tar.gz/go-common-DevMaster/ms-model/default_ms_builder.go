package ms_model

import (
	"github.com/google/uuid"
	"strings"
	"time"
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
)

type DefaultMsBuilder struct {
}

const (
	MobileDatetimePattern = "20060102150405" // format java : yyyyMMddHHmmss
)

func (p *DefaultMsBuilder) BuildMsRequestHeader(rqHeader message.RequestHeader) MsRequestHeader {
	now := time.Now()
	id := uuid.New().String()
	return MsRequestHeader{
		MobileNo:        rqHeader.MobileNo,
		AppId:           "715",
		RequestUniqueId: strings.Replace(id, "-", "", -1),
		RequestDateTime: &now,
		CorrId:          rqHeader.CorrId,
		Language:        rqHeader.Language}
}

func (p *DefaultMsBuilder) BuildMsResponseHeader(rqHeader MsRequestHeader, statusCode string, statusMessage string) MsResponseHeader {
	id := uuid.New().String()
	return MsResponseHeader{
		MobileNo:          rqHeader.MobileNo,
		RequestedUniqueId: rqHeader.RequestUniqueId,
		RequestedDateTime: FormatDate(time.Now(), MobileDatetimePattern), // TODO format from rqHeader.RequestDateTime
		ResponseId:        strings.Replace(id, "-", "", -1),
		ResponseDateTime:  FormatDate(time.Now(), MobileDatetimePattern),
		StatusCode:        statusCode,
		StatusMessage:     statusMessage,
		CorrId:            rqHeader.CorrId,
		Errors:            make([]MsErrorMessage, 0),
	}
}

func (p *DefaultMsBuilder) BuildFailResponse(rqHeader MsRequestHeader, errorCode string, description string) MsResponse {
	id := uuid.New().String()
	errors := make([]MsErrorMessage, 0)
	error := MsErrorMessage{}
	error.ErrorCode = errorCode
	error.ErrorDesc = description
	errors = append(errors, error)
	msResponseHeader := MsResponseHeader{
		MobileNo:          rqHeader.MobileNo,
		RequestedUniqueId: rqHeader.RequestUniqueId,
		RequestedDateTime: FormatDate(time.Now(), MobileDatetimePattern), // TODO format from rqHeader.RequestDateTime
		ResponseId:        strings.Replace(id, "-", "", -1),
		ResponseDateTime:  FormatDate(time.Now(), MobileDatetimePattern),
		StatusCode:        "",
		StatusMessage:     "",
		CorrId:            rqHeader.CorrId,
		Errors:            errors,
	}
	msRs := MsResponse{}
	msRs.Header = p.BuildResponseFromErrors(msResponseHeader, errors)
	return msRs
}

func (p *DefaultMsBuilder) BuildResponseFromErrors(rsHeader MsResponseHeader, errors []MsErrorMessage) MsResponseHeader {
	rsHeader.Errors = errors
	if rsHeader.Errors == nil || 0 == len(rsHeader.Errors) {
		rsHeader.StatusCode = "S"
		rsHeader.StatusMessage = ""
	} else {
		rsHeader.StatusCode = "F"
		rsHeader.StatusMessage = errors[0].ErrorDesc
	}
	return rsHeader
}

func FormatDate(date time.Time, format string) string {
	return date.Format(format)
}
