package logging

import (
	"context"
	"fmt"
	golog "log"
	"os"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

const (
	LOG_FIELDS_KEY = "logFields"
	// DebugLevel logs are typically voluminous, and are usually disabled in
	// production.
	DebugLevel = zap.DebugLevel
	// InfoLevel is the default logging priority.
	InfoLevel = zap.InfoLevel
	// WarnLevel logs are more important than Info, but don't need individual
	// human review.
	WarnLevel = zap.WarnLevel
	// ErrorLevel logs are high-priority. If an application is running smoothly,
	// it shouldn't generate any error-level logs.
	ErrorLevel = zap.ErrorLevel
	// DPanicLevel logs are particularly important errors. In development the
	// logger panics after writing the message.
	DPanicLevel = zap.DPanicLevel
	// PanicLevel logs a message, then panics.
	PanicLevel = zap.PanicLevel
	// FatalLevel logs a message, then calls os.Exit(1).
	FatalLevel = zap.FatalLevel
)

type (
	Level zapcore.Level
)

var logger *zap.Logger = zap.L()

func maskingMobileNo(mobileNo string) string {
	lens := len(mobileNo)
	head := mobileNo[:2]
	tail := mobileNo[lens-4:]
	return head + "-xxxx-" + tail
}

func AppendFieldsFromContext(ctx context.Context, fields []zapcore.Field) []zapcore.Field {
	if reqHeaders, ok := ctx.Value("reqHeaders").(map[string]interface{}); ok {
		if v, ok := reqHeaders["corrId"].(string); ok {
			fields = append(fields, zap.String("corrId", v))
		}
		if v, ok := reqHeaders["profileId"].(string); ok {
			fields = append(fields, zap.String("profileId", v))
		}
		if v, ok := reqHeaders["mobileNo"].(string); ok {
			fields = append(fields, zap.String("mobileNo", v))
		}
		if v, ok := reqHeaders["inboxSessionId"].(string); ok {
			fields = append(fields, zap.String("inboxSessionId", v))
		}
		if v, ok := reqHeaders["requestedUniqueId"].(string); ok {
			fields = append(fields, zap.String("rqId", v))
		}
	}

	if logFields, ok := ctx.Value(LOG_FIELDS_KEY).(map[string]interface{}); ok {
		for k, v := range logFields {
			// fields[k] = v
			fields = append(fields, zap.Reflect(k, v))
		}
	}
	if corrID, ok := ctx.Value(KeyCorrID).(string); ok && len(corrID) > 0 {
		fields = append(fields, zap.String("corrId", corrID))
	}
	if profileID, ok := ctx.Value(KeyProfileID).(string); ok && len(profileID) > 0 {
		fields = append(fields, zap.String("profileId", profileID))
	}
	if mobileNo, ok := ctx.Value(KeyMobileNo).(string); ok && len(mobileNo) > 0 {
		if _, ok := os.LookupEnv("LOG_FORMAT_ONPREM"); ok {
			fields = append(fields, zap.String("mobileNo", mobileNo))
		} else {
			fields = append(fields, zap.String("mobileNo", maskingMobileNo(mobileNo)))
		}
	}
	if inboxSessionID, ok := ctx.Value(KeyInboxSessionID).(string); ok && len(inboxSessionID) > 0 {
		fields = append(fields, zap.String("inboxSessionId", inboxSessionID))
	}
	if requestUniqueID, ok := ctx.Value(KeyRequestID).(string); ok && len(requestUniqueID) > 0 {
		fields = append(fields, zap.String("rqId", requestUniqueID))
	}
	return fields
}

// func AppendLogrusFields(ctx context.Context, fields logrus.Fields) logrus.Fields {
// 	if logFields, ok := ctx.Value(LOG_FIELDS_KEY).(map[string]interface{}); ok {
// 		for k, v := range logFields {
// 			fields[k] = v
// 		}
// 	}
// 	if corrId, ok := ctx.Value("corrId").(string); ok && len(corrId) > 0 {
// 		fields["corrId"] = corrId
// 	}
// 	if profileId, ok := ctx.Value("profileId").(string); ok && len(profileId) > 0 {
// 		fields["profileId"] = profileId
// 	}
// 	if mobileNo, ok := ctx.Value("mobileNo").(string); ok && len(mobileNo) > 0 {
// 		if _, ok := os.LookupEnv("LOG_FORMAT_ONPREM"); ok {
// 			fields["mobileNo"] = mobileNo
// 		} else {
// 			fields["mobileNo"] = maskingMobileNo(mobileNo)
// 		}
// 	}
// 	return fields
// }

// TODO
func AddLogField(ctx context.Context, key string, value interface{}) context.Context {
	logFields, ok := ctx.Value(LOG_FIELDS_KEY).(map[string]interface{})
	if !ok {
		logFields = make(map[string]interface{})
	}
	logFields[key] = value
	return context.WithValue(ctx, LOG_FIELDS_KEY, logFields)
}

func Panicf(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.PanicLevel, format, args...)
}

func Fatalf(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.FatalLevel, format, args...)
}

func Errorf(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.ErrorLevel, format, args...)
}

func Warnf(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.WarnLevel, format, args...)
}

func Infof(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.InfoLevel, format, args...)
}

func Debugf(ctx context.Context, format string, args ...interface{}) {
	logf(ctx, zap.DebugLevel, format, args...)
}

func Check(lvl zapcore.Level, msg string) *zapcore.CheckedEntry {
	return logger.Check(lvl, msg)
}

func IsLevelEnabled(lvl zapcore.Level) bool {
	return logger.Core().Enabled(lvl)
}

func logf(ctx context.Context, level zapcore.Level, format string, args ...interface{}) {
	// logrus.WithFields(fields).Logf(level, format, args...)
	if ce := logger.Check(level, fmt.Sprintf(format, args...)); ce != nil {
		fields := AppendFieldsFromContext(ctx, make([]zapcore.Field, 0))
		ce.Write(fields...)
	}
}

func Panic(ctx context.Context, args ...interface{}) {
	log(ctx, zap.PanicLevel, args...)
}

func Fatal(ctx context.Context, args ...interface{}) {
	log(ctx, zap.FatalLevel, args...)
}

func Error(ctx context.Context, args ...interface{}) {
	log(ctx, zap.ErrorLevel, args...)
}

func Warn(ctx context.Context, args ...interface{}) {
	log(ctx, zap.WarnLevel, args...)
}

func Info(ctx context.Context, args ...interface{}) {
	log(ctx, zap.InfoLevel, args...)
}

func Debug(ctx context.Context, args ...interface{}) {
	log(ctx, zap.DebugLevel, args...)
}

func log(ctx context.Context, level zapcore.Level, args ...interface{}) {
	// fields := AppendLogFields(ctx, logrus.Fields{})
	// logrus.WithFields(fields).Log(level, args...)
	if ce := logger.Check(level, fmt.Sprint(args...)); ce != nil {
		fields := AppendFieldsFromContext(ctx, make([]zapcore.Field, 0))
		ce.Write(fields...)
	}
}

func Panicln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.PanicLevel, args...)
}

func Fatalln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.FatalLevel, args...)
}

func Errorln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.ErrorLevel, args...)
}

func Warnln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.WarnLevel, args...)
}

func Infoln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.InfoLevel, args...)
}

func Debugln(ctx context.Context, args ...interface{}) {
	Logln(ctx, zap.DebugLevel, args...)
}

func Logln(ctx context.Context, level zapcore.Level, args ...interface{}) {
	// fields := AppendLogFields(ctx, logrus.Fields{})
	// logrus.WithFields(fields).Logln(level, args...)
	if ce := logger.Check(level, fmt.Sprintln(args...)); ce != nil {
		fields := AppendFieldsFromContext(ctx, make([]zapcore.Field, 0))
		ce.Write(fields...)
	}
}

func InitialLogger() *zap.Logger {
	var err error
	logger, err = NewProduction()
	if err != nil {
		golog.Fatalf("can't initialize zap logger: %v", err)
	}
	zap.ReplaceGlobals(logger)
	defer logger.Sync() // flushes buffer, if any
	return logger

}

// NewProduction builds a sensible production Logger that writes InfoLevel and
// above logs to standard error as JSON.
//
// It's a shortcut for NewProductionConfig().Build(...Option).
func NewProduction(options ...zap.Option) (*zap.Logger, error) {
	return NewProductionConfig().Build(options...)
}

func NewProductionConfig() zap.Config {
	var lv = zapcore.InfoLevel
	if envValue, isSet := os.LookupEnv("LOG_LEVEL"); isSet {
		if err := (&lv).Set(envValue); err != nil {
			golog.Fatalf("Can't parse LOG_LEVEL: %s.", envValue)
		}
	}
	return zap.Config{
		Level:       zap.NewAtomicLevelAt(lv),
		Development: false,
		Sampling: &zap.SamplingConfig{
			Initial:    100,
			Thereafter: 100,
		},
		Encoding:         "json",
		EncoderConfig:    NewProductionEncoderConfig(),
		OutputPaths:      []string{"stderr"},
		ErrorOutputPaths: []string{"stderr"},
		DisableCaller:    true,
	}
}

func NewProductionEncoderConfig() zapcore.EncoderConfig {
	config := zapcore.EncoderConfig{
		LevelKey:       "severity",
		NameKey:        "logger",
		CallerKey:      "caller",
		FunctionKey:    zapcore.OmitKey,
		MessageKey:     "msg",
		StacktraceKey:  "stacktrace",
		LineEnding:     zapcore.DefaultLineEnding,
		EncodeLevel:    zapcore.CapitalLevelEncoder,
		EncodeTime:     zapcore.ISO8601TimeEncoder,
		EncodeDuration: zapcore.MillisDurationEncoder,
		EncodeCaller:   zapcore.ShortCallerEncoder,
	}
	if _, isKibana := os.LookupEnv("LOG_FORMAT_ONPREM"); isKibana {
		config.TimeKey = "@timestamp"
		config.MessageKey = "@message"
		config.LevelKey = "level"
	} else {
		config.TimeKey = "time"
	}
	return config
}

func L() *zap.Logger {
	return logger
}
