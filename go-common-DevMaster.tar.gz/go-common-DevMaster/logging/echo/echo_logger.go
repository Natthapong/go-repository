package echo

import (
	"bufio"
	"bytes"
	"io"
	"net"
	"net/http"
	"time"

	"github.com/labstack/echo/v4"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

func Logger(next echo.HandlerFunc) echo.HandlerFunc {
	return func(c echo.Context) (err error) {
		start := time.Now()
		// var brw *logging.ResponseWriter
		path := c.Request().URL.Path
		method := c.Request().Method

		reader, ctx := logging.LogPreRequest(c.Request().Context(), path, method, c.Request().Body)
		c.SetRequest(c.Request().WithContext(ctx))
		c.Request().Body = reader

		// brw = logging.NewResponseWriter(c.Response().Writer)
		// c.Response().Writer = brw

		// Response
		var resBody *bytes.Buffer
		resBody = new(bytes.Buffer)
		mw := io.MultiWriter(c.Response().Writer, resBody)
		writer := &bodyDumpResponseWriter{Writer: mw, ResponseWriter: c.Response().Writer}
		c.Response().Writer = writer

		if err = next(c); err != nil {
			c.Error(err)
		}

		logging.LogPostRequestWithBytes(c.Request().Context(), path, method, c.Response().Status, start, resBody.Bytes())
		return err
	}
}

type bodyDumpResponseWriter struct {
	io.Writer
	http.ResponseWriter
}

// WriteHeader copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) WriteHeader(code int) {
	w.ResponseWriter.WriteHeader(code)
}

// Write copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Write(b []byte) (int, error) {
	return w.Writer.Write(b)
}

// Flush copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Flush() {
	w.ResponseWriter.(http.Flusher).Flush()
}

// Hijack copy from https://github.com/labstack/echo/blob/master/middleware/body_dump.go
func (w *bodyDumpResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return w.ResponseWriter.(http.Hijacker).Hijack()
}
