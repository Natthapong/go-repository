package echo

import (
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"go.uber.org/zap"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

type blRsHeader struct {
	CorrID            string        `json:"corrId,omitempty"`
	RequestDateTime   string        `json:"requestedDateTime,omitempty"`
	RequestedUniqueID string        `json:"requestedUniqueId,omitempty"`
	ResponseCode      string        `json:"responseCode,omitempty"`
	ResponseDateTime  string        `json:"responseDateTime,omitempty"`
	ResponseDesc      string        `json:"responseDesc,omitempty"`
	ResponseID        string        `json:"responseId,omitempty"`
	Status            string        `json:"status,omitempty"`
	InboxSessionID    string        `json:"inboxSessionId,omitempty"`
	Errors            []interface{} `json:"errors,omitempty"`
}

func BLResponseFailBuilder(c echo.Context, responseCode string, responseDesc string, err error) map[string]interface{} {
	responseId := strings.Replace(uuid.New().String(), "-", "", -1)
	responseDateTime := time.Now().Format("20060102030405")
	var header = &blRsHeader{
		// CorrId: "",
		// RequestDateTime:   "",
		// RequestedUniqueId: "",
		ResponseCode:     responseCode,
		ResponseDateTime: responseDateTime,
		ResponseDesc:     responseDesc,
		ResponseID:       responseId,
		Status:           "F",
	}
	fields := make([]zap.Field, 5)
	fields = append(fields, zap.String("path", c.Path()))
	fields = append(fields, zap.String("statusCode", responseCode))
	fields = append(fields, zap.Error(err))

	var ctx = c.Request().Context()

	if corrID, ok := ctx.Value(logging.KeyCorrID).(string); ok && len(corrID) > 0 {
		header.CorrID = corrID
		fields = append(fields, zap.String("corrId", corrID))
	}
	if inboxSessionID, ok := ctx.Value(logging.KeyInboxSessionID).(string); ok && len(inboxSessionID) > 0 {
		header.InboxSessionID = inboxSessionID
		fields = append(fields, zap.String("inboxSessionId", inboxSessionID))
	}
	if requestUniqueID, ok := ctx.Value(logging.KeyRequestID).(string); ok && len(requestUniqueID) > 0 {
		header.RequestedUniqueID = requestUniqueID
		fields = append(fields, zap.String("rqId", requestUniqueID))
	}
	logging.L().Warn(responseDesc, fields...)
	return map[string]interface{}{"header": &header}
}
