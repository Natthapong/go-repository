package echo

import (
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"go.uber.org/zap"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

type msRsHeader struct {
	CorrID            string        `json:"corrId,omitempty"`
	Errors            []interface{} `json:"errors,omitempty"`
	InboxSessionID    string        `json:"inboxSessionId,omitempty"`
	MobileNo          string        `json:"mobileNo,omitempty"`
	RequestDateTime   string        `json:"requestedDateTime,omitempty"`
	RequestedUniqueID string        `json:"requestedUniqueId,omitempty"`
	ResponseDateTime  string        `json:"responseDateTime,omitempty"`
	ResponseID        string        `json:"responseId,omitempty"`
	StatusCode        string        `json:"statusCode,omitempty"`
	StatusMessage     string        `json:"statusMessage,omitempty"`
}

func MSResponseFailBuilder(c echo.Context, statusCode string, statusMessage string, err error) map[string]interface{} {
	responseID := strings.Replace(uuid.New().String(), "-", "", -1)
	responseDateTime := time.Now().Format("20060102030405")
	var header = &msRsHeader{
		// CorrId: "",
		// RequestDateTime:   "",
		// RequestedUniqueId: "",
		StatusCode:       statusCode,
		ResponseDateTime: responseDateTime,
		StatusMessage:    statusMessage,
		ResponseID:       responseID,
	}
	fields := make([]zap.Field, 5)
	fields = append(fields, zap.String("path", c.Path()))
	fields = append(fields, zap.String("statusCode", statusCode))
	fields = append(fields, zap.Error(err))

	var ctx = c.Request().Context()

	if corrID, ok := ctx.Value(logging.KeyCorrID).(string); ok && len(corrID) > 0 {
		header.CorrID = corrID
		fields = append(fields, zap.String("corrId", corrID))
	}
	if mobileNo, ok := ctx.Value(logging.KeyMobileNo).(string); ok && len(mobileNo) > 0 {
		header.MobileNo = mobileNo
		fields = append(fields, zap.String("mobileNo", mobileNo))
	}
	if inboxSessionID, ok := ctx.Value(logging.KeyInboxSessionID).(string); ok && len(inboxSessionID) > 0 {
		header.InboxSessionID = inboxSessionID
		fields = append(fields, zap.String("inboxSessionId", inboxSessionID))
	}
	if requestUniqueID, ok := ctx.Value(logging.KeyRequestID).(string); ok && len(requestUniqueID) > 0 {
		header.RequestedUniqueID = requestUniqueID
		fields = append(fields, zap.String("rqId", requestUniqueID))
	}

	return map[string]interface{}{"header": &header}
}
