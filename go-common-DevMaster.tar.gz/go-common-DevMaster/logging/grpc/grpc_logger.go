package grpc

import (
	"context"
	"encoding/json"
	"time"

	"go.uber.org/zap"
	"google.golang.org/grpc"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

func Logger(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (resp interface{}, err error) {
	start := time.Now()
	var method string
	if logging.IsLevelEnabled(zap.DebugLevel) {
		method = info.FullMethod
		reqStr, _ := json.Marshal(req)
		logPreRequest(method, reqStr)
	}

	res, err := handler(ctx, req)
	if logging.IsLevelEnabled(zap.DebugLevel) {
		resStr, _ := json.Marshal(res)
		logPostRequest(method, start, resStr)
	}
	return res, err
}

func logPreRequest(path string, data []byte) {
	zap.L().Debug("Entering",
		zap.String("path", path),
		zap.ByteString("data", data),
	)
}

func logPostRequest(path string, startTime time.Time, response []byte) {
	endTime := time.Now()
	latency := endTime.Sub(startTime)
	zap.L().Debug("Exiting",
		zap.String("path", path),
		zap.ByteString("response", response),
		zap.Duration("responseTime", latency),
	)
}
