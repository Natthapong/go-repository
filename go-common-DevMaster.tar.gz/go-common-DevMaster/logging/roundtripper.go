package logging

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	"go.uber.org/zap"
)

const (
	SuccessMessage = "HC SUCCESS"
	FailureMessage = "HC FAILURE"
)

// This type implements the http.RoundTripper interface
type LoggingRoundTripper struct {
	next   http.RoundTripper
	logger *zap.Logger
}

func NewLoggingRoundTripper(next http.RoundTripper, logger *zap.Logger) *LoggingRoundTripper {
	return &LoggingRoundTripper{
		next:   next,
		logger: logger,
	}
}

func (lrt *LoggingRoundTripper) RoundTrip(req *http.Request) (res *http.Response, e error) {
	// Do "before sending requests" actions here.
	// Request
	reqBody := []byte{}
	if req.Body != nil { // Read
		reqBody, _ = ioutil.ReadAll(req.Body)
	}
	req.Body = ioutil.NopCloser(bytes.NewBuffer(reqBody)) // Reset
	startTime := time.Now()

	// Send the request, get the response (or the error)
	res, e = lrt.next.RoundTrip(req)

	// Handle the result.
	latency := time.Since(startTime)

	fields := []zap.Field{
		zap.Duration("latency", latency),
		zap.String("url", req.URL.String()),
		zap.String("method", req.Method),
	}

	if reqHeaders, ok := req.Context().Value("reqHeaders").(map[string]interface{}); ok {
		if ce := lrt.logger.Check(zap.DebugLevel, "check reqHeaders"); ce != nil {
			ce.Write(zap.String("reqHeaders", fmt.Sprintf("%#v", reqHeaders)))
		}
		if v, ok := reqHeaders["corrId"].(string); ok {
			fields = append(fields, zap.String("corrId", v))
		}
		if v, ok := reqHeaders["profileId"].(string); ok {
			fields = append(fields, zap.String("profileId", v))
		}
		// } else {
		// 	lrt.logger.Warn(fmt.Sprintf("reqHeaders invalid type %#v", req.Context().Value("reqHeaders")))
	}

	if e != nil {
		fields = append(fields, zap.String("error", e.Error()))
		lrt.logger.Error(FailureMessage, fields...)
	} else {
		fields = append(fields, zap.Int("status", res.StatusCode))
		if ce := lrt.logger.Check(zap.DebugLevel, SuccessMessage); ce != nil {
			resBody := []byte{}
			if res.Body != nil { // Read
				resBody, _ = ioutil.ReadAll(res.Body)
			}
			res.Body = ioutil.NopCloser(bytes.NewBuffer(resBody)) // Reset
			fields = append(fields,
				zap.ByteString("request", reqBody),
				zap.ByteString("response", resBody),
			)
			ce.Write(fields...)
		} else {
			lrt.logger.Info(SuccessMessage, fields...)
		}
	}
	return
}
