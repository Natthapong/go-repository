package logging

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo/v4"
	"go.kbtg.tech/715_MicroService/go-common/core_message"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

type key int

const (
	KeyCorrID key = iota
	KeyRequestID
	KeyProfileID
	KeyMobileNo
	KeyInboxSessionID
	// ...
)

type RequestHeader struct {
	Header Header `json:"header"`
}
type Header struct {
	CorrID          string `json:"corrId,omitempty"`
	MobileNo        string `json:"mobileNo,omitempty"`
	ProfileID       string `json:"profileId,omitempty"`
	RequestUniqueID string `json:"requestUniqueId,omitempty"`
	InboxSessionID  string `json:"inboxSessionId,omitempty"`
}

func BuildContext(ctx context.Context, data []byte) context.Context {
	requestHeader := RequestHeader{}
	err := json.Unmarshal(data, &requestHeader)
	if err != nil {
		return ctx
	}

	if len(requestHeader.Header.CorrID) > 0 {
		ctx = context.WithValue(ctx, KeyCorrID, requestHeader.Header.CorrID)
	}
	if len(requestHeader.Header.MobileNo) > 0 {
		ctx = context.WithValue(ctx, KeyMobileNo, requestHeader.Header.MobileNo)
	}
	if len(requestHeader.Header.ProfileID) > 0 {
		ctx = context.WithValue(ctx, KeyProfileID, requestHeader.Header.ProfileID)
	}
	if len(requestHeader.Header.InboxSessionID) > 0 {
		ctx = context.WithValue(ctx, KeyInboxSessionID, requestHeader.Header.InboxSessionID)
	}
	if len(requestHeader.Header.RequestUniqueID) > 0 {
		ctx = context.WithValue(ctx, KeyRequestID, requestHeader.Header.RequestUniqueID)
	}

	return ctx
}

func LogPreRequest(ctx context.Context, path string, method string, requestBody io.ReadCloser) (io.ReadCloser, context.Context) {
	if ce := logger.Check(zap.InfoLevel, "Entering"); ce != nil {
		fields := []zapcore.Field{
			zap.String("path", path),
			zap.String("method", method),
		}
		// Read raw data and re-assign to Body maybe effect to performance.
		var data []byte

		if requestBody != nil {
			data, _ = ioutil.ReadAll(requestBody)
			if mustLogBody() {
				fields = append(fields, zap.ByteString("data", data))
			}

			ctx = BuildContext(ctx, data)
			fields = AppendFieldsFromContext(ctx, fields)

			// Restore the io.ReadCloser to its original state
			requestBody = ioutil.NopCloser(bytes.NewBuffer(data))
		}

		ce.Write(fields...)
	}
	return requestBody, ctx
}

func LogPostRequest(ctx context.Context, path string, method string, statusCode int, startTime time.Time, brw *ResponseWriter) {
	if brw != nil {
		LogPostRequestWithBytes(ctx, path, method, statusCode, startTime, brw.Body.Bytes())
	} else {
		LogPostRequestWithBytes(ctx, path, method, statusCode, startTime, []byte{})
	}
}

func LogPostRequestWithBytes(ctx context.Context, path string, method string, statusCode int, startTime time.Time, bytes []byte) {
	if ce := logger.Check(zap.InfoLevel, "Exiting"); ce != nil {
		fields := []zapcore.Field{
			zap.String("path", path),
			zap.String("method", method),
			zap.Int("status", statusCode),
			zap.Duration("latency", time.Since(startTime)),
		}
		fields = AppendFieldsFromContext(ctx, fields)

		if mustLogBody() && len(bytes) > 0 {
			fields = append(fields, zap.ByteString("response", bytes))
		}
		ce.Write(fields...)
	}
}

func mustLogBody() bool {
	logBody, _ := strconv.ParseBool(os.Getenv("LOG_HTTP_BODY"))
	return logBody
}

func GetStringFromRequestBody(requestBody io.ReadCloser) (string, time.Time) {
	buf := new(bytes.Buffer)
	_, _ = buf.ReadFrom(requestBody)
	return buf.String(), time.Now()
}

func LogPreBLGet(c echo.Context, ctx context.Context, body string) context.Context {
	var data []byte
	var err error
	path := c.Request().URL.Path
	method := c.Request().Method

	if ce := logger.Check(zap.InfoLevel, "Entering"); ce != nil {
		// Read raw data and re-assign to Body maybe effect to performance.
		// var data []byte
		requestBody := strings.NewReader(body)
		fields := []zapcore.Field{
			zap.String("path", path),
			zap.String("method", method),
		}

		if IsLevelEnabled(zap.DebugLevel) {
			var m core_message.BaseDebugRequest
			json.NewDecoder(requestBody).Decode(&m)
			m.Header.OS = m.Header.MobileOS
			m.Header.AppVer = m.Header.AppVersion
			m.Header.Rqdt = m.Header.RequestDateTime
			m.Header.CorId = m.Header.CorrId
			m.Header.Inbxsid = m.Header.InboxSessionId
			m.Header.Rquid = m.Header.RequestUniqueId

			m.Header.MobileOS = ""
			m.Header.AppVersion = ""
			m.Header.RequestDateTime = ""
			m.Header.CorrId = ""
			m.Header.InboxSessionId = ""
			m.Header.RequestUniqueId = ""
			data, err = json.Marshal(m)
		} else {
			var m core_message.BaseInfoRequest
			json.NewDecoder(requestBody).Decode(&m)
			m.Header.OS = m.Header.MobileOS
			m.Header.AppVer = m.Header.AppVersion
			m.Header.Rqdt = m.Header.RequestDateTime
			m.Header.CorId = m.Header.CorrId

			m.Header.MobileOS = ""
			m.Header.AppVersion = ""
			m.Header.RequestDateTime = ""
			m.Header.CorrId = ""
			data, err = json.Marshal(m)
		}

		if err == nil {
			fields = append(fields, zap.ByteString("data", data))

			ctx = BuildContext(ctx, data)
			fields = AppendFieldsFromContext(ctx, fields)

			ce.Write(fields...)
		} // TODO - handle error
	}
	return ctx
}

func LogPostBLGetOne(c echo.Context, ctx context.Context, statusCode int, startTime time.Time, ip interface{}) {
	var rs core_message.DebugResponseOne
	// LogPostBLGet2(c, ctx, statusCode, startTime, ip, &rs)
	method, path, fields, raw, er1 := LogPostBLGet(c, ctx, statusCode, startTime, ip)
	if ce := logger.Check(zap.InfoLevel, "Exiting"); ce != nil {
		if er1 == nil {
			s := string(raw)
			json.NewDecoder(strings.NewReader(s)).Decode(&rs)
			rs.Header.Rscode = rs.Header.ResponseCode
			rs.Header.Rsdesc = rs.Header.ResponseDesc
			rs.Header.Rquid = rs.Header.RequestedUniqueId
			rs.Header.Rqdt = rs.Header.RequestDateTime
			rs.Header.Rsid = rs.Header.ResponseId
			rs.Header.Rsdt = rs.Header.ResponseDateTime
			rs.Header.Inbxsid = rs.Header.InboxSessionId
			rs.Header.Corid = rs.Header.CorrId

			rs.Header.ResponseCode = ""
			rs.Header.ResponseDesc = ""
			rs.Header.RequestedUniqueId = ""
			rs.Header.RequestDateTime = ""
			rs.Header.ResponseId = ""
			rs.Header.ResponseDateTime = ""
			rs.Header.InboxSessionId = ""
			rs.Header.CorrId = ""

			data, er2 := json.Marshal(rs)
			if er2 == nil {
				fields = append(fields,
					zap.ByteString("response", data),
					zap.String("path", path),
					zap.String("method", method),
				)
				fields = AppendFieldsFromContext(ctx, fields)
				ce.Write(fields...)
			} // TODO - handle error
		}
	}
}

func LogPostBLGetList(c echo.Context, ctx context.Context, statusCode int, startTime time.Time, ip interface{}) {
	var rs core_message.DebugResponseList
	// LogPostBLGet(c, ctx, statusCode, startTime, ip, &rs)
	method, path, fields, raw, er1 := LogPostBLGet(c, ctx, statusCode, startTime, ip)
	if ce := logger.Check(zap.InfoLevel, fmt.Sprintf("Exiting %s %s", method, path)); ce != nil {
		if er1 == nil {
			s := string(raw)
			json.NewDecoder(strings.NewReader(s)).Decode(&rs)
			rs.Header.Rscode = rs.Header.ResponseCode
			rs.Header.Rsdesc = rs.Header.ResponseDesc
			rs.Header.Rquid = rs.Header.RequestedUniqueId
			rs.Header.Rqdt = rs.Header.RequestDateTime
			rs.Header.Rsid = rs.Header.ResponseId
			rs.Header.Rsdt = rs.Header.ResponseDateTime
			rs.Header.Inbxsid = rs.Header.InboxSessionId
			rs.Header.Corid = rs.Header.CorrId

			rs.Header.ResponseCode = ""
			rs.Header.ResponseDesc = ""
			rs.Header.RequestedUniqueId = ""
			rs.Header.RequestDateTime = ""
			rs.Header.ResponseId = ""
			rs.Header.ResponseDateTime = ""
			rs.Header.InboxSessionId = ""
			rs.Header.CorrId = ""

			data, er2 := json.Marshal(rs)
			if er2 == nil {
				fields = append(fields,
					zap.ByteString("response", data),
				)
				fields = AppendFieldsFromContext(ctx, fields)
			}
			ce.Write(fields...)
		}
	}
}

func LogPostBLGet2(c echo.Context, ctx context.Context, statusCode int, startTime time.Time, ip interface{}, op interface{}) {
	endTime := time.Now()
	latency := endTime.Sub(startTime)
	path := c.Request().URL.Path
	method := c.Request().Method

	if ce := logger.Check(zap.InfoLevel, "Exiting"); ce != nil {
		fields := []zapcore.Field{
			zap.String("path", path),
			zap.String("method", method),
			zap.Int("status", statusCode),
			zap.Int64("latency", latency.Milliseconds()),
		}

		raw, er1 := json.Marshal(ip)
		if er1 == nil {
			s := string(raw)
			json.NewDecoder(strings.NewReader(s)).Decode(op)
			data, er2 := json.Marshal(op)
			if er2 == nil {
				fields = append(fields,
					zap.ByteString("response", data),
				)
				fields = AppendFieldsFromContext(ctx, fields)
				ce.Write(fields...)
			} else {
				logger.Error(fmt.Sprintf("Unexpected error %v", er2), fields...)
			}
		}
	}
}

func LogPostBLGet(c echo.Context, ctx context.Context, statusCode int, startTime time.Time, ip interface{}) (string, string, []zapcore.Field, []byte, error) {
	endTime := time.Now()
	latency := endTime.Sub(startTime)
	path := c.Request().URL.Path
	method := c.Request().Method

	fields := []zapcore.Field{
		zap.String("path", path),
		zap.String("method", method),
		zap.Int("status", statusCode),
		zap.Int64("latency", latency.Milliseconds()),
	}

	raw, er1 := json.Marshal(ip)
	return method, path, fields, raw, er1
}
