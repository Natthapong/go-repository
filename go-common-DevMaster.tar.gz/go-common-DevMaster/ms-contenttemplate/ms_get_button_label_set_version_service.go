package mscontenttemplate

type (
	// ButtonLabelsetVersionRetriever is responsible for retrieving all button label set versions.
	ButtonLabelsetVersionRetriever interface {
		GetVersions() ([]ButtonLabelSetVersion, error)
	}
)
