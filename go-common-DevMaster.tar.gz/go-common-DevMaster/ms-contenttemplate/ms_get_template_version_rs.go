package mscontenttemplate

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type (
	// GetContentTemplateVersionsResponse represents the response of get content template request
	GetContentTemplateVersionsResponse struct {
		Header ms.MsResponseHeader                    `json:"header,omitempty"`
		Data   GetContentTemplateVersionsResponseData `json:"data,omitempty"`
	}

	// GetContentTemplateVersionsResponseData represents the data part of a get content template response
	GetContentTemplateVersionsResponseData struct {
		TemplateVersionList []TemplateVersion `json:"templateVersionList,omitempty"`
	}

	// TemplateVersion represents the template version
	TemplateVersion struct {
		ID      string `json:"id,omitempty"`
		Version int64  `json:"version,omitempty"`
	}
)
