package mscontenttemplate

type (
	// ContentTemplateVersionRetriever is responsible for retrieving all content template versions.
	ContentTemplateVersionRetriever interface {
		GetVersions() ([]TemplateVersion, error)
	}
)
