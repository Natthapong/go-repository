package mscontenttemplate

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type (
	// GetContentTemplateVersionsRequest represents the get content template request
	GetContentTemplateVersionsRequest struct {
		Header ms.MsRequestHeader `json:"header,omitempty"`
	}
)
