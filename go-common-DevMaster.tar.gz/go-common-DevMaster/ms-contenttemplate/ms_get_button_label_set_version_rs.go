package mscontenttemplate

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type (
	// GetButtonLabelSetVersionsResponse represents the response of get button label set request
	GetButtonLabelSetVersionsResponse struct {
		Header ms.MsResponseHeader                  `json:"header,omitempty"`
		Data   GetButtonLabelSetVersionResponseData `json:"data,omitempty"`
	}
	// GetButtonLabelSetVersionResponseData represents the data part of a get button label set version response
	GetButtonLabelSetVersionResponseData struct {
		ButtonLabelSetVersions []ButtonLabelSetVersion `json:"buttonLabelSetVersionList,omitempty"`
	}
	// ButtonLabelSetVersion represents the button label set version
	ButtonLabelSetVersion struct {
		ID      string `json:"id,omitempty"`
		Version int64  `json:"version,omitempty"`
	}
)
