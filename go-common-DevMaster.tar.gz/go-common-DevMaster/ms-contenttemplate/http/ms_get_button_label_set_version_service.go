package http

import (
	"strings"
	"time"

	"go.uber.org/zap"
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
	contenttemplate "go.kbtg.tech/715_MicroService/go-common/ms-contenttemplate"
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
	"go.kbtg.tech/715_MicroService/go-common/util/web_client"

	"github.com/google/uuid"
)

var postObject = web_client.PostObject

// ButtonLabelSetVersionService provides the implementation of ButtonLabelSetVersionService interface
// using HTTP protocol
type ButtonLabelSetVersionService struct {
	url    string
	logger *zap.Logger
}

// NewHTTPButtonLabelSetVersionService initializes a HTTPButtonLabelSetVersionService
func NewHTTPButtonLabelSetVersionService(url string) *ButtonLabelSetVersionService {
	return NewHTTPButtonLabelSetVersionServiceWithLogger(url, zap.L())
}
func NewHTTPButtonLabelSetVersionServiceWithLogger(url string, logger *zap.Logger) *ButtonLabelSetVersionService {
	return &ButtonLabelSetVersionService{url: url, logger: logger}
}

// GetVersions returns all button label set versions
func (s *ButtonLabelSetVersionService) GetVersions() ([]contenttemplate.ButtonLabelSetVersion, error) {
	id := uuid.New().String()
	now := time.Now()
	req := contenttemplate.GetContentTemplateVersionsRequest{
		Header: ms.MsRequestHeader{
			AppId:           "715",
			RequestUniqueId: strings.Replace(id, "-", "", -1),
			RequestDateTime: &now,
			CorrId:          uuid.New().String(),
			Language:        message.Thai,
		},
	}

	client, err := postObject(s.url, req)
	if err != nil {
		s.logger.Error("Failed to retrieve button label set versions. " + err.Error())
		return nil, err
	}

	var res contenttemplate.GetButtonLabelSetVersionsResponse
	err = client.Decode(&res)
	if err != nil {
		s.logger.Error("Failed to decode get button label set version response. " + err.Error())
		return nil, err
	}

	return res.Data.ButtonLabelSetVersions, nil
}
