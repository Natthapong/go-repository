package http

import (
	"strings"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
	contenttemplate "go.kbtg.tech/715_MicroService/go-common/ms-contenttemplate"
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

// TemplateVersionService provides the implementation of TemplateVersionService interface
// using HTTP protocol
type TemplateVersionService struct {
	url    string
	logger *zap.Logger
}

// NewHTTPTemplateVersionService initializes an instance of HTTPTemplateVersionService
func NewHTTPTemplateVersionService(url string) *TemplateVersionService {
	return NewHTTPTemplateVersionServiceWithLogger(url, zap.L())
}
func NewHTTPTemplateVersionServiceWithLogger(url string, logger *zap.Logger) *TemplateVersionService {
	return &TemplateVersionService{url: url, logger: logger}
}

// GetVersions returns all content template versions
func (s *TemplateVersionService) GetVersions() ([]contenttemplate.TemplateVersion, error) {
	id := uuid.New().String()
	now := time.Now()
	req := contenttemplate.GetContentTemplateVersionsRequest{
		Header: ms.MsRequestHeader{
			AppId:           "715",
			RequestUniqueId: strings.Replace(id, "-", "", -1),
			RequestDateTime: &now,
			CorrId:          uuid.New().String(),
			Language:        message.Thai,
		},
	}

	client, err := postObject(s.url, req)
	if err != nil {
		s.logger.Error("Failed to retrieve template versions. " + err.Error())
		return nil, err
	}

	var res contenttemplate.GetContentTemplateVersionsResponse
	err = client.Decode(&res)
	if err != nil {
		s.logger.Error("Failed to decode get template versions response. " + err.Error())
		return nil, err
	}

	return res.Data.TemplateVersionList, nil
}
