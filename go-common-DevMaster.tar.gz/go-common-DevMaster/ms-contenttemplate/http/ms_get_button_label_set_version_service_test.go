package http

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/stretchr/testify/assert"
	"testing"
	ct "go.kbtg.tech/715_MicroService/go-common/ms-contenttemplate"
)

func TestGetButtonSession(t *testing.T) {
	testCases := []struct {
		name        string
		response    interface{}
		expectedRs  interface{}
		errPostObj  error
		expectedErr error
	}{
		{"Success",
			ct.GetButtonLabelSetVersionsResponse{Data: ct.GetButtonLabelSetVersionResponseData{ButtonLabelSetVersions: []ct.ButtonLabelSetVersion{{ID: "1", Version: 1}}}},
			[]ct.ButtonLabelSetVersion{{ID: "1", Version: 1}},
			nil,
			nil,
		},
		{"HttpResponseError",
			ct.GetButtonLabelSetVersionsResponse{},
			[]ct.ButtonLabelSetVersion(nil),
			fmt.Errorf("err"),
			fmt.Errorf("err"),
		},
		{"DecodeFail",
			1,
			[]ct.ButtonLabelSetVersion(nil),
			nil,
			fmt.Errorf("decode err"),
		},
	}
	old := postObject
	defer func() { postObject = old }()
	service := NewHTTPButtonLabelSetVersionService("TestGetButtonVersionsUrl")

	for _, tc := range testCases {
		postObject = func(url string, data interface{}) (*json.Decoder, error) {
			b, _ := json.Marshal(tc.response)
			bytes.NewReader(b)
			return json.NewDecoder(bytes.NewReader(b)), tc.errPostObj
		}
		rs, err := service.GetVersions()
		assert.Equal(t, tc.expectedRs, rs, tc.name)
		if tc.name == "DecodeFail" {
			_, errDecodeType := err.(*json.UnmarshalTypeError)
			assert.Equal(t, errDecodeType, true, tc.name)
		} else {
			assert.Equal(t, tc.expectedErr, err, tc.name)
		}
	}
}
