package mscontenttemplate

import (
	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type (
	// GetButtonLabelSetVersionsRequest represents the get button label set version request
	GetButtonLabelSetVersionsRequest struct {
		Header ms.MsRequestHeader `json:"header,omitempty"`
	}
)
