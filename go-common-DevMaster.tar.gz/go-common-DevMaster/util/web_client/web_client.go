package web_client

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"io"
	"io/ioutil"
	"net/http"
	"time"

	"go.kbtg.tech/715_MicroService/go-common/logging"
	"go.uber.org/zap"
)

// type MockClient struct {
// 	DoFunc func(req *http.Request) (*http.Response, error)
// }

// // Do is the mock client's `Do` func
// func (m *MockClient) Do(req *http.Request) (*http.Response, error) {
// 	// coming soon!
// }

type Doer interface {
	Do(req *http.Request) (*http.Response, error)
}

const (
	contentType      string = "application/json"
	handshakeTimeout        = time.Duration(5 * time.Second)
	requestTimeout          = time.Duration(20 * time.Second)
)

var (
	HTTPClient         Doer
	InsecureHTTPClient Doer
)

func init() {
	var logger *zap.Logger
	var err error
	if logger, err = logging.NewProduction(); err != nil {
		logger = zap.L()
	}
	var rt http.RoundTripper = &http.Transport{
		TLSHandshakeTimeout: handshakeTimeout,
		TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
	}

	// rt = NewTracingRoundTripper(rt)
	rt = logging.NewLoggingRoundTripper(rt, logger)
	InsecureHTTPClient = &http.Client{
		Transport: rt,
		Timeout:   requestTimeout}

	var rt2 http.RoundTripper = http.DefaultTransport
	// rt2 = NewTracingRoundTripper(rt2)
	rt2 = logging.NewLoggingRoundTripper(rt2, logger)
	HTTPClient = &http.Client{
		Transport: rt2,
		Timeout:   requestTimeout}
}
func Get(url string, insecureSkipVerify bool) (*http.Response, error) {
	return GetWithContext(nil, url, insecureSkipVerify)
}
func GetWithContext(ctx context.Context, url string, insecureSkipVerify bool) (*http.Response, error) {
	var client Doer
	if insecureSkipVerify {
		client = InsecureHTTPClient
	} else {
		client = HTTPClient
	}
	req, err := newRequest(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	return client.Do(req)
}

// func GetObject(url string, insecureSkipVerify bool, retryConfig []int) (*json.Decoder, error) {
func GetObject(url string, insecureSkipVerify bool) (*json.Decoder, error) {
	res, err := Get(url, insecureSkipVerify)
	// if err != nil && len(retryConfig) > 0 {
	// 	var attempts = -1
	// 	retry(retryConfig, attempts, func() error {
	// 		res, err = Get(url, insecureSkipVerify)
	// 		return err
	// 	})
	// }
	if err != nil {
		return nil, err
	}
	return json.NewDecoder(res.Body), nil
}

func retry(retryConfig []int, attempts int, f func() error) error {
	if attempts++; attempts < len(retryConfig) {
		time.Sleep(time.Duration(retryConfig[attempts]) * time.Millisecond)
		zap.L().Debug("Doing retry postObject")
		err := f()
		if err != nil {
			zap.S().Warnf("retry %v w %vms", attempts+1, (time.Duration(retryConfig[attempts]) * time.Millisecond).Milliseconds())
			return retry(retryConfig, attempts, f)
		}
		return nil
	}
	return nil
}

func newRequest(ctx context.Context, method, url string, body io.Reader) (*http.Request, error) {
	if ctx != nil {
		return http.NewRequestWithContext(ctx, method, url, body)
	}
	return http.NewRequest(method, url, body)
}

// PostWithContext sends a post request to the URL with the body & context for logging
func PostWithContext(ctx context.Context, url string, skipSSL bool, data interface{}, headers http.Header) (*http.Response, error) {
	jsonBytes, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}
	req, err := newRequest(ctx, http.MethodPost, url, bytes.NewReader(jsonBytes))
	if err != nil {
		return nil, err
	}
	// if jsonBytes != nil && len(jsonBytes) > 0 {
	// 	req.Header.Set("Content-Type", "application/json")
	// }
	req.Header = headers
	if skipSSL {
		return InsecureHTTPClient.Do(req)
	} else {
		return HTTPClient.Do(req)
	}
}

// Post sends a post request to the URL with the body
func Post(url string, skipSSL bool, data interface{}, headers http.Header) (*http.Response, error) {
	return PostWithContext(nil, url, skipSSL, data, headers)
}

// PostObject to post http request
func PostObject(url string, data interface{}) (*json.Decoder, error) {
	return PostObjectWithSkipSSLOption(url, false, data)
}

// PostObjectWithSkipSSLOption to post http request with option to skip SSL verification
func PostObjectWithSkipSSLOption(url string, skipSSL bool, data interface{}) (*json.Decoder, error) {
	return PostObjectWithContext(nil, url, skipSSL, data)
}

// PostObjectWithContext to post http request with context and option to skip SSL verification
func PostObjectWithContext(ctx context.Context, url string, InsecureSkipVerify bool, data interface{}) (*json.Decoder, error) {
	headers := http.Header{}
	headers.Set("Content-Type", contentType)
	res, err := PostWithContext(ctx, url, InsecureSkipVerify, data, headers)
	if err != nil {
		return nil, err
	}

	if res.StatusCode == 503 {
		err = errors.New("503 Service Unavailable")
		return nil, err
	}

	defer res.Body.Close()
	resBody := []byte{}
	if res.Body != nil { // Read
		resBody, _ = ioutil.ReadAll(res.Body)
	}
	return json.NewDecoder(bytes.NewBuffer(resBody)), nil
}
