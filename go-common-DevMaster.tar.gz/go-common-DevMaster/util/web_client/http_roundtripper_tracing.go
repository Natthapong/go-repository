package web_client

import (
	"net/http"

	opentracing "github.com/opentracing/opentracing-go"
	"github.com/opentracing/opentracing-go/ext"
)

type TracingRoundTripper struct {
	next http.RoundTripper
}

func NewTracingRoundTripper(next http.RoundTripper) *TracingRoundTripper {
	return &TracingRoundTripper{
		next: next,
	}
}

func (rt *TracingRoundTripper) RoundTrip(req *http.Request) (resp *http.Response, err error) {
	if parentSpan := opentracing.SpanFromContext(req.Context()); parentSpan != nil {
		tracer := opentracing.GlobalTracer()
		sp := opentracing.StartSpan("call "+req.URL.String(), opentracing.ChildOf(parentSpan.Context()))
		defer sp.Finish()
		ext.SpanKindRPCClient.Set(sp)
		ext.HTTPUrl.Set(sp, req.URL.String())
		ext.HTTPMethod.Set(sp, req.Method)
		tracer.Inject(sp.Context(), opentracing.HTTPHeaders, opentracing.HTTPHeadersCarrier(req.Header))
		defer func() {
			if err != nil || (resp != nil && !(resp.StatusCode >= 200 && resp.StatusCode <= 299)) {
				// sp.LogFields(spanlog.Error(err))
				ext.Error.Set(sp, true)
			}
			if resp != nil {
				ext.HTTPStatusCode.Set(sp, uint16(resp.StatusCode))
			}
		}()
	}
	return rt.next.RoundTrip(req)
}
