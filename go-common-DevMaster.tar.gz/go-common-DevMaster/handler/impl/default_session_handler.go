package impl

import (
	"bytes"
	"context"
	"encoding/json"
	"io/ioutil"
	"net/http"

	"github.com/labstack/echo/v4"
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
	log "go.kbtg.tech/715_MicroService/go-common/logging"
	session "go.kbtg.tech/715_MicroService/go-common/session"
)

const (
	layoutDate string = "2006-01-02T15:04:00Z07:00"
	layoutTime string = "2006-01-02T15:04"
)

type DefaultSessionHandler struct {
	MsSessionService session.MsSessionService
	rsbuilder        message.ResponseBuilder
}

type SessionResponse struct {
	Header *SessionResponseHeader `json:"header"`
}

func NewSessionHandler(msSessionService session.MsSessionService) *DefaultSessionHandler {
	return &DefaultSessionHandler{MsSessionService: msSessionService, rsbuilder: &message.DefaultResponseBuilder{}}
}

func (p *DefaultSessionHandler) CheckSession() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			ctx := c.Request().Context()

			var body message.BaseRequest
			err := json.NewDecoder(c.Request().Body).Decode(&body)

			if err != nil {
				res := p.BuildFailResponse(body.Header, "400", "Bad Request", "400", "Error no parser request")
				return c.JSON(http.StatusBadRequest, res)
			}
			if len(body.Header.InboxSessionId) == 0 {
				res := p.BuildFailResponse(body.Header, "401", "Bad Request", "401", "Not authenticated: Lack of InboxSessionId")
				return c.JSON(http.StatusOK, res)
			}
			sessionRq := session.SessionRq{}
			sessionRq.Header.InboxSessionId = body.Header.InboxSessionId
			sessionRq.Header.CorrId = body.Header.CorrId
			// get from redis
			session, errSession := p.MsSessionService.GetSession(sessionRq)
			if errSession != nil {
				log.Errorf(ctx, "Call ms-session got error: %s", errSession)
				res := p.BuildFailResponse(body.Header, "500", "Fail", "503", "Network Error: Call ms-session got error.||No route to host: "+p.MsSessionService.GetURL())
				return c.JSON(http.StatusInternalServerError, res)
			} else if len(session.ProfileId) == 0 {
				res := p.BuildFailResponse(body.Header, "401", "Invalid session", "", "")
				res.Header.InboxSessionId = "invalid"
				res.Header.ResponseId = ""
				res.Header.ResponseDateTime = ""
				return c.JSON(http.StatusOK, res)
			} else if len(session.MobileNo) == 0 {
				res := p.BuildFailResponse(body.Header, "401", "Invalid session", "", "")
				res.Header.InboxSessionId = "invalid"
				res.Header.ResponseId = ""
				res.Header.ResponseDateTime = ""
				return c.JSON(http.StatusOK, res)
			}

			// set mobile no
			body.Header.MobileNo = session.MobileNo
			//if len(body.Header.MobileNo) == 0 && len(session.MobileNo) > 0 {
			//	ctx = context.WithValue(ctx, "mobileNo", session.MobileNo)
			//}

			// set profileId
			body.Header.ProfileId = session.ProfileId
			ctx = context.WithValue(ctx, "session", session)

			c.SetRequest(c.Request().WithContext(ctx))

			reqBodyBytes := new(bytes.Buffer)
			_ = json.NewEncoder(reqBodyBytes).Encode(&body)
			c.Request().Body = ioutil.NopCloser(bytes.NewReader(reqBodyBytes.Bytes()))
			return next(c)
		}
	}
}

func prettyPrint(i interface{}) string {
	s, _ := json.MarshalIndent(i, "", "\t")
	return string(s)
}

func (p *DefaultSessionHandler) BuildFailResponse(requestHeader message.RequestHeader, responseCode string, responseDesc string, errCode string, errDesc string) SessionResponse {
	rsHeader := p.rsbuilder.CreateResponseHeader(requestHeader)
	rsHeader = p.rsbuilder.BuildFailedBusinessResponseWithMessageAndCode(rsHeader, errDesc, errCode)
	rsHeader.ResponseCode = responseCode
	rsHeader.ResponseDesc = responseDesc
	var status message.ResponseStatus
	rsHeader.Status = status.FromString("F")

	rsSessionHeader := &SessionResponseHeader{}
	rsSessionHeader.Status = rsHeader.Status
	rsSessionHeader.ResponseCode = rsHeader.ResponseCode
	rsSessionHeader.ResponseDesc = rsHeader.ResponseDesc
	rsSessionHeader.MobileNo = rsHeader.MobileNo
	rsSessionHeader.RequestedUniqueId = rsHeader.RequestedUniqueId
	rsSessionHeader.RequestDateTime = rsHeader.RequestDateTime
	rsSessionHeader.ResponseId = rsHeader.ResponseId
	rsSessionHeader.ResponseDateTime = rsHeader.ResponseDateTime
	rsSessionHeader.InboxSessionId = rsHeader.InboxSessionId
	rsSessionHeader.Errors = rsHeader.Errors
	rsSessionHeader.CorrId = rsHeader.CorrId

	return SessionResponse{Header: rsSessionHeader}
}

type SessionResponseHeader struct {
	Status            message.ResponseStatus `json:"status" bson:"status"`
	ResponseCode      string                 `json:"responseCode" bson:"responseCode"`
	ResponseDesc      string                 `json:"responseDesc,omitempty" bson:"responseDesc"`
	MobileNo          string                 `json:"-"`
	RequestedUniqueId string                 `json:"requestedUniqueId" bson:"requestedUniqueId"`
	RequestDateTime   string                 `json:"requestedDateTime,omitempty" bson:"requestDateTime"`
	ResponseId        string                 `json:"responseId,omitempty" bson:"responseId"`
	ResponseDateTime  string                 `json:"responseDateTime,omitempty" bson:"responseDateTime"`
	InboxSessionId    string                 `json:"inboxSessionId,omitempty" bson:"inboxSessionId"`
	Errors            []message.ErrorMessage `json:"errors,omitempty" bson:"errors"`
	CorrId            string                 `json:"corrId" bson:"corrId"`
}
