package impl

import (
	"context"
	"net/http"

	"github.com/labstack/echo/v4"
	"go.uber.org/zap"
	"go.kbtg.tech/715_MicroService/go-common/logging"
	"go.kbtg.tech/715_MicroService/go-common/middleware"
	session "go.kbtg.tech/715_MicroService/go-common/session"
)

type SessionAuth struct {
	MsSessionService session.MsSessionService
}

func NewSessionAuth(msSessionService session.MsSessionService) *SessionAuth {
	return &SessionAuth{MsSessionService: msSessionService}
}

func (p *SessionAuth) CheckSession() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {

			ctx := c.Request().Context()

			// Get these headers from GetHeaderInfo middleware
			var inboxSessionID = c.Request().Header.Get("Uct-Inboxsessionid")
			var correlationID = c.Request().Header.Get(middleware.HeaderXCorrelationID)
			var requestID = c.Request().Header.Get(middleware.HeaderXRequestID)

			if len(inboxSessionID) == 0 {
				return echo.NewHTTPError(http.StatusUnauthorized, "Invalid session")
			}
			sessionRq := session.SessionRq{}
			sessionRq.Header.InboxSessionId = inboxSessionID
			sessionRq.Header.CorrId = correlationID
			session, errSession := p.MsSessionService.GetSessionWithContext(ctx, sessionRq)
			if errSession != nil {
				logging.L().Error("Call ms-session got error",
					zap.String("corrId", correlationID),
					zap.String("rqId", requestID),
					zap.String("inboxSessionId", inboxSessionID),
					zap.Error(errSession),
				)
				return errSession
			} else if len(session.ProfileId) == 0 || len(session.MobileNo) == 0 {
				return echo.NewHTTPError(http.StatusUnauthorized, "Invalid session")
			}

			if reqHeaders, ok := ctx.Value("reqHeaders").(map[string]interface{}); ok {
				reqHeaders["mobileNo"] = session.MobileNo
				reqHeaders["profileId"] = session.ProfileId
				ctx = context.WithValue(ctx, "reqHeaders", reqHeaders)
			}
			ctx = context.WithValue(ctx, "session", session)
			c.SetRequest(c.Request().Clone(ctx))

			c.Request().Header.Set("Uct-Mobileno", session.MobileNo)
			c.Request().Header.Set("Uct-Profileid", session.ProfileId)

			return next(c)
		}
	}
}
