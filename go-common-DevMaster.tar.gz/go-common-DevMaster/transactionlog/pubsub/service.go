package pubsub

import (
	"context"
	"encoding/json"

	pubsubclient "go.kbtg.tech/715_MicroService/go-common/core_message_queue/client"
	"go.kbtg.tech/715_MicroService/go-common/transactionlog"
)

type (
	PubsubService struct {
		client pubsubclient.MessageQueueProducerClient
	}
)

func NewPubsubService(client pubsubclient.MessageQueueProducerClient) *PubsubService {
	return &PubsubService{
		client: client,
	}
}

func (t *PubsubService) CreateTransactionLogs(ctx context.Context, trans transactionlog.TransactionLogsRq) error {
	data, err := json.Marshal(trans)
	if err != nil {
		return err
	}

	// Currently don't need to pass in any attributes
	// So passing empty map as the second argument
	m := map[string]string{}
	_, err = t.client.InsertMessage(data, &m)
	if err != nil {
		return err
	}

	return nil
}
