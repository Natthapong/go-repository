package transactionlog

import (
	"time"

	ms "go.kbtg.tech/715_MicroService/go-common/ms-model"
)

type (
	TransactionLogsRq struct {
		Header ms.MsRequestHeader `json:"header,omitempty"`
		Data   []TransactionLog   `json:"data,omitempty"`
	}

	TransactionLog struct {
		ProfileID             string     `json:"profileId,omitempty"`
		FeedId                string     `json:"feedId,omitempty"`
		CorrID                string     `json:"corrId,omitempty"`
		LogName               string     `json:"logName,omitempty"`
		LogType               string     `json:"logType,omitempty"`
		SourceSystem          string     `json:"sourceSystem,omitempty"`
		Remark                string     `json:"remark,omitempty"`
		NotificationLogStep   string     `json:"notificationLogStep,omitempty"`
		NotificationLogStatus string     `json:"notificationLogStatus,omitempty"`
		RawContent            string     `json:"rawContent,omitempty"`
		DateTime              *time.Time `json:"dateTime,omitempty"`
	}
)
