package transactionlog

import "context"

type (
	Service interface {
		CreateTransactionLogs(ctx context.Context, rq TransactionLogsRq) error
	}
)
