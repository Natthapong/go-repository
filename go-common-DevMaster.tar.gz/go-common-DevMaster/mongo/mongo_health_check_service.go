package mongo

import (
	"context"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/x/bsonx"
	"go.kbtg.tech/715_MicroService/go-common/logging"
)

type MongoHealthCheckService struct {
	db   *mongo.Database
	name string
	timeout time.Duration
}

func NewMongoHealthService(db *mongo.Database, name string, timeout time.Duration) *MongoHealthCheckService {
	return &MongoHealthCheckService{db, name, timeout}
}

func NewDefaultMongoHealthService(db *mongo.Database) *MongoHealthCheckService {
	return NewMongoHealthService(db, "mongo", 5 * time.Second)
}

func (s *MongoHealthCheckService) GetId() string {
	return s.name
}

func (s *MongoHealthCheckService) Check(ctx context.Context) error {
	if s.timeout > 0 {
		cancel := func() {}
		ctx, cancel = context.WithTimeout(ctx, s.timeout)
		defer cancel()
	}

	info := make(map[string]interface{})
	err := s.db.RunCommand(ctx, bsonx.Doc{{"ping", bsonx.Int32(1)}}).Decode(&info)
	if err != nil {
		logging.Errorf(ctx, "Mongo Health Check error: %s", err.Error())
	}
	return err
}
