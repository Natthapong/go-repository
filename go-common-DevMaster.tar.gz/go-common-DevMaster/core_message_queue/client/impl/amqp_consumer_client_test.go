package impl

import (
	"context"
	"reflect"
	"testing"

	"github.com/Azure/go-amqp"
	"go.uber.org/zap"
)

func TestAMQPConsumerClient_mapToAttributes(t *testing.T) {
	type fields struct {
		ctx      context.Context
		Receiver *amqp.Receiver
		Session  *amqp.Session
		logger   *zap.Logger
	}
	type args struct {
		header map[string]interface{}
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   map[string]string
	}{
		{
			name:   "Convert basic types (non pointer)",
			fields: fields{},
			args: args{
				header: map[string]interface{}{
					"UCT_mobileNo":      "0942519194",
					"UCT_batchId":       "B20210721095436455_715",
					"UCT_correlationId": "c3roor2bvqp6u7g5ilr0",
					"UCT_mode":          "batch",
					"UCT_lineNo":        2,
					"some-bool":         true,
					"some-float":        1.001,
				},
			},
			want: map[string]string{
				"UCT_mobileNo":      "0942519194",
				"UCT_batchId":       "B20210721095436455_715",
				"UCT_correlationId": "c3roor2bvqp6u7g5ilr0",
				"UCT_mode":          "batch",
				"UCT_lineNo":        "2",
				"some-bool":         "true",
				"some-float":        "1.001",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &AMQPConsumerClient{
				ctx:      tt.fields.ctx,
				Receiver: tt.fields.Receiver,
				Session:  tt.fields.Session,
				logger:   tt.fields.logger,
			}
			if got := c.mapToAttributes(tt.args.header); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AMQPConsumerClient.mapToAttributes() = %v, want %v", got, tt.want)
			}
		})
	}
}
