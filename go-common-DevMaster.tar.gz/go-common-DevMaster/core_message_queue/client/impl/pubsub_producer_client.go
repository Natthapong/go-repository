package impl

import (
	"context"
	"time"

	"cloud.google.com/go/iam"
	"cloud.google.com/go/pubsub"
	"go.uber.org/zap"
	"google.golang.org/api/option"
	config "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	"go.kbtg.tech/715_MicroService/go-common/utils"
)

var checkTopicPermission = checkPermission

type PubSubProducerClient struct {
	ctx    context.Context
	Client *pubsub.Client
	topic  *pubsub.Topic
	logger *zap.Logger
}

func NewPubSubProducerClient(pubSubProducerConfig config.PubSubProducerConfig) *PubSubProducerClient {
	return NewPubSubProducerClientWtihLogger(pubSubProducerConfig, zap.L())
}
func NewPubSubProducerClientWtihLogger(pubSubProducerConfig config.PubSubProducerConfig, logger *zap.Logger) *PubSubProducerClient {
	//ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)
	ctx := context.Background()
	var (
		client *pubsub.Client
		err    error
	)
	if utils.FileExists(pubSubProducerConfig.KeyFilename) {
		logger.Info("key file exists: " + pubSubProducerConfig.KeyFilename)
		client, err = pubsub.NewClient(ctx, pubSubProducerConfig.ProjectId,
			option.WithCredentialsFile(pubSubProducerConfig.KeyFilename),
		)
	} else {
		logger.Info("key file doesn't exists: " + pubSubProducerConfig.KeyFilename)
		client, err = pubsub.NewClient(ctx, pubSubProducerConfig.ProjectId)
	}
	if err != nil {
		logger.Error(err.Error())
	}

	topic := client.Topic(pubSubProducerConfig.TopicName)

	//if exists, err := topic.Exists(ctx); err != nil {
	//	logger.Fatalf("Error checking exists topic: %v", err)
	//} else if !exists {
	//	logger.Fatalf("Topic not exists: %s", pubSubProducerConfig.TopicName)
	//}

	checkTopicPermission(topic.IAM(), "pubsub.topics.publish")

	if pubSubProducerConfig.Batching != nil {
		topic.PublishSettings.DelayThreshold = time.Duration(pubSubProducerConfig.Batching.MaxMilliseconds) * time.Millisecond
		topic.PublishSettings.CountThreshold = pubSubProducerConfig.Batching.MaxMessages
		topic.PublishSettings.ByteThreshold = pubSubProducerConfig.Batching.MaxBytes
	}

	if pubSubProducerConfig.Concurrency != nil {
		topic.PublishSettings.NumGoroutines = pubSubProducerConfig.Concurrency.NumGoroutines
	}

	return &PubSubProducerClient{ctx: ctx, Client: client, topic: topic, logger: logger}
}

func (c *PubSubProducerClient) InsertMessage(data []byte, messageAttributes *map[string]string) (interface{}, error) {
	msg := &pubsub.Message{
		Data: data,
	}

	if messageAttributes != nil {
		msg.Attributes = *messageAttributes
	}

	publishResult := c.topic.Publish(c.ctx, msg)

	if serverId, err := publishResult.Get(c.ctx); err != nil {
		return nil, err
	} else {
		return serverId, nil
	}
}

func checkPermission(iam *iam.Handle, permission string) {
	logger := zap.S()
	ctx, _ := context.WithTimeout(context.Background(), 30*time.Second)
	logger.Infof("Checking permission: %s", permission)
	if permissions, err := iam.TestPermissions(ctx, []string{permission}); err != nil {
		logger.Fatalf("Can't check permission %s: %v", permission, err)
	} else if len(permissions) > 0 && permissions[0] == permission {
		logger.Infof("Permission %s valid", permission)
	} else {
		logger.Fatalf("Permission %s invalid", permission)
	}
}
