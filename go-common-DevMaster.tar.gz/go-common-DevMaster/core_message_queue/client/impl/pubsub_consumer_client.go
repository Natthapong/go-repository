package impl

import (
	"context"
	"time"

	"cloud.google.com/go/pubsub"
	config "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	model "go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"
	"go.kbtg.tech/715_MicroService/go-common/utils"
	"go.uber.org/zap"
	"google.golang.org/api/option"
)

// const kOverallMessages = 10 * 1000 * 1000
// const kWorker = 5
// const kBytesPerWorker = 100000000 // 100 MB per worker

type PubSubConsumerClient struct {
	ctx          context.Context
	Client       *pubsub.Client
	Subscription *pubsub.Subscription
	logger       *zap.Logger
}

func NewPubSubConsumerClient(cctx context.Context, pubSubConsumerConfig config.PubSubConsumerConfig) *PubSubConsumerClient {
	return NewPubSubConsumerClientWithLogger(cctx, pubSubConsumerConfig, zap.L())
}
func NewPubSubConsumerClientWithLogger(ctx context.Context, pubSubConsumerConfig config.PubSubConsumerConfig, logger *zap.Logger) *PubSubConsumerClient {
	var (
		client *pubsub.Client
		err    error
	)
	if utils.FileExists(pubSubConsumerConfig.KeyFilename) {
		logger.Info("key file exists")
		client, err = pubsub.NewClient(ctx, pubSubConsumerConfig.ProjectId,
			option.WithCredentialsFile(pubSubConsumerConfig.KeyFilename),
		)
	} else {
		logger.Info("key file doesn't exists")
		client, err = pubsub.NewClient(ctx, pubSubConsumerConfig.ProjectId)
	}

	if err != nil {
		logger.Error(err.Error())
	}

	subscription := client.Subscription(pubSubConsumerConfig.SubscriptionName)
	// subscription.ReceiveSettings.MaxOutstandingMessages = kOverallMessages
	// subscription.ReceiveSettings.NumGoroutines = kWorker

	return &PubSubConsumerClient{ctx: ctx, Client: client, Subscription: subscription, logger: logger}
}

func (c *PubSubConsumerClient) ConsumeMessage(callBack func(error, *model.MessageQueue)) {
	err := c.Subscription.Receive(c.ctx, func(ctx context.Context, m *pubsub.Message) {
		if m.Attributes == nil {
			m.Attributes = make(map[string]string)
		}
		m.Attributes["timestamp"] = m.PublishTime.Format(time.RFC3339)
		m.Attributes["msgID"] = m.ID
		messageQueue := model.MessageQueue{
			Data:       m.Data,
			Attributes: m.Attributes,
		}
		callBack(nil, &messageQueue)
		m.Ack()
	})
	if err != nil {
		callBack(err, nil)
	}
}
