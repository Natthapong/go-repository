package impl

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"strings"
	"time"

	"github.com/Azure/go-amqp"
	"github.com/opentracing/opentracing-go"
	"github.com/opentracing/opentracing-go/ext"
	"github.com/prometheus/client_golang/prometheus"
	prom "github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	amqptracer "github.com/thitiphong/go-amqptracer"
	"go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	"go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"
	"go.uber.org/zap"
)

type AMQPConsumerClient struct {
	ctx      context.Context
	Receiver *amqp.Receiver
	Session  *amqp.Session
	logger   *zap.Logger
}

var DefaultAMQPConsumerClient *AMQPConsumerClient
var (
	receiveMsgCnt = promauto.NewCounterVec(
		prom.CounterOpts{
			Name: "message_received_total",
			Help: "How many message received, partitioned by address",
		},
		[]string{"address"},
	)

	reqDur = promauto.NewHistogramVec(
		prometheus.HistogramOpts{
			Name: "message_handled_duration_seconds",
			Help: "Handing message latencies in seconds.",
		},
		[]string{"address"},
	)
)

func NewAMQPConsumerClient(ctx context.Context, cfg config.AMQPConsumerConfig) *AMQPConsumerClient {
	return NewAMQPConsumerClientWithLogger(ctx, cfg, zap.L())
}
func NewAMQPConsumerClientWithLogger(ctx context.Context, cfg config.AMQPConsumerConfig, logger *zap.Logger) *AMQPConsumerClient {

	conn, err := net.Dial("tcp", net.JoinHostPort(cfg.Host, cfg.Port))
	fatalIf(logger, err)

	hostname, _ := os.Hostname()
	client, err := amqp.New(conn,
		amqp.ConnSASLPlain(cfg.UserName, cfg.Password),
		amqp.ConnSASLAnonymous(),
		amqp.ConnTLS(false),
		amqp.ConnContainerID(hostname),
	)

	fatalIf(logger, err)
	// defer client.Close()

	// Open a session
	session, err := client.NewSession()

	fatalIf(logger, err)

	// Create a receiver
	rcvr, err := session.NewReceiver(
		amqp.LinkSourceAddress(cfg.Address),
		amqp.LinkCredit(cfg.LinkCredit),
	)

	if err != nil {
		logger.Fatal("Creating receiver link: " + err.Error())
	}
	logger.Info("AMQP receiver created")

	c := &AMQPConsumerClient{ctx: ctx, Receiver: rcvr, Session: session, logger: logger}
	if DefaultAMQPConsumerClient == nil {
		DefaultAMQPConsumerClient = c
	}
	return c
}

func fatalIf(logger *zap.Logger, err error) {
	if err != nil {
		logger.Fatal(err.Error())
	}
}

func (c *AMQPConsumerClient) ConsumeMessage(callBack func(error, *model.MessageQueue)) {
	addr := c.Receiver.Address()
	// Continuously read messages
	for {
		// Receive next message
		msg, err := c.Receiver.Receive(c.ctx)
		if err != nil {
			if errors.Is(err, context.Canceled) {
				c.logger.Warn("Consumer stop by canceled context")
				break
			}
			time.Sleep(3 * time.Second) // to prevent in-flight transaction lost.
			c.logger.Fatal("Reading message from AMQP: " + err.Error())
		}
		start := time.Now()

		// OpenTracing
		spCtx, err := amqptracer.Extract(msg.ApplicationProperties)
		var sp opentracing.Span
		if err == nil {
			sp = opentracing.StartSpan("handle message", opentracing.FollowsFrom(spCtx))
			ext.SpanKindConsumer.Set(sp)
			sp.SetTag("address", addr)
		}

		// fmt.Printf("Message received: %s\n", msg.Value)
		attributes := c.mapToAttributes(msg.ApplicationProperties)
		messageQueue := model.MessageQueue{
			Data:       []byte(msg.Value.(string)),
			Attributes: attributes,
		}
		callBack(nil, &messageQueue)

		// Accept message
		c.Receiver.AcceptMessage(c.ctx, msg)
		if sp != nil {
			sp.Finish()
		}
		elapsed := float64(time.Since(start)) / float64(time.Second)
		// Prometheus metrics
		reqDur.WithLabelValues(addr).Observe(elapsed)
		receiveMsgCnt.WithLabelValues(addr).Inc()
	}
}

func (c *AMQPConsumerClient) Consume(callBack func(context.Context, error, *model.MessageQueue)) {
	addr := c.Receiver.Address()
	// Continuously read messages
	for {
		// Receive next message
		msg, err := c.Receiver.Receive(c.ctx)
		if err != nil {
			if errors.Is(err, context.Canceled) {
				c.logger.Warn("Consumer stop by canceled context")
				break
			}
			c.logger.Fatal("Reading message from AMQP: " + err.Error())
		}
		start := time.Now()

		// OpenTracing
		spCtx, err := amqptracer.Extract(msg.ApplicationProperties)
		var sp opentracing.Span
		if err == nil {
			sp = opentracing.StartSpan("handle message", opentracing.FollowsFrom(spCtx))
			ext.SpanKindConsumer.Set(sp)
			sp.SetTag("address", addr)
		}
		ctx := opentracing.ContextWithSpan(context.Background(), sp)

		// fmt.Printf("Message received: %s\n", msg.Value)
		attributes := c.mapToAttributes(msg.ApplicationProperties)
		messageQueue := model.MessageQueue{
			Data:       []byte(msg.Value.(string)),
			Attributes: attributes,
		}
		callBack(ctx, nil, &messageQueue)

		// Accept message
		c.Receiver.AcceptMessage(c.ctx, msg)
		if sp != nil {
			sp.Finish()
		}
		elapsed := float64(time.Since(start)) / float64(time.Second)
		// Prometheus metrics
		reqDur.WithLabelValues(addr).Observe(elapsed)
		receiveMsgCnt.WithLabelValues(addr).Inc()
	}
}

func (c *AMQPConsumerClient) mapToAttributes(header map[string]interface{}) map[string]string {
	attributes := make(map[string]string, 0)
	for k, v := range header {
		if !strings.HasPrefix(k, "JMS") {
			attributes[k] = fmt.Sprint(v)
		}
	}
	return attributes
}
