package impl

import (
	"context"
	"fmt"
	"net"
	"os"
	"time"

	"github.com/Azure/go-amqp"
	"github.com/rs/zerolog/log"

	config "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
)

type AMQPProducerClient struct {
	ctx     context.Context
	Sender  *amqp.Sender
	Session *amqp.Session
}

func NewAMQPProducerClient(amqpCfg config.AMQPProducerConfig) *AMQPProducerClient {
	ctx := context.Background()

	addr := net.JoinHostPort(amqpCfg.Host, amqpCfg.Port)
	client, dialErr := amqp.Dial("amqp://"+addr,
		amqp.ConnSASLPlain(amqpCfg.UserName, amqpCfg.Password),
		amqp.ConnSASLAnonymous(),
		amqp.ConnContainerID(clientID()),
		amqp.ConnTLS(false),
		amqp.ConnConnectTimeout(20*time.Second),
	)
	if dialErr != nil {
		log.Fatal().Err(dialErr).Msg("Dialing AMQP server")
	}
	log.Info().Msg("connected to AMQP server")

	// Open a session
	session, sessionErr := client.NewSession()
	if sessionErr != nil {
		log.Fatal().Err(sessionErr).Msg("Creating AMQP session")
	}
	log.Info().Msg("AMQP session created")

	sender, err := session.NewSender(amqp.LinkTargetAddress(amqpCfg.Address))
	if err != nil {
		log.Error().Err(err).Msgf("create sender link %s", amqpCfg.Address)
	}
	log.Info().Msgf("created a sender (ID:%s) for address %s", sender.LinkName(), amqpCfg.Address)

	return &AMQPProducerClient{ctx: ctx, Sender: sender, Session: session}
}

func (c *AMQPProducerClient) InsertMessage(data []byte, messageAttributes *map[string]string) (interface{}, error) {
	msg := &amqp.Message{
		Value: string(data),
	}

	if messageAttributes != nil {
		msg.ApplicationProperties = c.mapToAttributes(*messageAttributes)
	}

	// Send message
	err := c.Sender.Send(c.ctx, msg)

	if err != nil {
		return nil, err
	} else {
		log.Debug().Str("destination", c.Sender.Address()).Interface("value", msg.Value).Msg("Pushed Queue")
		return c.Sender.LinkName(), nil
	}
}

func (c *AMQPProducerClient) mapToAttributes(header map[string]string) map[string]interface{} {
	attributes := make(map[string]interface{}, 0)
	for k, v := range header {
		attributes[k] = fmt.Sprintf("%s", v)
	}
	return attributes
}

func clientID() string {
	hostname, err := os.Hostname()
	if err != nil {
		hostname = os.Getenv("HOST")
	}
	log.Info().Msgf("hostname: %s", hostname)
	return fmt.Sprintf("%s-%v", hostname, os.Getpid())
}
