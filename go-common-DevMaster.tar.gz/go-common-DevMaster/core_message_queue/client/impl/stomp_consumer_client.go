package impl

import (
	"context"
	"os"

	"github.com/go-stomp/stomp"
	"github.com/go-stomp/stomp/frame"
	"go.uber.org/zap"
	config "go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	model "go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"
)

type AMQConsumerClient struct {
	ctx          context.Context
	Client       *stomp.Conn
	Subscription *stomp.Subscription
	logger       *zap.Logger
}

func NewAMQConsumerClient(AMQConsumerConfig config.AMQConsumerConfig) *AMQConsumerClient {
	return NewAMQConsumerClientWithLogger(AMQConsumerConfig, zap.L())
}
func NewAMQConsumerClientWithLogger(AMQConsumerConfig config.AMQConsumerConfig, logger *zap.Logger) *AMQConsumerClient {
	ctx := context.Background()
	var options []func(*stomp.Conn) error = []func(*stomp.Conn) error{}
	if len(AMQConsumerConfig.UserName) > 0 && len(AMQConsumerConfig.Password) > 0 {
		clientID, err := os.Hostname()
		if err != nil {
			logger.Error("Cannot get hostname " + err.Error())
		}
		options = []func(*stomp.Conn) error{
			stomp.ConnOpt.Login(AMQConsumerConfig.UserName, AMQConsumerConfig.Password),
			// stomp.ConnOpt.Host("/"),
			stomp.ConnOpt.Header("client-id", clientID),
		}
	}
	client, err := stomp.Dial("tcp", AMQConsumerConfig.Addr, options...)
	if err != nil {
		logger.Error("Cannot connect to server amq: " + err.Error())
		return nil
	}
	// Artemis FQQN = address::queue
	des := AMQConsumerConfig.DestinationName + "::" + AMQConsumerConfig.SubscriptionName
	subscription, err1 := client.Subscribe(des, stomp.AckAuto,
		stomp.SubscribeOpt.Header("subscription-type", "ANYCAST"),
	)
	if err1 != nil {
		logger.Error("Cannot subscribe to " + err1.Error())
		return nil
	}
	return &AMQConsumerClient{ctx: ctx, Client: client, Subscription: subscription, logger: logger}
}

func (c *AMQConsumerClient) ConsumeMessage(callBack func(error, *model.MessageQueue)) {
	for msg := range c.Subscription.C {
		attributes := c.mapToAttributes(msg.Header)
		messageQueue := model.MessageQueue{
			Data:       msg.Body,
			Attributes: attributes,
		}
		callBack(nil, &messageQueue)
	}
}

func (c *AMQConsumerClient) mapToAttributes(header *frame.Header) map[string]string {
	attributes := make(map[string]string, 0)
	for i := 0; i < header.Len(); i++ {
		key, value := header.GetAt(i)
		attributes[key] = value
	}
	return attributes
}
