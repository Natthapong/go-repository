package impl

import (
	"context"
	"fmt"
	"os"
	"testing"

	"cloud.google.com/go/iam"
	"cloud.google.com/go/pubsub"
	"cloud.google.com/go/pubsub/pstest"
	"github.com/stretchr/testify/assert"
	"google.golang.org/api/option"
	"google.golang.org/grpc"
	"go.kbtg.tech/715_MicroService/go-common/core_message_queue/config"
	"go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"
)

func TestConsumeMessage(t *testing.T) {
	ctx := context.Background()
	srv := pstest.NewServer()
	inputMessage := "unit_test"
	conn, _ := grpc.Dial(srv.Addr, grpc.WithInsecure())
	client, _ := pubsub.NewClient(ctx, "test-project", option.WithGRPCConn(conn))
	defer client.Close()
	topic, _ := client.CreateTopic(ctx, "test-topic")
	sub, _ := client.CreateSubscription(ctx, "sub-name", pubsub.SubscriptionConfig{Topic: topic})
	old := checkTopicPermission
	defer func() { checkTopicPermission = old }()
	checkTopicPermission = func(iam *iam.Handle, permission string) {}

	os.Setenv("PUBSUB_EMULATOR_HOST", srv.Addr)
	pubSubConsumerConfig := config.PubSubConsumerConfig{ProjectId: "test-project", SubscriptionName: sub.ID()}
	consumer := NewPubSubConsumerClient(ctx, pubSubConsumerConfig)
	pubSubProducerConfig := config.PubSubProducerConfig{ProjectId: "test-project", TopicName: topic.ID()}
	pubSubProducerConfig.Concurrency = &config.PubSubProducerConcurrencyConfig{1}
	pubSubProducerConfig.Batching = &config.PubSubProducerBatchingConfig{1, 30000, 1000}
	producer := NewPubSubProducerClient(pubSubProducerConfig)
	messageAttributes := make(map[string]string)
	messageAttributes["Test"] = "Test"
	producer.InsertMessage([]byte(inputMessage), &messageAttributes)
	consumer.ConsumeMessage(func(err error, message *model.MessageQueue) {
		if err == nil {
			actual := fmt.Sprintf("%s", message.Data)
			assert.Equal(t, inputMessage, actual)
		}
		defer producer.Client.Close()
		defer consumer.Client.Close()
	})
}
