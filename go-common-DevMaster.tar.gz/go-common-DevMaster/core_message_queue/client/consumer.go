package repository

import model "go.kbtg.tech/715_MicroService/go-common/core_message_queue/model"

type MessageQueueConsumerClient interface {
	ConsumeMessage(f func(error, *model.MessageQueue))
}
