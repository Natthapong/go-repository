package repository

type MessageQueueProducerClient interface {
	InsertMessage(data []byte, messageAttributes *map[string]string) (interface{}, error)
}
