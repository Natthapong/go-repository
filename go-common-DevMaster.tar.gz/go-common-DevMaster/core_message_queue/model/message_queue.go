package model

type MessageQueue struct {
	Data       []byte
	Attributes map[string]string
}
