package config

type PubSubProducerConfig struct {
	ProjectId   string                           `mapstructure:"projectId"`
	KeyFilename string                           `mapstructure:"keyFilename"`
	TopicName   string                           `mapstructure:"topicName"`
	Batching    *PubSubProducerBatchingConfig    `mapstructure:"batching"`
	Concurrency *PubSubProducerConcurrencyConfig `mapstructure:"concurrency"`
}

type PubSubProducerBatchingConfig struct {
	MaxMessages     int `mapstructure:"maxMessages"`
	MaxMilliseconds int `mapstructure:"maxMilliseconds"`
	MaxBytes        int `mapstructure:"maxBytes"`
}

type PubSubProducerConcurrencyConfig struct {
	NumGoroutines int `mapstructure:"numGoroutines"`
}
