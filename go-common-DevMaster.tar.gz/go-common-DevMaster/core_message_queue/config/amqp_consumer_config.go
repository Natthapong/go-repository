package config

type AMQPConsumerConfig struct {
	Host       string `mapstructure:"host"`
	Port       string `mapstructure:"port"`
	UserName   string `mapstructure:"username"`
	Password   string `mapstructure:"password"`
	Address    string `mapstructure:"address"`
	LinkCredit uint32 `mapstructure:"linkcredit"`
}
