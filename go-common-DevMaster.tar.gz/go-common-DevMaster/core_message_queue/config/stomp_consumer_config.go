package config

type AMQConsumerConfig struct {
	Addr             string `mapstructure:"addr"`
	Host             string `mapstructure:"host"`
	UserName         string `mapstructure:"username"`
	Password         string `mapstructure:"password"`
	DestinationName  string `mapstructure:"destinationName"`
	SubscriptionName string `mapstructure:"subscriptionName"`
}
