package config

type PubSubConsumerConfig struct {
	ProjectId        string `mapstructure:"projectId"`
	KeyFilename      string `mapstructure:"keyFilename"`
	SubscriptionName string `mapstructure:"subscriptionName"`
}

