package kmb_model

type KmbRequestHeader struct {
	RequestId       string `bson:"requestId" json:"requestId"`
	IpAddress       string `bson:"ipAddress" json:"ipAddress"`
	AppName         string `bson:"appName" json:"appName"`
	RequestAppId    string `bson:"requestAppId" json:"requestAppId"`
	RequestDateTime string `bson:"requestDateTime" json:"requestDateTime"`
	Channel         string `bson:"channel" json:"channel"` // = "UCenter"
	MobileNumber    string `bson:"mobileNumber" json:"mobileNumber"`
	MobileOperator  string `bson:"mobileOperator" json:"mobileOperator"`
	Language        string `bson:"language" json:"language"`
	FromMenu        string `bson:"fromMenu" json:"fromMenu"`
	AppVersion      string `bson:"appVersion" json:"appVersion"`
	OsPlatform      string `bson:"osPlatform" json:"osPlatform"`
	OsVersion       string `bson:"osVersion" json:"osVersion"`
}
