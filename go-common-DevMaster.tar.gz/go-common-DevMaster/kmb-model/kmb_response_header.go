package kmb_model

type KmbResponseHeader struct {
	AppId               string `bson:"appId" json:"appId"`
	RequestedAppId      string `bson:"requestedAppId" json:"requestedAppId"`
	RequestedDateTime   string `bson:"requestedDateTime" json:"requestedDateTime"`
	RequestedId         string `bson:"requestedId" json:"requestedId"`
	ResponseCode        string `bson:"responseCode" json:"responseCode"`
	ResponseDateTime    string `bson:"responseDateTime" json:"responseDateTime"`
	ResponseDescription string `bson:"responseDescription" json:"responseDescription"`
	ResponseId          string `bson:"responseId" json:"responseId"`
	ResponseStatus      string `bson:"responseStatus" json:"responseStatus"`
}
