package kmb_model

import (
	message "go.kbtg.tech/715_MicroService/go-common/core_message"
	"net"
	"os"
)

type DefaultKmbRequestBuilder struct {
}

func (b *DefaultKmbRequestBuilder) BuildHeader(reqHeader message.RequestHeader) KmbRequestHeader {
	var header = KmbRequestHeader{}
	header.RequestAppId = reqHeader.AppId
	//header.RequestId = IDGenerator.GenID20Digits(reqHeader.AppId)
	//header.RequestDateTime = DateUtil.FormatDate(DateUtil.Now(), "20060102150405") // YYYYMMDDHHmmssSSS
	header.MobileNumber = reqHeader.MobileNo
	header.Language = reqHeader.Language.String()

	var address string
	host, _ := os.Hostname()
	addrs, _ := net.LookupIP(host)
	for _, addr := range addrs {
		if ipv4 := addr.To4(); ipv4 != nil {
			address = ipv4.String()
		}
	}
	header.IpAddress = address
	header.Channel = "UCenter"
	header.FromMenu = ""
	header.AppName = "App01"
	header.AppVersion = reqHeader.AppVersion
	header.OsPlatform = reqHeader.MobileOS
	header.OsVersion = ""
	return header
}
