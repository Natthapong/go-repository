package kmb_model

type KmbDocument struct {
	CardExpDatestring    string `bson:"cardExpDatestring" json:"cardExpDatestring"`
	CardIssueDatestring  string `bson:"cardIssueDatestring" json:"cardIssueDatestring"`
	CardIssuePlacestring string `bson:"cardIssuePlacestring" json:"cardIssuePlacestring"`
	Numstring            string `bson:"numstring" json:"numstring"`
	PrimaryCodestring    string `bson:"primaryCodestring" json:"primaryCodestring"`
	TypeCodestring       string `bson:"typeCodestring" json:"typeCodestring"`
}
