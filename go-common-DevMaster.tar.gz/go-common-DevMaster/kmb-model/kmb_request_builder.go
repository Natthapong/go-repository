package kmb_model

import message "go.kbtg.tech/715_MicroService/go-common/core_message"

type KmbRequestBuilder interface {
	BuildHeader(reqHeader message.RequestHeader) KmbRequestHeader
}
