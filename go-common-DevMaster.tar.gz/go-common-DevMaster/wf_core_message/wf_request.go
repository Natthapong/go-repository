package wf_core_message

type WFRequest struct {
	Header WFRequestHeader `json:"header"`
	Data   *interface{}  `json:"data"`
}
