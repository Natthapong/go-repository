package wf_core_message

type WFResponseStatus struct {
	ResponseCode int    `json:"responseCode"`
	ResponseDesc string `json:"responseDesc,omitempty"`
}
