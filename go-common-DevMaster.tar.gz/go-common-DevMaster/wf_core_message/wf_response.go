package wf_core_message

type WFResponse struct {
	Header WFResponseHeader `json:"header"`
	Data   *interface{}     `json:"data,omitempty"`
	Error  *interface{}     `json:"error,omitempty"`
}
