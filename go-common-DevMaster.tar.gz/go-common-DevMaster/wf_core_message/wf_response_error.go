package wf_core_message

type WebformResponseError struct {
	Code     string      `json:"code"`
	Severity string      `json:"severity"`
	Message  interface{} `json:"message"`
}
