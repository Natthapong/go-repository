package wf_core_message

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	msg "go.kbtg.tech/715_MicroService/go-common/core_message"
)

const WFDatetimePattern = "20060102150405"

type DefaultWebformResponseBuilder struct {
}

func (p *DefaultWebformResponseBuilder) HasAnyError(errors []msg.ErrorMessage) bool {
	return len(errors) != 0
}

func (p *DefaultWebformResponseBuilder) CreateResponseHeader(requestHeader WFRequestHeader) *WFResponseHeader {
	id := strings.Replace(uuid.New().String(), "-", "", -1)
	var header = WFResponseHeader{}
	header.CorrID = requestHeader.CorrID
	header.RequestedUniqueID = requestHeader.RequestUniqueID
	header.RequestDateTime = requestHeader.RequestDateTime
	header.ResponseID = id
	header.ResponseDateTime = msg.FormatDate(time.Now(), WFDatetimePattern)
	header.InboxSessionID = requestHeader.InboxSessionID
	header.Errors = make([]msg.ErrorMessage, 0)
	return &header
}

func (p *DefaultWebformResponseBuilder) BuildResponseStatus(header *WFResponseHeader) *WFResponseHeader {
	var status msg.ResponseStatus
	var errors = header.Errors
	if len(errors) == 0 {
		header.Status = status.FromString("S")
		header.ResponseCode = strconv.Itoa(http.StatusOK)
		header.ResponseDesc = "Success"
	} else {
		header.Status = status.FromString("F")
		header.ResponseCode = strconv.Itoa(http.StatusInternalServerError)
		header.ResponseDesc = "Fail"
	}
	return header
}

func (p *DefaultWebformResponseBuilder) BuildResponseSuccess(header *WFResponseHeader, responseStatus WFResponseStatus) *WFResponseHeader {
	var status msg.ResponseStatus
	header.Status = status.FromString("S")
	header.ResponseCode = strconv.Itoa(responseStatus.ResponseCode)
	header.ResponseDesc = responseStatus.ResponseDesc
	return header
}

func (p *DefaultWebformResponseBuilder) BuildNotFoundResponse(header *WFResponseHeader) *WFResponseHeader {
	return p.BuildNotFoundResponseWithMessage(header, http.StatusText(http.StatusNotFound))
}

func (p *DefaultWebformResponseBuilder) BuildNotFoundResponseWithMessage(header *WFResponseHeader, message string) *WFResponseHeader {
	var status msg.ResponseStatus
	header.Status = status.FromString("F")
	header.ResponseCode = strconv.Itoa(http.StatusNotFound)
	header.ResponseDesc = message
	return header
}

func (p *DefaultWebformResponseBuilder) BuildFailedBusinessResponseWithMessageAndCode(response *WFResponseHeader, message string, code string) *WFResponseHeader {
	var error = msg.ErrorMessage{}
	error.ErrorCode = code
	error.ErrorDesc = message
	return p.BuildResponseFromError(response, error)
}

func (p *DefaultWebformResponseBuilder) BuildResponseFromErrors(header *WFResponseHeader, errors []msg.ErrorMessage) *WFResponseHeader {
	var status msg.ResponseStatus
	if len(errors) > 0 {
		for i := 0; i < len(errors); i++ {
			// fmt.Println(errors[i])
			header.Errors = append(header.Errors, errors[i])
		}
	} else {
		header.Errors = errors
	}
	if len(header.Errors) == 0 {
		header.Status = status.FromString("S")
		header.ResponseCode = "200"
		header.ResponseDesc = "Success"
	} else {
		header.Status = status.FromString("F")
		header.ResponseCode = "500"
		header.ResponseDesc = "Fail"
	}
	var responseDesc string
	header.Errors, responseDesc = p.transformErrors(header.Errors)
	if len(responseDesc) > 0 {
		header.ResponseDesc = responseDesc
	}
	return header
}

func (p *DefaultWebformResponseBuilder) transformErrors(errors []msg.ErrorMessage) ([]msg.ErrorMessage, string) {
	var responseDesc string
	var errs = make([]msg.ErrorMessage, 0)
	for _, elem := range errors {
		if !((elem.ErrorCode == "503" && strings.HasPrefix(elem.ErrorDesc, "Network Error: ")) || (elem.ErrorCode == "500" && strings.HasPrefix(elem.ErrorDesc, "Database Error: "))) {
			errs = append(errs, elem)
		}
		if arr := strings.Split(elem.ErrorDesc, "||"); len(arr) > 1 {
			responseDesc = arr[1]
		}
	}
	return errs, responseDesc
}

func (p *DefaultWebformResponseBuilder) BuildResponseFromError(responseHeader *WFResponseHeader, error msg.ErrorMessage) *WFResponseHeader {
	if error.ErrorDesc == "" {
		return p.BuildResponseFromErrors(responseHeader, nil)
	} else {
		var errors = make([]msg.ErrorMessage, 0)
		errors = append(errors, error)
		return p.BuildResponseFromErrors(responseHeader, errors)
	}
}

func (p *DefaultWebformResponseBuilder) BuildFailedBusinessResponseFromErrorCodeAndDescription(header *WFResponseHeader, responseCode string, responseDesc string) *WFResponseHeader {
	return p.BuildFailedBusinessResponseWithMessageAndCode(header, responseCode, responseDesc)
}
