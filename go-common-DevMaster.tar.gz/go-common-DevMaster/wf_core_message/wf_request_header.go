package wf_core_message

import "go.kbtg.tech/715_MicroService/go-common/core_message"

type WFRequestHeader struct {
	MobileNo        string                `json:"mobileNo" bson:"mobileNo" `
	MobileOS        string                `json:"mobileOS" bson:"mobileOS"`
	AppVersion      string                `json:"appVersion" bson:"appVersion"`
	AppID           string                `json:"appId" bson:"appId"`
	InboxSessionID  string                `json:"inboxSessionId" bson:"inboxSessionId"`
	RequestUniqueID string                `json:"requestUniqueId" bson:"requestUniqueId"`
	RequestDateTime string                `json:"requestDateTime" bson:"requestDateTime"`
	CorrID          string                `json:"corrId" bson:"corrId"`
	Language        core_message.Language `json:"language" bson:"language"`
	FormID          string                `json:"formId,omitempty" bson:"formId,omitempty"`
}
