package wf_core_message

import "go.kbtg.tech/715_MicroService/go-common/core_message"

type WFResponseHeader struct {
	Status            core_message.ResponseStatus `json:"status" bson:"status"`
	ResponseCode      string                      `json:"responseCode" bson:"responseCode"`
	ResponseDesc      string                      `json:"responseDesc" bson:"responseDesc"`
	RequestedUniqueID string                      `json:"requestedUniqueId" bson:"requestedUniqueId"`
	RequestDateTime   string                      `json:"requestedDateTime" bson:"requestDateTime"`
	ResponseID        string                      `json:"responseId" bson:"responseId"`
	ResponseDateTime  string                      `json:"responseDateTime" bson:"responseDateTime"`
	InboxSessionID    string                      `json:"inboxSessionId" bson:"inboxSessionId"`
	Errors            []core_message.ErrorMessage `json:"errors,omitempty" bson:"errors,omitempty"`
	CorrID            string                      `json:"corrId" bson:"corrId"`
}
