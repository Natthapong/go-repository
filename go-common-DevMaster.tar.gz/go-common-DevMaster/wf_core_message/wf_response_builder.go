package wf_core_message

import err "go.kbtg.tech/715_MicroService/go-common/core_message"

type WebformResponseBuilder interface {
	HasAnyError(errors []err.ErrorMessage) bool
	CreateResponseHeader(requestHeader WFRequestHeader) *WFResponseHeader
	BuildResponseStatus(header *WFResponseHeader) *WFResponseHeader
	BuildResponseSuccess(header *WFResponseHeader, responseStatus WFResponseStatus) *WFResponseHeader
	BuildNotFoundResponse(header *WFResponseHeader) *WFResponseHeader
	BuildResponseFromErrors(header *WFResponseHeader, errors []err.ErrorMessage) *WFResponseHeader
	BuildNotFoundResponseWithMessage(header *WFResponseHeader, message string) *WFResponseHeader
	BuildFailedBusinessResponseWithMessageAndCode(response *WFResponseHeader, message string, code string) *WFResponseHeader
	BuildFailedBusinessResponseFromErrorCodeAndDescription(header *WFResponseHeader, responseCode string, responseDesc string) *WFResponseHeader
}
